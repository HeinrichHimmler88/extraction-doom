  const dx=per.dx,dy=per.dy,dist=per.dist;
  const nx=dx/dist,ny=dy/dist;
  if(!per.see){
    e.lostT=(e.lostT||0)+dt;
    if(e.lostT>3){setState(e,'SEARCH');e.searchPoint=e.lastKnownPos||{x:per.tgtX,y:per.tgtY};e.searchT=8;e.lostT=0;return}
  } else {
    e.lostT=0;e.lastKnownPos={x:per.tgtX,y:per.tgtY};
    let diff=per.angleToP-e.face;
    while(diff>Math.PI)diff-=Math.PI*2;while(diff<-Math.PI)diff+=Math.PI*2;
    e.face+=clamp(diff,-4*dt,4*dt);
  }
  if(e.hp/e.maxHp<0.25&&!e.boss&&e.type!=='dog'){setState(e,'FLEE');e.fleeTarget=findCoverFrom(e,P.x,P.y);return}
  if(e.type==='officer'&&per.see&&dist<18&&e.shoutT<=0){
    e.shoutT=8+Math.random()*3;SFX.shout();msg('¡EL OFICIAL PIDE REFUERZOS!','#ff6a5a');
    broadcastToSquad(e,{x:P.x,y:P.y});if(e.outpost)raiseAlert(e.outpost,'ALARM');
  }
  if(e.boss&&e.reinforceT<=0&&dist<20){
    e.reinforceT=20;SFX.shout();msg('¡EL COMANDANTE PIDE REFUERZOS!','#ff2020');
    for(let i=0;i<2;i++){
      const a=Math.random()*6.28,r=3+Math.random()*2;
      const nxx=e.x+Math.cos(a)*r,nyy=e.y+Math.sin(a)*r;
      if(canStandProp(nxx,nyy,.3)){
        const conf=ETYPES.soldier;const nf=Math.random()*6.28;
        const hpMul=meta.nightmareActive?1.5:1,dmgMul=meta.nightmareActive?1.5:1;
        const ne={x:nxx,y:nyy,type:'soldier',hp:Math.round(conf.hp*hpMul),maxHp:Math.round(conf.hp*hpMul),speed:conf.speed,dmg:Math.round(conf.dmg*dmgMul),fr:conf.fr,corpse:conf.corpse,atkCd:.5,hurtT:0,alive:true,wt:0,wander:nf,wanderT:0,loot:makeLoot('soldier'),height:conf.h,aimT:0,shoutT:0,reinforceT:0,recentDmg:0,recentDmgT:0,zigzagT:0,zigzagDir:1,stop:conf.stop,boss:false,sniper:false,meleeType:false,pellets:1,minDist:0,maxDist:30,coverTarget:null,face:nf,detect:1,fov:conf.fov,sight:conf.sight,name:conf.name,color:conf.color,outpost:e.outpost,homeX:e.homeX,homeY:e.homeY,leash:e.leash,state:'COMBAT',stateT:0,lastKnownPos:{x:P.x,y:P.y}};
        enemies.push(ne);if(e.outpost)e.outpost.enemies.push(ne);total++;
      }
    }
  }
  if(per.see){
    let sx=0,sy=0;
    for(const o of enemies){if(o===e||!o.alive)continue;const px=e.x-o.x,py=e.y-o.y,d=Math.hypot(px,py);if(d>.001&&d<.85){sx+=px/d*(.85-d);sy+=py/d*(.85-d)}}
    let mx=0,my=0;const stopD=e.stop;
    if(e.meleeType&&dist>1.5){e.zigzagT=(e.zigzagT||0)-dt;if(e.zigzagT<=0){e.zigzagT=.35;e.zigzagDir=(e.zigzagDir||1)*-1}mx=nx+e.zigzagDir*(-ny)*.7;my=ny+e.zigzagDir*(nx)*.7}
    else if(e.sniper&&dist<e.minDist){mx=-nx;my=-ny}
    else if(dist>stopD){mx=nx;my=ny}
    else if(dist<stopD-1.5){mx=-nx;my=-ny}
    if(dist<10&&!e.meleeType){mx+=-ny*.4;my+=nx*.4}
    if(e.recentDmg>15&&!e.coverTarget){
      outer:for(let r=1;r<=4;r++){for(let a=0;a<8;a++){const ang=a*Math.PI/4;const cx=(e.x+Math.cos(ang)*r)|0,cy=(e.y+Math.sin(ang)*r)|0;if(cx<1||cy<1||cx>=MW-1||cy>=MH-1)continue;if(map[cy*MW+cx])continue;const mx2=cx+.5,my2=cy+.5;if(!los(mx2,my2,per.tgtX,per.tgtY)){e.coverTarget={x:mx2,y:my2,t:2.5};break outer}}}
    }
    if(e.coverTarget){e.coverTarget.t-=dt;if(e.coverTarget.t<=0)e.coverTarget=null;else{const cvx=e.coverTarget.x-e.x,cvy=e.coverTarget.y-e.y;const cvd=Math.hypot(cvx,cvy)||1;mx+=cvx/cvd*1.8;my+=cvy/cvd*1.8}}
    mx+=sx*2;my+=sy*2;
    const l=Math.hypot(mx,my);if(l>1){mx/=l;my/=l}
    let spd=e.speed;if(e.sniper&&e.aimT>0)spd=e.speed*.1;
    moveE(e,mx*spd*dt,my*spd*dt);
  }
  if(e.atkCd<=0&&per.see&&dist<(e.sniper?22:15))fireEnemyWeapon(e,dt,per,nx,ny);
}
function updEnemies(dt){
  flowT-=dt;if(flowT<=0){flowT=.4;buildFlow()}
  for(let i=noises.length-1;i>=0;i--){noises[i].life-=dt;if(noises[i].life<=0)noises.splice(i,1)}
  for(const op of OUTPOSTS){
    if(op.taken){op.alertState='CLEARED';continue}
    if(!op.alertState)op.alertState='CALM';
    if(op.alertState==='ALERT'){
      op.alertT=(op.alertT||0)+dt;
      const engaged=op.enemies.filter(x=>x.alive&&(x.state==='COMBAT'||x.state==='SEARCH')).length;
      if(op.alertT>5&&engaged>0)raiseAlert(op,'ALARM');
    }
    if(op.alertState==='ALARM'){
      op.radioCd=(op.radioCd||0)-dt;
      if(op.radioCd<=0&&(op.reinforcementCount||0)<2){op.radioCd=22;op.reinforcementCount=(op.reinforcementCount||0)+1;spawnOutpostReinforcements(op)}
    }
    op.broadcastT=(op.broadcastT||0)-dt;
    if(op.broadcastT<=0&&(op.alertState==='ALERT'||op.alertState==='ALARM')){
      op.broadcastT=2.5;
      const src=op.enemies.find(x=>x.alive&&x.state==='COMBAT'&&x.lastKnownPos);
      if(src)broadcastToSquad(src,src.lastKnownPos);
    }
  }
  for(const e of enemies){
    if(!e.alive)continue;
    if(e.hurtT>0)e.hurtT-=dt;
    if(e.recentDmgT>0)e.recentDmgT-=dt;else e.recentDmg=0;
    if(e.atkCd>0)e.atkCd-=dt;
    if(e.shoutT>0)e.shoutT-=dt;
    if(e.reinforceT>0)e.reinforceT-=dt;
    if(e.stateT===undefined)e.stateT=0;
    e.stateT+=dt;
    if(e.outpost&&e.outpost.taken){e.alive=false;continue}
    if(!e.state)e.state='PATROL';
    const distHome=e.homeX!==undefined?Math.hypot(e.x-e.homeX,e.y-e.homeY):0;
    const outOfLeash=e.leash!==undefined&&distHome>e.leash;
    const sightMul=weather==='fog'?0.5:weather==='rain'?0.75:weather==='sandstorm'?0.6:1;
    const sightR=e.sight*sightMul;
    let tgtX=P.x,tgtY=P.y,tgtAlly=null;
    if(e.state==='COMBAT'||e.state==='SEARCH'||e.state==='SUSPICIOUS'){
      let bestAllyD=Infinity;
      for(const a of allies){
        if(!a.alive||!a.following)continue;
        const ad=Math.hypot(a.x-e.x,a.y-e.y);
        if(ad<sightR&&ad<bestAllyD&&los(e.x,e.y,a.x,a.y)){
          const pd=Math.hypot(P.x-e.x,P.y-e.y);
          if(ad<pd*0.9){tgtX=a.x;tgtY=a.y;tgtAlly=a;bestAllyD=ad}
        }
      }
    }
    const dx=tgtX-e.x,dy=tgtY-e.y,dist=Math.hypot(dx,dy)||0.001;
    const angleToP=Math.atan2(dy,dx);
    let angleDiff=angleToP-e.face;
    while(angleDiff>Math.PI)angleDiff-=Math.PI*2;
    while(angleDiff<-Math.PI)angleDiff+=Math.PI*2;
    const inFOV=Math.abs(angleDiff)<e.fov/2;
    const clearLOS=!outOfLeash&&dist<sightR&&inFOV&&los(e.x,e.y,tgtX,tgtY);
    const visRange=dist<sightR;
    const see=clearLOS||(visRange&&inFOV);
    if(e.state!=='COMBAT'&&e.state!=='FLEE'){
      if(clearLOS)e.detect=Math.min(1,(e.detect||0)+dt*(1+(1-dist/sightR)*2.5));
      else e.detect=Math.max(0,(e.detect||0)-dt*0.5);
      if(e.detect<1&&noises.length){
        for(const n of noises){const nd=Math.hypot(e.x-n.x,e.y-n.y);if(nd<n.radius&&nd<e.leash){e.detect=Math.max(e.detect,0.55);e.lastNoise={x:n.x,y:n.y}}}
      }
    }
    if(outOfLeash){
      const hdx=e.homeX-e.x,hdy=e.homeY-e.y,hd=Math.hypot(hdx,hdy)||1;
      moveE(e,hdx/hd*e.speed*1.5*dt,hdy/hd*e.speed*1.5*dt);
      e.face=Math.atan2(hdy,hdx);
      e.detect=Math.max(0,(e.detect||0)-dt);
      if(e.state==='COMBAT')setState(e,'SEARCH');
      e.wt=(e.wt||0)+dt;continue;
    }
    const per={see,clearLOS,dist,tgtX,tgtY,dx,dy,angleToP,tgtAlly,inFOV,sightR};
    if(e.state==='PATROL'||e.state==='IDLE')handlePatrolState(e,dt,per);
    else if(e.state==='SUSPICIOUS')handleSuspiciousState(e,dt,per);
    else if(e.state==='SEARCH')handleSearchState(e,dt,per);
    else if(e.state==='COMBAT')handleCombatState(e,dt,per);
    else if(e.state==='FLEE')handleFleeState(e,dt);
    e.wt=(e.wt||0)+dt;
  }
}
function updAllies(dt){
 for(const a of allies){
  if(!a.alive)continue;
  if(a.atkCd>0)a.atkCd-=dt;
  if(!a.following)continue;
  const pdx=P.x-a.x,pdy=P.y-a.y,pd=Math.hypot(pdx,pdy);
  if(pd>2.2){
   const ox=a.x,oy=a.y;
   if(pd>0.01){const dx=pdx/pd,dy=pdy/pd;
    if(canStandProp(a.x+dx*a.speed*dt,a.y,.3))a.x+=dx*a.speed*dt;
    if(canStandProp(a.x,a.y+dy*a.speed*dt,.3))a.y+=dy*a.speed*dt}
   const moved=Math.hypot(a.x-ox,a.y-oy);
