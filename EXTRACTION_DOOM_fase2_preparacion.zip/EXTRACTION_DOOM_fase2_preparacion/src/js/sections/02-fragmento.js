function generateOutpostMask(op){
  const[x0,y0,x1,y1]=getBlockBounds(op.block[0],op.block[1]);
  const pad=1;
  const px0=x0+pad,py0=y0+pad,px1=x1-pad,py1=y1-pad;
  const w=px1-px0+1,h=py1-py0+1;
  op.maskX=px0;op.maskY=py0;op.maskW=w;op.maskH=h;
  const mask=new Uint8Array(w*h);
  const rng=mulberry32((MAP_SEED^(op.block[0]*73856093)^(op.block[1]*19349663)^0xABCDEF)>>>0);
  if(op.tier===1){
    mask.fill(1);
  } else if(op.tier===2){
    const cutSize=Math.max(3,Math.min(w,h)-6)+Math.floor(rng()*3);
    const corner=Math.floor(rng()*4);
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){
      let cut=false;
      if(corner===0)cut=(x>=w-cutSize&&y<cutSize);
      else if(corner===1)cut=(x>=w-cutSize&&y>=h-cutSize);
      else if(corner===2)cut=(x<cutSize&&y>=h-cutSize);
      else cut=(x<cutSize&&y<cutSize);
      mask[y*w+x]=cut?0:1;
    }
  } else {
    const cutSize=Math.max(2,Math.floor(Math.min(w,h)*0.3));
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){
      const tlx=Math.max(0,cutSize-x);
      const tly=Math.max(0,cutSize-y);
      const trx=Math.max(0,x-(w-1-cutSize));
      const blx=Math.max(0,cutSize-x);
      const bly=Math.max(0,y-(h-1-cutSize));
      const bry=Math.max(0,y-(h-1-cutSize));
      const trY=Math.max(0,cutSize-y);
      const brx=Math.max(0,x-(w-1-cutSize));
      const corners=[tlx+tly,trx+trY,blx+bly,brx+bry];
      let sum=0;
      for(const c of corners)if(c>0)sum=Math.max(sum,c);
      if(sum>cutSize)mask[y*w+x]=0;
      else mask[y*w+x]=1;
    }
  }
  op.mask=mask;
  op.perimeter=[];op.interiorCells=[];
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){
    if(!mask[y*w+x])continue;
    let isEdge=false;
    const dirs=[[1,0],[-1,0],[0,1],[0,-1]];
    for(const[dx,dy]of dirs){
      const nx=x+dx,ny=y+dy;
      if(nx<0||ny<0||nx>=w||ny>=h||!mask[ny*w+nx]){isEdge=true;break}
    }
    if(isEdge)op.perimeter.push({mx:x,my:y});
    else op.interiorCells.push({mx:x,my:y});
  }
  if(op.interiorCells.length===0){
    op.interiorCells=op.perimeter.slice();
    op.perimeter=[];
  }
  let cxm=0,cym=0;
  for(const c of op.interiorCells){cxm+=c.mx;cym+=c.my}
  cxm/=op.interiorCells.length;cym/=op.interiorCells.length;
  op.centerMX=cxm;op.centerMY=cym;
  op.x=op.maskX+cxm+0.5;
  op.y=op.maskY+cym+0.5;
  let maxR=0;
  for(const c of op.interiorCells){const d=Math.hypot(c.mx-cxm,c.my-cym);if(d>maxR)maxR=d}
  op.r=maxR+1;
}
function isInsideMask(op,wx,wy){
  const mx=Math.floor(wx)-op.maskX;
  const my=Math.floor(wy)-op.maskY;
  if(mx<0||my<0||mx>=op.maskW||my>=op.maskH)return false;
  return op.mask[my*op.maskW+mx]===1;
}
function maskCellToWorld(op,c){return{x:op.maskX+c.mx+0.5,y:op.maskY+c.my+0.5}}

const fortProps=[],fortDecos=[],fortTowers=[];
function addFortProp(x,y,r,spr,ww,wh,z0){fortProps.push({x,y,r});if(spr)fortDecos.push({x,y,spr,wh:wh||0.6,ww:ww||0.9,z0:z0||0})}
function addFortDeco(x,y,spr,wh,ww,z0){fortDecos.push({x,y,spr,wh,ww,z0:z0||0})}

function fortifyOutpost(op){
  generateOutpostMask(op);
  const rng=mulberry32((MAP_SEED^(op.block[0]*73856093)^(op.block[1]*19349663)^(op.tier*99991))>>>0);
  const isHeavy=op.tier===3,isMed=op.tier===2,isLight=op.tier===1;
  const wallType=isHeavy?6:5;
  const wallGateSpr=isHeavy?sGate:sGateLight;

  // ==== PISO MILITAR dentro de la máscara ====
  for(let y=0;y<op.maskH;y++)for(let x=0;x<op.maskW;x++){
    if(op.mask[y*op.maskW+x]){
      const wx=op.maskX+x,wy=op.maskY+y;
      gmap[wy*MW+wx]=6; // concreto militar
    }
  }

  const numGates=isLight?3:isMed?2:2;
  const shuffled=op.perimeter.slice();
  for(let i=shuffled.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[shuffled[i],shuffled[j]]=[shuffled[j],shuffled[i]];}
  const gates=[];
  for(const cell of shuffled){
    if(gates.length>=numGates)break;
    let ok=true;
    for(const g of gates)if(Math.abs(g.mx-cell.mx)+Math.abs(g.my-cell.my)<5){ok=false;break}
    if(ok)gates.push(cell);
  }
  op.gates=gates;
  const gateKeys=new Set(gates.map(g=>g.my*op.maskW+g.mx));

  // ==== Muros con variantes dañadas ====
  for(const cell of op.perimeter){
    const wx=op.maskX+cell.mx,wy=op.maskY+cell.my;
    if(gateKeys.has(cell.my*op.maskW+cell.mx)){
      addFortDeco(wx+0.5,wy+0.5,wallGateSpr,0.7,1.0,0);
    } else {
      // Tier 3: 20% muros dañados (tipo 7)
      // Tier 2: muros tipo 5 (sacos)
      // Tier 1: muros tipo 5 (sacos)
      let wt=wallType;
      if(isHeavy&&rng()<0.20)wt=7;
      else if(isMed&&rng()<0.15)wt=7;
      map[wy*MW+wx]=wt;
    }
  }
  if(isMed||isHeavy){
    const wireZ=isHeavy?1.4:1.0,wireWH=isHeavy?0.9:0.55;
    for(const cell of op.perimeter){
      if(gateKeys.has(cell.my*op.maskW+cell.mx))continue;
      const wx=op.maskX+cell.mx,wy=op.maskY+cell.my;
      addFortDeco(wx+0.5,wy+0.5,sWire,wireWH,1.0,wireZ);
    }
  }

  // ==== Torres con reflector ====
  const quads=[
    {qx:-1,qy:-1,best:null,bestD:0},
    {qx:1,qy:-1,best:null,bestD:0},
    {qx:-1,qy:1,best:null,bestD:0},
    {qx:1,qy:1,best:null,bestD:0},
  ];
  for(const cell of op.perimeter){
    const dx=cell.mx-op.centerMX,dy=cell.my-op.centerMY;
    const qx=dx<0?-1:1,qy=dy<0?-1:1;
    const d=Math.hypot(dx,dy);
    for(const q of quads)if(q.qx===qx&&q.qy===qy&&d>q.bestD){q.best=cell;q.bestD=d}
  }
  const numTowers=isLight?1:isMed?2:4;
  for(let i=0;i<numTowers;i++){
    const q=quads[i];if(!q.best)continue;
    const wx=op.maskX+q.best.mx,wy=op.maskY+q.best.my;
    map[wy*MW+wx]=0;
    addFortProp(wx+0.5,wy+0.5,0.5,sTower,1.4,3.0,0);
    fortTowers.push({x:wx+0.5,y:wy+0.5,z:3.4,phase:rng()*6.28,speed:0.5+rng()*0.4,radius:4+rng()*2});
  }

