#!/usr/bin/env python3
"""Reconstruye dist/game.js concatenando fragmentos en orden, sin alterar su contenido."""
from pathlib import Path
import re, subprocess, sys
ROOT = Path(__file__).resolve().parent
sections = sorted((ROOT / "src" / "js" / "sections").glob("*-fragmento.js"))
if not sections:
    raise SystemExit("ERROR: no se encontraron fragmentos en src/js/sections/")
source = "".join(p.read_text(encoding="utf-8") for p in sections)
(ROOT / "dist" / "game.js").write_text(source, encoding="utf-8")
print(f"Generado dist/game.js desde {len(sections)} fragmentos.")
try:
    r = subprocess.run(["node", "--check", str(ROOT / "dist" / "game.js")], check=False)
except FileNotFoundError:
    print("AVISO: Node.js no está instalado; se omitió la comprobación de sintaxis.")
    sys.exit(0)
if r.returncode:
    raise SystemExit("ERROR: la comprobación de sintaxis JavaScript falló.")
print("OK: sintaxis JavaScript válida.")
