 let y=H+Math.abs(Math.cos(P.bob))*H*.012+(P.muzzle>0?H*.05:0);
 let rOff=0;if(P.reloading>0&&P.reloadTotal>0){const t=1-P.reloading/P.reloadTotal;rOff=Math.sin(t*Math.PI)*90*u}
 let mAng=0,mOffX=0;if(P.meleeAnim>0){const t=1-P.meleeAnim/0.28;mAng=Math.sin(t*Math.PI)*0.45;mOffX=Math.sin(t*Math.PI)*8*u}
 y+=rOff;
 if(mAng||mOffX){ctx.save();ctx.translate(cx+mOffX,y);ctx.rotate(mAng);ctx.translate(-cx,-y)}
 const isRocketWeapon=WEAPONS[P.weapon].rocket===true;
 for(const r of WP[P.weapon]){if(r[5]&&isRocketWeapon&&P.mag[P.weapon]<=0&&!(P.reloading>0&&P.reloadTotal>0&&(1-P.reloading/P.reloadTotal)>.5))continue;ctx.fillStyle=r[0];ctx.fillRect(cx+r[1]*u,y-r[2]*u,r[3]*u,r[4]*u)}
 if(P.muzzle>0){const m=P.muzzle/.09,fy=y-[72,84,100,104,105,108,113][P.weapon]*u,r=(18+Math.random()*14)*u*m,g=ctx.createRadialGradient(cx,fy,0,cx,fy,r);
  g.addColorStop(0,'rgba(255,255,230,'+.95*m+')');g.addColorStop(.4,'rgba(255,190,60,'+.75*m+')');g.addColorStop(1,'rgba(255,80,0,0)');
  ctx.fillStyle=g;ctx.beginPath();ctx.arc(cx,fy,r,0,6.2832);ctx.fill();
  if(isRocketWeapon){const by2=y-24*u,rb=(40+Math.random()*20)*u*m,g2=ctx.createRadialGradient(cx,by2,0,cx,by2,rb);
   g2.addColorStop(0,'rgba(255,240,200,'+Math.min(1,.9*m)+')');g2.addColorStop(.35,'rgba(255,150,50,'+Math.min(1,.6*m)+')');g2.addColorStop(1,'rgba(120,120,120,0)');
   ctx.fillStyle=g2;ctx.beginPath();ctx.arc(cx,by2,rb,0,6.2832);ctx.fill()}}
 if(mAng||mOffX)ctx.restore()}
const EC={soldier:'#f33',heavy:'#f60',sniper:'#f0f',shotgunner:'#fa0',officer:'#ff0',dog:'#f88',commander:'#fff'};
function minimap(){
 mctx.setTransform(1,0,0,1,0,0);
 mctx.clearRect(0,0,64,64);
 mctx.drawImage(mmBase,0,0,MW,MH,0,0,64,64);
 mctx.setTransform(64/MW,0,0,64/MH,0,0);
 for(const op of OUTPOSTS){
  let color,fillColor;
  if(op.taken){color='#7dff8f';fillColor='rgba(125,255,143,.35)'}
  else if(op.alertState==='ALARM'){color='#ff2020';fillColor='rgba(255,30,30,.45)'}
  else if(op.alertState==='ALERT'){color='#ffd24a';fillColor='rgba(255,210,74,.35)'}
  else if(op.tier===3){color='#ff3a3a';fillColor='rgba(255,60,60,.35)'}
  else if(op.tier===2){color='#ffb040';fillColor='rgba(255,150,60,.30)'}
  else{color='#9fd8ff';fillColor='rgba(120,180,255,.28)'}
  if(op.mask){
    mctx.fillStyle=fillColor;
    for(let my=0;my<op.maskH;my++)for(let mx=0;mx<op.maskW;mx++){
      if(op.mask[my*op.maskW+mx])mctx.fillRect(op.maskX+mx,op.maskY+my,1,1);
    }
    mctx.fillStyle=color;
    for(const cell of op.perimeter){
      mctx.fillRect(op.maskX+cell.mx,op.maskY+cell.my,1,1);
    }
    // NUEVO: destello si está revelado (post-toma) o en alerta
    if(revealedOutposts.has(op.id)&&!op.taken){
      mctx.strokeStyle='#9fd8ff';mctx.lineWidth=1;
      mctx.setLineDash([2,2]);
      mctx.strokeRect(op.maskX-0.5,op.maskY-0.5,op.maskW+1,op.maskH+1);
      mctx.setLineDash([]);
    }
  }
 }
 for(const e of enemies)if(e.alive&&(e.x-P.x)**2+(e.y-P.y)**2<400){
  mctx.fillStyle=EC[e.type]||'#f33';const sz=e.boss?3:2;mctx.fillRect(e.x-sz/2,e.y-sz/2,sz,sz);
  if(e.objective){mctx.strokeStyle='#ffd24a';mctx.lineWidth=1;mctx.strokeRect(e.x-2.5,e.y-2.5,5,5)}
 }
 for(const a of allies){if(!a.alive)continue;
  if((a.x-P.x)**2+(a.y-P.y)**2<400){mctx.fillStyle=a.following?'#5bd8ff':'#9cf';mctx.fillRect(a.x-1.5,a.y-1.5,3,3);
   if(!a.following){mctx.strokeStyle='#9fd8ff';mctx.lineWidth=1;mctx.strokeRect(a.x-2.5,a.y-2.5,5,5)}}}
 for(const c of corpses){if(c.perm)continue;
  if(c.cache){mctx.fillStyle='#ffd24a';mctx.fillRect(c.x-1.5,c.y-1.5,3,3)}
  else{mctx.fillStyle='#fd4';mctx.fillRect(c.x,c.y,1,1)}}
 for(const box of SAFE_BOXES)if(!box.opened){mctx.fillStyle='#d6a343';mctx.fillRect(box.x-1.2,box.y-1.2,2.4,2.4)}
 for(const s of smokes){mctx.fillStyle='rgba(200,200,200,.6)';mctx.beginPath();mctx.arc(s.x,s.y,s.radius,0,6.28);mctx.fill()}
 for(const f of fires){mctx.fillStyle='rgba(255,120,30,.6)';mctx.beginPath();mctx.arc(f.x,f.y,f.radius,0,6.28);mctx.fill()}
 mctx.fillStyle='#4f8';mctx.fillRect(BEACON.x-1.5,BEACON.y-1.5,3,3);
 mctx.fillStyle='#fff';mctx.fillRect(P.x-1.5,P.y-1.5,3,3);
 mctx.strokeStyle='#fff';mctx.beginPath();mctx.moveTo(P.x,P.y);mctx.lineTo(P.x+Math.cos(P.a)*5,P.y+Math.sin(P.a)*5);mctx.stroke();
 mctx.setTransform(1,0,0,1,0,0);
}
function hud(f){
 const hp=Math.ceil(P.hp);if(f||hp!==lastHp){$('hpv').textContent=hp;$('hpv').className='val'+(hp<=30?' low':'');$('hpfill').style.width=hp+'%';lastHp=hp}
 const w=WEAPONS[P.weapon],wi=P.weapon;
 let amText,amLow=false;
 if(w.ammo){amText=P.mag[wi]+' / '+P[w.ammo];amLow=P.mag[wi]<=Math.max(1,Math.floor(w.magMax*0.25))}
 else amText='∞';
 const rocketReady=w.rocket===true&&P.mag[wi]>0;
 if(f||amText!==lastAm){
   $('amv').textContent=amText;
   $('amv').className='val'+(amLow?' low':'')+(rocketReady?' rocket-ready':'');
   lastAm=amText;
 }
 if(f||P.weapon!==lastW){$('wnv').textContent=w.name;lastW=P.weapon}
 const rb=$('reloadBar'),rl=$('reloadLbl');
 if(P.reloading>0){rb.classList.add('on');rl.classList.add('on');$('reloadFill').style.width=Math.round((1-P.reloading/P.reloadTotal)*100)+'%'}
 else{if(rb.classList.contains('on')){rb.classList.remove('on');rl.classList.remove('on')}}
 $('caliberLbl').textContent=w.caliber||'';const sw=$('btnSwap');const wantReload=w.ammo&&P.mag[wi]<=0&&P[w.ammo]>0;const swTxt=wantReload?'RECARGAR':'ARMA';
 if(swTxt!==lastBtnSwap){sw.textContent=swTxt;lastBtnSwap=swTxt}
 const fragN=P.throwables.frag||0,smkN=P.throwables.smoke||0,molN=P.throwables.molotov||0;
 const thTxt='💣×'+fragN+' · 💨×'+smkN+' · 🔥×'+molN;
 if(f||thTxt!==lTh){$('thl').textContent=thTxt;lTh=thTxt}
 const btnT=$('btnThrow');
 const cT=P.currentThrow||'frag';const cN=P.throwables[cT]||0;
 const icon=cT==='frag'?'💣':cT==='smoke'?'💨':'🔥';
 const bTxt=icon+(cN>0?'×'+cN:'');
 if(btnT.textContent!==bTxt){btnT.textContent=bTxt;btnT.classList.toggle('empty',cN===0)}
 const fd=Math.ceil(P.food),wt=Math.ceil(P.water);
 if(f||fd!==lF||wt!==lW){$('foodfill').style.width=fd+'%';$('waterfill').style.width=wt+'%';$('fb').className=fd<=25?'nb low':'nb';$('wb').className=wt<=25?'nb low':'nb';lF=fd;lW=wt}
 const rem=Math.max(0,Math.ceil(EXT_AT-gt));
 if(f||rem!==lO){$('objective').textContent=rem?'EXTRACCIÓN EN '+((rem/60)|0)+':'+('0'+rem%60).slice(-2):'EXTRACCIÓN ACTIVA · BALIZA VERDE ↘';lO=rem}
 const wv=Math.round(weight()*10);if(f||wv!==lWt){$('wtl').textContent=(wv/10)+'/'+MAXW+' KG';$('wtl').style.color=wv>MAXW*9?'#ff6a5a':'';lWt=wv}
 if(f)armorHud();
 updCompass();
 const el=$('objList');
 if(el){
  let html='<div class="hdr">OBJETIVOS</div>';
  if(objectives.length===0)html+='<div class="obj">—</div>';
  for(const o of objectives)html+='<div class="obj'+(o.done?' done':'')+'">'+(o.done?'✓ ':'○ ')+o.label+'</div>';
  if(html!==lastObjHtml){el.innerHTML=html;lastObjHtml=html}
 }}
let mt=null;function msg(t,c){const m=$('msg');m.textContent=t;m.style.color=c||'#ffe080';m.classList.add('show');clearTimeout(mt);mt=setTimeout(()=>m.classList.remove('show'),1100)}
function screen(id){if(id&&id!=='gameScreen'&&safeCrack){cancelSafeCrack();$('safeCrackUI').style.display='none'}document.querySelectorAll('.overlay').forEach(o=>o.classList.remove('on'));if(id)$(id).classList.add('on')}

function killEnemy(e,distance,method){
 if(!e.alive)return;e.alive=false;kills++;
 const conf=ETYPES[e.type];addXp((conf&&conf.xp)||10);
 SFX.enemyDie();puff(e.x,e.y,14,C(210,30,30));
 if(decals.length<40)decals.push({x:e.x,y:e.y,spr:sBlood,wh:.18,ww:.18});
 corpses.push({x:e.x,y:e.y,spr:e.corpse,loot:e.loot.slice(),wh:e.height*.45,ww:e.height*.45*e.corpse.w/e.corpse.h,z0:0});
 const key='kills_'+e.type;if(meta.stats[key]!==undefined)meta.stats[key]++;
 updateDailyProgress('kills',1);
 if(P.weapon===2||P.weapon===3||P.weapon===4||P.weapon===5)updateDailyProgress('rifle_kills',1);
 if(kills>=1)unlockAchievement('first_blood');
 if(method==='melee'){runStats.meleeKills++;meta.achievementProgress.meleeKills++;if(meta.achievementProgress.meleeKills>=10)unlockAchievement('berserker')}
 if(distance!==undefined&&distance>20){runStats.longKills++;meta.achievementProgress.longKills++;if(meta.achievementProgress.longKills>=5)unlockAchievement('sniper_ace')}
 if(e.type==='commander')unlockAchievement('commander_down');
 if(e.objective){const obj=objectives.find(o=>o.id==='kill_officer');if(obj&&!obj.done){obj.done=true;msg('¡OFICIAL ELIMINADO!','#7dff8f');meta.stats.objectivesDone++;updateDailyProgress('objectives',1)}}
 checkOutpostCleared(e);saveMeta();
}
function fragExplode(x,y){SFX.boom();if(navigator.vibrate)navigator.vibrate(50);
 puff(x,y,30,C(255,180,40));puff(x,y,15,C(255,240,150));puff(x,y,20,C(80,80,80));
 let killCount=0;
 for(const e of enemies){if(!e.alive)continue;const d=Math.hypot(e.x-x,e.y-y);
  if(d<4.5&&los(x,y,e.x,e.y)){const dm=Math.round(90*(1-d/4.5));if(dm>0){const before=e.alive;hit(e,dm,false);if(before&&!e.alive)killCount++}}}
 if(killCount>=3)unlockAchievement('demolisher');
 for(const a of allies){if(!a.alive)continue;const d=Math.hypot(a.x-x,a.y-y);
  if(d<4.5){a.hp-=Math.round(60*(1-d/4.5));if(a.hp<=0){a.hp=0;a.alive=false;msg('¡ALIADO CAÍDO!','#ff6a5a')}}}
 const dp=Math.hypot(P.x-x,P.y-y);if(dp<4.0)hurt(Math.max(1,Math.round(50*(1-dp/4.0))),x,y)}
function spawnSmoke(x,y){if(smokes.length>=5)smokes.shift();
 smokes.push({x,y,life:8,maxLife:8,radius:3.5,seed:Math.random()*100});SFX.smoke()}
function spawnFire(x,y){fires.push({x,y,life:3.5,maxLife:3.5,radius:2.5});SFX.fire();if(navigator.vibrate)navigator.vibrate(30)}
function updateThrowables(dt){for(let i=throwables.length-1;i>=0;i--){const g=throwables[i];
 g.life-=dt;g.age+=dt;if(g.type==='frag')g.fuse-=dt;g.vz-=12*dt;g.z+=g.vz*dt;
 const nx=g.x+g.vx*dt,ny=g.y+g.vy*dt;let hitWall=false;
