function makeLoot(type){type=type||'soldier';const l=[],r=Math.random;
 const add=(id,n)=>{const it=l.find(x=>x.id===id);if(it)it.count+=(n||1);else l.push({id,count:n||1})};
 add(['shells','bullets','ammo9','ammo76239'][r()*4|0],1);
 if(r()<.4)add(r()<.7?'bandage':'medkit',1);
 if(r()<.35)add(FOODS[r()*FOODS.length|0],1);
 if(r()<.25)add(['frag','smoke','molotov'][r()*3|0],1);
 if(type==='heavy'){if(r()<.4)add(['rifle','shotgun','ak47'][r()*3|0],1);if(r()<.3)add(armorRoll(),1);if(r()<.3)add('rockets',1);if(r()<.18)add('ammo76239',2)}
 else if(type==='sniper'){if(r()<.65)add('m24',1);if(r()<.6)add('ammo76251',2)}
 else if(type==='shotgunner'){if(r()<.6)add('shotgun',1);if(r()<.5)add('shells',2)}
 else if(type==='officer'){if(r()<.5)add(armorRoll(),1);if(r()<.4)add(['rifle','shotgun','ak47'][r()*3|0],1);if(r()<.5)add('bullets',2);if(r()<.12)add('ammo9',2)}
 else if(type==='commander'){add(r()<.5?'mg42':'ak47',1);add('rockets',2);add('medkit',1);add('vest3',1);add('frag',3);add(r()<.5?'ammo792':'ammo76239',3)}
 return l}
function contLoot(t){const l=[],r=Math.random,pk=a=>a[r()*a.length|0],add=id=>l.push({id,count:1});const thr=['frag','smoke','molotov'];
 if(t==='s'){for(let i=0,n=2+(r()*2|0);i<n;i++)add(pk(FOODS));if(r()<.18)add(pk(thr))}
 else if(t==='c'){add(pk(FOODS));if(r()<.5)add(pk(['bandage','shells','bullets','ammo9','ammo76239','water']));if(r()<.28)add(pk(thr))}
 else if(t==='b'){add(pk(FOODS));if(r()<.6)add(pk(['bandage','medkit','bullets','shells']));if(r()<.32)add(pk(thr))}
 else if(t==='l'){add(pk(['bullets','shells','ammo9','ammo76239','bandage','medkit']));if(r()<.5)add(pk(FOODS));if(r()<.06)add('rocketl');
  if(r()<.55)add(pk(thr));if(r()<.3){add(pk(thr));if(r()<.4)add(pk(thr))}}
 else{add(pk(['bullets','shells']));add(pk(['medkit','bandage']));if(r()<.55)add('rockets');if(r()<.22)add('rocketl');if(r()<.3)add(pk(['rifle','shotgun']));
  if(r()<.75){add(pk(thr));if(r()<.5)add('frag');if(r()<.4)add(pk(thr))}}
 if(r()<{s:.12,c:.22,b:.18,l:.35,m:.6}[t])add(armorRoll());
 return l}
function makeOutpostReward(tier){
 const l=[],r=Math.random;
 const add=(id,n)=>{const it=l.find(x=>x.id===id);if(it)it.count+=(n||1);else l.push({id,count:n||1})};
 if(tier===1){
  add('shells',2+((r()*2)|0));add('bullets',2+((r()*2)|0));if(r()<.35)add('ammo9',1);
  if(r()<.6)add('bandage',1);if(r()<.4)add('medkit',1);
  if(r()<.5)add(FOODS[(r()*FOODS.length)|0],1);
  if(r()<.3)add(['frag','smoke','molotov'][(r()*3)|0],1);
 } else if(tier===2){
  add('shells',3+((r()*3)|0));add('bullets',3+((r()*3)|0));if(r()<.4)add('ammo76239',2);
  if(r()<.7)add('medkit',1+(r()<.3?1:0));
  if(r()<.5)add('frag',1);if(r()<.3)add('smoke',1);
  if(r()<.5)add('vest'+(1+((r()*2)|0)),1);
  if(r()<.4)add('helm'+(1+((r()*2)|0)),1);
  if(r()<.35)add(r()<.5?'rifle':'shotgun',1);
  if(r()<.2)add('rockets',1);
 } else {
  add('shells',4+((r()*3)|0));add('bullets',4+((r()*3)|0));add('ammo792',2+((r()*2)|0));if(r()<.35)add('ammo76239',2);if(r()<.25)add('ammo76251',1);
  add('medkit',2);add('frag',2);add('smoke',1);
  if(r()<.7)add('rockets',2);
  add('vest3',1);
  if(r()<.6)add('helm3',1);else if(r()<.5)add('helm2',1);
  add(r()<.35?'mg42':r()<.65?'ak47':r()<.8?'rifle':'rocketl',1);
  if(r()<.5)add('vest2',1);
  if(r()<.4)add('shotgun',1);
 }
 return l}

function computeInteriorProps(seed){
  const rng=mulberry32((seed^0xA5A5A5A5)>>>0);
  CONTS=[];FURNITURE=[];
  const FURN_TYPES=['sofa','sofa2','bed','bed2','table','rug'];
  for(const[x0,y0,x1,y1]of BUILDINGS){
    const iw=x1-x0-1,ih=y1-y0-1;
    if(iw<2||ih<2)continue;
    const nC=1+Math.floor(rng()*3);
    for(let i=0;i<nC;i++){
      const px=x0+1+Math.floor(rng()*iw),py=y0+1+Math.floor(rng()*ih);
      const types=['s','c','b','l','m'];
      CONTS.push([px,py,types[Math.floor(rng()*types.length)]]);
    }
    const nF=Math.floor(rng()*2);
    for(let i=0;i<nF;i++){
      const px=x0+1+Math.floor(rng()*iw),py=y0+1+Math.floor(rng()*ih);
      FURNITURE.push([px,py,FURN_TYPES[Math.floor(rng()*FURN_TYPES.length)]]);
    }
  }
}
function computePickupSpots(seed){
  const rng=mulberry32((seed^0x9E3779B9)>>>0);
  PICKUP_SPOTS=[];
  const types=['medkit','shells','bullets'];
  const sprs={medkit:sMed,shells:sShell,bullets:sBul};
  let placed=0,tries=0;
  while(placed<14&&tries<500){
    tries++;
    const x=2.5+Math.floor(rng()*(MW-5)),y=2.5+Math.floor(rng()*(MH-5));
    if(isWall(x,y))continue;
    if(isInsideBuilding(x,y))continue;
    let tooClose=false;
    for(const p of PICKUP_SPOTS)if(Math.hypot(p.x-x,p.y-y)<4){tooClose=true;break}
    if(tooClose)continue;
    const type=types[Math.floor(rng()*types.length)];
    PICKUP_SPOTS.push({x,y,type,spr:sprs[type]});
    placed++;
  }
}

function computeOutpostWaypoints(op){
  const validCells=op.interiorCells.filter(c=>{
    const wx=op.maskX+c.mx+0.5,wy=op.maskY+c.my+0.5;
    return canStandProp(wx,wy,0.4)&&!isWall(wx,wy);
  });
  if(validCells.length===0){op.waypoints=[{x:op.x,y:op.y}];return;}
  const n=Math.min(8,Math.max(4,Math.floor(validCells.length/3)));
  const step=Math.max(1,Math.floor(validCells.length/n));
  const wps=[];
  for(let i=0;i<validCells.length&&wps.length<n;i+=step){
    wps.push(maskCellToWorld(op,validCells[i]));
  }
  op.waypoints=wps;
}

function spawnCommander(){
 const conf=ETYPES.commander;
 let cx=BEACON.x,cy=BEACON.y;
 for(let r=0;r<12;r++){
  const a=Math.random()*6.28,tx=BEACON.x+Math.cos(a)*(6+r),ty=BEACON.y+Math.sin(a)*(6+r);
  if(tx>1&&ty>1&&tx<MW-1&&ty<MH-1&&canStand(tx,ty,.4)&&!isWall(tx,ty)){cx=tx;cy=ty;break}
 }
 const hpMul=meta.nightmareActive?1.5:1,dmgMul=meta.nightmareActive?1.5:1;
 enemies.push({x:cx,y:cy,type:'commander',hp:Math.round(conf.hp*hpMul),maxHp:Math.round(conf.hp*hpMul),speed:conf.speed,dmg:Math.round(conf.dmg*dmgMul),
  fr:conf.fr,corpse:conf.corpse,atkCd:1,hurtT:0,alive:true,wt:0,wander:0,wanderT:0,loot:makeLoot('commander'),
  height:conf.h,aimT:0,shoutT:0,reinforceT:conf.reinforceCd,recentDmg:0,recentDmgT:0,zigzagT:0,zigzagDir:1,
  stop:conf.stop,boss:true,sniper:false,meleeType:false,pellets:1,minDist:0,maxDist:30,coverTarget:null,
  face:Math.random()*6.28,detect:1,fov:conf.fov,sight:conf.sight,name:conf.name,color:conf.color,
  state:'COMBAT',stateT:0,lastKnownPos:{x:P.x,y:P.y}});
 total++;
 msg('¡EL COMANDANTE HA LLEGADO!','#ff2020');
}
function spawnOutpostEnemies(outpost){
 const count=outpost.min+Math.floor(Math.random()*(outpost.max-outpost.min+1));
 const spawned=[];
 const hpMul=meta.nightmareActive?1.5:1,dmgMul=meta.nightmareActive?1.5:1;
 const validCells=outpost.interiorCells.filter(c=>{
   const wx=outpost.maskX+c.mx+0.5,wy=outpost.maskY+c.my+0.5;
   return canStandProp(wx,wy,0.35)&&!isWall(wx,wy);
 });
 if(validCells.length===0)return;
 for(let i=0;i<count;i++){
  let x,y,tries=0;
  do{
   const c=validCells[Math.floor(Math.random()*validCells.length)];
   x=outpost.maskX+c.mx+0.5;
   y=outpost.maskY+c.my+0.5;
   tries++;
  } while((!canStandProp(x,y,0.35)||isWall(x,y))&&tries<20);
  if(tries>=20)continue;
  let type;
  if(outpost.tier===1)type='soldier';
  else if(outpost.tier===2)type=Math.random()<0.75?'soldier':'heavy';
  else{const roll=Math.random();
   if(roll<0.40)type='heavy';
   else if(roll<0.62)type='sniper';
   else if(roll<0.82)type='shotgunner';
   else type='officer';}
  const conf=ETYPES[type];
  const initFace=Math.random()*6.28;
  const e={x,y,type,hp:Math.round(conf.hp*hpMul),maxHp:Math.round(conf.hp*hpMul),speed:conf.speed,dmg:Math.round(conf.dmg*dmgMul),
