  // ==== Props interiores ====
  const pickInterior=()=>{
    if(op.interiorCells.length===0)return null;
    return op.interiorCells[Math.floor(rng()*op.interiorCells.length)];
  };
  const placed=new Set();
  const putProp=(spr,ww,wh,count,extraR,minDistFromCenter)=>{
    let n=0,tries=0;
    while(n<count&&tries<count*12){
      tries++;
      const c=pickInterior();if(!c)break;
      const wx=op.maskX+c.mx+0.5,wy=op.maskY+c.my+0.5;
      const key=c.mx+','+c.my;
      if(placed.has(key))continue;
      if(minDistFromCenter&&Math.hypot(wx-op.x,wy-op.y)<minDistFromCenter)continue;
      placed.add(key);
      addFortProp(wx,wy,extraR||0.4,spr,ww,wh,0);
      n++;
    }
  };
  putProp(sTent,1.5,2.0,isLight?1:isMed?2:3,0.5,1.5);
  if(isMed||isHeavy){
    addFortProp(op.x,op.y,0.75,sBunker,1.8,1.35,0);
    placed.add(Math.floor(op.centerMX)+','+Math.floor(op.centerMY));
    putProp(sBagWall,0.9,0.5,isMed?1:3,0.4,2.0);
    putProp(rng()<0.5?sCar:sCar2,1.35,0.85,1,0.55,2.5);
    // NUEVO: Generador + Antena + Mesa de mapas
    putProp(sGenerator,0.85,0.85,1,0.45,2.0);
    putProp(sAntenna,0.55,1.2,1,0.35,2.5);
    putProp(sMapTable,1.0,0.75,1,0.4,2.0);
  }
  if(isHeavy){
    putProp(sCrate,0.7,0.65,3,0.4,2.0);
    putProp(sMil,0.7,0.7,1,0.4,2.0);
    // NUEVO: barriles de combustible
    putProp(sFuelBarrel,0.6,0.7,2,0.35,2.5);
  }

  // ==== Erizos exteriores ====
  const numHedge=isLight?2:isMed?4:6;
  for(let i=0;i<numHedge;i++){
    const cell=op.perimeter[Math.floor(rng()*op.perimeter.length)];if(!cell)continue;
    const dirs=[[1,0],[-1,0],[0,1],[0,-1]];
    const dir=dirs[Math.floor(rng()*4)];
    const hx=op.maskX+cell.mx+dir[0]*2;
    const hy=op.maskY+cell.my+dir[1]*2;
    if(hx<2||hy<2||hx>=MW-2||hy>=MH-2)continue;
    if(map[hy*MW+hx]!==0)continue;
    addFortProp(hx+0.5,hy+0.5,0.4,sCzech,0.85,0.85,0);
  }
  const extraHedge=isLight?6:isMed?9:12;
  let hPlaced=0,hTries=0;
  while(hPlaced<extraHedge&&hTries<80){
    hTries++;
    const a=rng()*6.28,r=4+rng()*9;
    const hx=Math.floor(op.x+Math.cos(a)*r),hy=Math.floor(op.y+Math.sin(a)*r);
    if(hx<2||hy<2||hx>=MW-2||hy>=MH-2)continue;
    if(map[hy*MW+hx]!==0)continue;
    const g=gmap[hy*MW+hx];if(g>3)continue;
    let tooClose=false;
    for(const fp of fortProps)if(Math.hypot(fp.x-(hx+0.5),fp.y-(hy+0.5))<1.5){tooClose=true;break}
    if(tooClose)continue;
    addFortProp(hx+0.5,hy+0.5,0.4,sCzech,0.85,0.85,0);
    hPlaced++;
  }
  for(let i=0;i<numTowers;i++){
    const q=quads[i];if(!q.best)continue;
    const wx=op.maskX+q.best.mx,wy=op.maskY+q.best.my;
    for(const[dx,dy]of[[1,1],[1,-1],[-1,1],[-1,-1]]){
      const lx=wx+dx,ly=wy+dy;
      if(lx>0&&ly>0&&lx<MW-1&&ly<MH-1&&!isWall(lx,ly)){
        addFortDeco(lx+0.5,ly+0.5,sLamp,2.5,1.25,0);
        break;
      }
    }
  }
}

const BEACON={x:0,y:0};
function updateBeacon(){
  const L=MAP_LAYOUT;
  const[x0,y0,x1,y1]=getBlockBounds(L.EXTRACTION_BLOCK[0],L.EXTRACTION_BLOCK[1]);
  BEACON.x=(x0+x1)/2+0.5;BEACON.y=(y0+y1)/2+0.5;
}

const solidProps=[];
function addSolidProp(x,y,r){solidProps.push({x,y,r:r||.35})}
const pblk=new Uint8Array(MW*MH),propGrid=new Array(MW*MH).fill(null);
function rebuildPropGrid(){
  propGrid.fill(null);pblk.fill(0);
  for(const p of solidProps){
    const x0=Math.max(0,Math.floor(p.x-p.r)),x1=Math.min(MW-1,Math.floor(p.x+p.r));
    const y0=Math.max(0,Math.floor(p.y-p.r)),y1=Math.min(MH-1,Math.floor(p.y+p.r));
    for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++){
      const i=y*MW+x;(propGrid[i]||(propGrid[i]=[])).push(p);
    }
    pblk[(p.y|0)*MW+(p.x|0)]=1;
  }
}
function propBlocksAt(x,y){
  const ix=x|0,iy=y|0;
  if(ix<0||iy<0||ix>=MW||iy>=MH)return false;
  const l=propGrid[iy*MW+ix];if(!l)return false;
  for(const p of l){const dx=x-p.x,dy=y-p.y;if(dx*dx+dy*dy<p.r*p.r)return true}
  return false;
}
function canStandProp(x,y,r){if(!canStand(x,y,r))return false;return !propBlocksAt(x,y)}

let FOG=[196,212,230];
function shades(d,mul,red){
  mul=mul||1;const o=[];
  for(let s=0;s<SH;s++){
    const f=s/(SH-1),a=new Uint32Array(d.length);
    for(let i=0;i<d.length;i++){
      const c=d[i];if(!c)continue;
      let r=(c&255)*mul,g=((c>>8)&255)*mul,b=((c>>16)&255)*mul;
      if(red){r=r*.5+150;g*=.45;b*=.45}
      a[i]=C(r*f+FOG[0]*(1-f),g*f+FOG[1]*(1-f),b*f+FOG[2]*(1-f));
    }
    o.push(a);
  }
  return o;
}
function mk(fn){const d=new Uint32Array(TEX*TEX);for(let y=0;y<TEX;y++)for(let x=0;x<TEX;x++)d[y*TEX+x]=fn(x,y);return d}
const tAsph=mk((x,y)=>{const n=hash(x,y,1),n2=hash(x>>2,y>>2,2);let v=92+n*24+n2*14;
 if(Math.sin(x*.35+y*.7+hash(x>>4,y>>4,5)*10)>.94)v*=.6;if(n>.965)v*=1.5;return C(v,v*.98,v*1.03)});
const tSide=mk((x,y)=>{const px=x%16,py=y%16,n=hash(x,y,3);let v=182+n*26;if(px===0||py===0)v*=.7;if(px===1||py===1)v*=1.06;return C(v,v*.98,v*.93)});
const tGrass=mk((x,y)=>{const n=hash(x,y,7),n2=hash(x>>2,y>>2,11);let r=70+n2*30+n*18,g=135+n2*42+n*26,b=52+n2*16+n*10;
 if(n2<.14){r+=40;g-=14}if(n>.84)g+=28;return C(r,g,b)});
const tDirt=mk((x,y)=>{const n=hash(x,y,13),n2=hash(x>>1,y>>1,17);let r=150+n*40+n2*22,g=114+n*30+n2*16,b=76+n*20;if(n2>.92){r*=1.2;g*=1.2;b*=1.15}return C(r,g,b)});
const tMilFloor=mk((x,y)=>{
  const n=hash(x,y,801),n2=hash(x>>2,y>>2,802);
  let v=132+n*22+n2*12;
