  if(x%16===0||y%16===0)v*=0.72;
  if(x%16===1||y%16===1)v*=1.05;
  if(hash(x>>3,y>>3,803)>0.85)v*=0.88;
  if((x%32>=14&&x%32<=17)&&(y%4<2))v=200;
  return C(v,v*0.97,v*0.88);
});
let gSh=[shades(tAsph),shades(tSide),shades(tGrass),shades(tDirt),shades(tAsph),shades(tAsph),shades(tMilFloor)];
const tCeil=mk((x,y)=>{const n=hash(x,y,101);let r=90+n*26,g=64+n*20,b=42+n*14;
 const plank=Math.floor(y/8)%2;if(plank){r*=1.06;g*=1.06}
 if(y%8===0){r*=0.55;g*=0.55;b*=0.55}
 const gr=Math.sin(x*.28+y*.14)*8;return C(r+gr,g+gr*.7,b+gr*.4)});
let gShCeil=shades(tCeil);
const win=(x,y)=>{const wx=x%32,wy=y%32;return wx>=8&&wx<=23&&wy>=9&&wy<=22};
const tConc=mk((x,y)=>{const n=hash(x,y,19);let v=176+n*28;if(x%16===0||y%16===0)v*=.75;
 if(hash(x>>3,y>>3,25)>.88)v*=.8;
 if(win(x,y)){const wx=x%32,wy=y%32;if(wx===8||wy===9||wx===23||wy===22)return C(70,66,60);
  const sky=150+(wy-9)*5+hash(x,y,4)*20;return hash(x>>2,y>>2,8)>.85?C(30,34,44):C(sky*.55,sky*.75,sky)}
 return C(v,v*.98,v*.92)});
const tBrick=mk((x,y)=>{const off=((y>>3)%2)*8,bx=(x+off)%16,by=y%8;if(by===0||bx===0)return C(150,136,124);
 const n=hash(x,y,23);let r=176+n*30,g=84+n*22,b=64+n*18;if(hash(x>>3,y>>3,29)>.85){r*=.8;g*=.8;b*=.8}
 if(win(x,y)){const wx=x%32,wy=y%32;if(wx===8||wy===9||wx===23||wy===22||wx===15||wy===15)return C(60,50,44);return C(40,50,66)}
 return C(r,g,b)});
const tWood=mk((x,y)=>{const n=hash(x,y,31);let r=172+n*40,g=120+n*30,b=70+n*22;if(x%8===0){r*=.65;g*=.65;b*=.65}
 const gr=Math.sin(y*.42+x*.14)*14;return C(r+gr,g+gr*.7,b+gr*.35)});
const tMetal=mk((x,y)=>{const wave=Math.sin(x*.55)*.3+.8,n=hash(x,y,37),v=130*wave+n*22;
 if(hash(x>>3,y>>3,41)>.68)return C(170+n*40,86+n*22,52+n*16);return C(v*.9,v*.97,v*1.1)});
const tSandbag=mk((x,y)=>{
  const bagW=16,bagH=8,row=Math.floor(y/bagH),rowY=y%bagH;
  const offsetX=(row%2)*(bagW/2);
  const bagX=(x+offsetX)%bagW;
  if(bagX<1||bagX>=bagW-1)return C(55,45,30);
  if(rowY<1||rowY>=bagH-1)return C(45,38,24);
  const bulgeX=1-Math.abs(bagX-bagW/2)/(bagW/2);
  const bulgeY=1-Math.abs(rowY-bagH/2)/(bagH/2);
  const bulge=Math.max(0,bulgeX*bulgeY);
  const n=hash(x,y,700+row),v=135+n*30+bulge*40;
  return C(v*0.92,v*0.82,v*0.55);
});
const tMilWall=mk((x,y)=>{
  const n=hash(x,y,740);let v=155+n*25;
  const band=y%16;
  if(band===0||band===15)v*=0.7;
  if(band===1)v*=1.15;
  if(band===14)v*=0.85;
  if((x%16===7||x%16===8)&&(band===7||band===8))v=80+n*20;
  if(x%16===0)v*=0.75;
  return C(v,v*0.98,v*0.92);
});
const tMilWallCrack=mk((x,y)=>{
  const n=hash(x,y,741);let v=155+n*25;
  const band=y%16;
  if(band===0||band===15)v*=0.7;
  if(band===1)v*=1.15;
  const crack1=Math.abs((x+y)%24-12);
  const crack2=Math.abs((x-y+64)%28-14);
  if(crack1<1.5||crack2<1.2){
    const ct=hash(x>>1,y>>1,742);
    v=60+ct*30;
  }
  if(hash(x>>2,y>>2,743)>0.9)v*=0.6;
  if(x%16===0)v*=0.75;
  return C(v,v*0.9,v*0.82);
});
const wTex=[null,tConc,tBrick,tWood,tMetal,tSandbag,tMilWall,tMilWallCrack];
let wSh,wShD;
function buildWallShades(){wSh=wTex.map(t=>t&&shades(t,1));wShD=wTex.map(t=>t&&shades(t,.78))}
buildWallShades();
const shadeAt=d=>Math.max(3,(SH-1)*(1-d/55)|0);

const ALLSPR=[];let bakedKey='clear';
function spr(w,h,d){const s={w,h,data:d,sh:shades(d),red:null};ALLSPR.push(s);return s}
function art(a,p){const w=a[0].length,h=a.length,d=new Uint32Array(w*h);
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const c=p[a[y][x]];d[y*w+x]=c===undefined?0:c}return spr(w,h,d)}
function proc(w,h,fn){const d=new Uint32Array(w*h);for(let y=0;y<h;y++)for(let x=0;x<w;x++)d[y*w+x]=fn(x,y)||0;return spr(w,h,d)}
const SOL=['................','....HHHHHH......','...HHHHHHHH.....','...HHffffHH.....','...HHfkkfHH.....','...HHffffHH.....','....HHHHHH......','...UUUUUUUU.....','..UUVVVVVVU.....','..UUVVVVVVUAA...','..UUVVVVVVUGGG..','..UUVVVVVVU.GG..','..AAAAAAAAA.....','..AAAAAAAAA.....','...AAAAAAA......','...AAAAAAA......','...LL..LL.......','...LL..LL.......','...LL..LL.......','...LL..LL.......','..BBB..BBB......','..BBB..BBB......','................','................'];
const SOLB=SOL.slice();for(let i=16;i<20;i++)SOLB[i]='..LL....LL......';SOLB[20]=SOLB[21]='.BBB....BBB.....';
const PS={'.':0,H:C(96,116,70),f:C(230,186,140),k:C(30,24,16),U:C(130,150,96),V:C(78,92,56),A:C(104,124,78),G:C(36,36,42),L:C(112,128,84),B:C(44,32,20)};
const PH={'.':0,H:C(70,78,96),f:C(214,168,126),k:C(255,60,40),U:C(96,102,120),V:C(56,60,78),A:C(80,86,104),G:C(30,30,36),L:C(76,82,98),B:C(30,24,16)};
const PSN={'.':0,H:C(64,80,48),f:C(200,170,120),k:C(20,15,10),U:C(58,72,44),V:C(34,46,28),A:C(64,80,48),G:C(28,30,32),L:C(54,68,42),B:C(30,22,14)};
const PSH={'.':0,H:C(92,72,60),f:C(220,180,130),k:C(30,20,14),U:C(120,74,50),V:C(170,40,30),A:C(108,66,44),G:C(30,30,34),L:C(94,60,44),B:C(42,30,18)};
const POF={'.':0,H:C(44,50,80),f:C(220,180,130),k:C(30,20,14),U:C(58,62,88),V:C(200,160,40),A:C(52,56,80),G:C(30,30,34),L:C(50,54,76),B:C(26,20,16)};
const PCO={'.':0,H:C(18,18,22),f:C(180,140,100),k:C(255,40,30),U:C(28,28,36),V:C(80,20,20),A:C(26,26,34),G:C(18,18,22),L:C(22,22,30),B:C(12,10,10)};
const PAL_ALLY={'.':0,H:C(60,80,140),f:C(230,186,140),k:C(30,24,16),U:C(80,110,180),V:C(50,70,130),A:C(70,95,160),G:C(36,36,42),L:C(70,100,170),B:C(30,24,20)};
const sALLY=[art(SOL,PAL_ALLY),art(SOLB,PAL_ALLY)];
const sS=[art(SOL,PS),art(SOLB,PS)],sH=[art(SOL,PH),art(SOLB,PH)];
const sSN=[art(SOL,PSN),art(SOLB,PSN)];
const sSH=[art(SOL,PSH),art(SOLB,PSH)];
const sOF=[art(SOL,POF),art(SOLB,POF)];
const sCO=[art(SOL,PCO),art(SOLB,PCO)];
const CORP=['................','................','..HHHH..........','.HHHHHHGGGGG....','HHffffHHGGGGGG..','.UUUUUUUUGGGG...','.UUUUUUUUUUUU...','..LLLLLLLL......','..BBBBBBBB......','................'];
const cS=art(CORP,PS),cH=art(CORP,PH),cSN=art(CORP,PSN),cSH=art(CORP,PSH),cOF=art(CORP,POF),cCO=art(CORP,PCO),cALLY=art(CORP,PAL_ALLY);
const DOG=['....................','..KK..........KK....','..KKK........KKK....','..KKKK......KKKK....','...KKKKKKKKKKKK.....','...KKDDDDDDDDKK.....','...KDDDDDDDDDDK.....','...KDDDDDDDDDDK.....','....KKKK..KKKK......','....KK....KK........','....KK....KK........','....................'];
const DOGB=DOG.slice();DOGB[9]='...KKK.....KKK......';DOGB[10]='..KKK......KKK......';DOGB[11]='..K.........K.......';
const PDG={'.':0,K:C(50,30,20),D:C(80,50,30)};
const sDOG=[art(DOG,PDG),art(DOGB,PDG)];
const CDOG=['....................','....................','....KKKKKKKKKK......','...KKDDDDDDDDKK.....','...KDDDDDDDDDDK.....','....KKKK..KKKK......','....KK....KK........','....................'];
const cDOG=art(CDOG,PDG);
const sTree=proc(32,48,(x,y)=>{const dx=(x-16)/15,dy=(y-15)/15,d=dx*dx+dy*dy;
 if(y<31&&d<1){const n=hash(x,y,50),l=(-dx*.5-dy*.7+1)*.5;let g=90+l*90+n*30;if(d>.8)g*=.75;return C(g*.45,g,g*.35)}
 if(y>=26&&x>=14&&x<=17){const b=100+hash(x,y,51)*30;return C(b*.9,b*.62,b*.35)}
 if(y>=44&&x>=12&&x<=19&&y<48)return C(90,62,38)});
const sBush=proc(16,10,(x,y)=>{const dx=(x-8)/8,dy=(y-6)/5;if(dx*dx+dy*dy<1){const g=110+hash(x,y,52)*60+(5-y)*6;return C(g*.45,g,g*.35)}});
const sDead=art(['...T........T...','....T......T....','.....T....T.....','......T..T......','.......TT.......','.......TT.......','......TTTT......','.......TT.......','.......TT.......','.......TT.......','.......TT.......','.......TT.......','.......TT.......','......TTTT......','.....TTTTTT.....','.....TTTTTT.....'],{'.':0,T:C(96,76,56)});
const CAR=['................','..BBBBBBBBBB....','.BBBBBBBBBBBB...','.BBBBBBBBBBBB...','BWWWWWWWWWWWWB..','BWWWWWWWWWWWWB..','BBBBBBBBBBBBBB..','BKKKKB..BKKKKB..','KKKKKK..KKKKKK..','KKKKKK..KKKKKK..','.KKKK....KKKK...','................'];
const sCar=art(CAR,{'.':0,B:C(180,70,60),W:C(170,210,230),K:C(30,28,26)}),sCar2=art(CAR,{'.':0,B:C(70,100,150),W:C(170,210,230),K:C(30,28,26)});
const sBarrel=art(['............','..MMMMMM....','.MMMMMMMM...','.MRRRRRRM...','.MRRRRRRM...','.MMMMMMMM...','.MRRRRRRM...','.MRRRRRRM...','.MMMMMMMM...','.MRRRRRRM...','.MRRRRRRM...','..MMMMMM....'],{'.':0,M:C(130,60,36),R:C(200,110,50)});
const sTrash=art(['..........','..GGGGGG..','.GGGGGGGG.','.GGGGGGGG.','.GGGGGGGG.','.GGGGGGGG.','.GGGGGGGG.','.GGGGGGGG.','.GGGGGGGG.','..GGGGGG..'],{'.':0,G:C(100,120,96)});
const sCrate=art(['............','.WWWWWWWWWW.','.WDDDDDDDDW.','.WDWWWWWWDW.','.WDWDDDDWDW.','.WDWDDDDWDW.','.WDWWWWWWDW.','.WDDDDDDDDW.','.WWWWWWWWWW.','............'],{'.':0,W:C(200,148,86),D:C(140,98,54)});
const sLamp=art(['........','..LLL...','..LLL...','...L....','...L....','...L....','...L....','...L....','...L....','...L....','...L....','...L....','...L....','...L....','...L....','...L....','..LLL...','..LLL...'],{'.':0,L:C(96,100,110)});
const sShelf=proc(16,22,(x,y)=>{const r=y%7,b=(y/7)|0;if(x<1||x>14||r===0||y>20)return C(130,92,52);if(r<=4&&hash(x>>1,b,60)>.3){const h=hash(x>>1,b,61);return h<.25?C(210,64,52):h<.5?C(72,134,210):h<.75?C(226,196,64):C(84,176,94)}return C(66,48,32)});
const sBag=proc(16,12,(x,y)=>{
  const row=Math.floor(y/6),rowY=y%6,offsetX=(row%2)*4;
  const bagX=(x+offsetX)%8;
  if(rowY===0||rowY===5||bagX===0||bagX===7)return C(50,42,28);
  if(bagX===1||rowY===1)return C(140,120,80);
  const n=hash(x,y,400+row);
  return C(155+n*30,135+n*25,95+n*20);
});
const sLocker=proc(10,18,(x,y)=>{if(x===0||x===9||y===0||y===17)return C(62,72,88);if(x===5)return C(74,84,100);if(y>=3&&y<=5&&x%2===0)return C(84,96,112);if((x===3||x===7)&&y===9)return C(226,204,92);const g=hash(x,y,63)*14;return C(120+g,142+g,164+g)});
const sMil=proc(14,9,(x,y)=>{if(x===0||x===13||y===0||y===8)return C(40,58,34);if(y===4&&x>=4&&x<=9)return C(232,204,64);if(x===3||x===10)return C(52,70,44);const g=hash(x,y,64)*12;return C(72+g,96+g,60+g)});
const sCache=proc(20,16,(x,y)=>{const dx=(x-9.5)/10,dy=(y-7.5)/8;if(dx*dx+dy*dy>1.15)return 0;
 if(y<2||y>14)return C(60,50,40);
 if(x<2||x>18)return C(60,50,40);
 const n=hash(x,y,150);if(y>=6&&y<=9&&x>=8&&x<=12)return C(255,215,80);
 if(y>=3&&y<=4&&x>=4&&x<=16)return C(180,140,60);
 if(n>.7)return C(140,105,55);return C(100,80,45)});
const sCacheOpen=proc(20,16,(x,y)=>{const dx=(x-9.5)/10,dy=(y-7.5)/8;if(dx*dx+dy*dy>1.15)return 0;
 if(y<2||y>14)return C(50,42,34);
 if(x<2||x>18)return C(50,42,34);
 const n=hash(x,y,151);if(y>=10&&y<=12&&x>=3&&x<=17)return C(220,180,60);
 if(n>.75)return C(80,65,40);return C(60,50,38)});
const sSafe=proc(24,28,(x,y)=>{if(x<2||x>21||y<2||y>25)return 0; if(x<4||x>19||y<4||y>23)return C(35,39,41); if(x===4||x===19||y===4||y===23)return C(125,132,133); if(x>=7&&x<=16&&y>=7&&y<=19){if(x===8||x===15||y===8||y===18)return C(76,82,82);if(x>=10&&x<=13&&y>=11&&y<=14)return C(224,177,64);return C(62,69,70)} if(y>=20&&y<=22)return C(46,50,50);return C(95+hash(x,y,734)*22,100+hash(x,y,735)*22,101+hash(x,y,736)*22)});
const sBlood=proc(12,12,(x,y)=>{const dx=(x-5.5)/5.5,dy=(y-5.5)/5.5,d=dx*dx+dy*dy;
 if(d>1)return 0;const n=hash(x,y,200);if(d>0.75&&n>0.4)return 0;return C(110+n*60,12+n*15,12+n*15)});
const sMed=proc(12,12,(x,y)=>{if(x<1||x>10||y<1||y>10)return 0;
 if((x>=5&&x<=6&&y>=3&&y<=8)||(x>=3&&x<=8&&y>=5&&y<=6))return C(245,245,245);return C(190,40,40)});
const sShell=proc(10,10,(x,y)=>{if(y<2||y>7||x<1||x>8)return 0;return C(190,120,40)});
const sBul=proc(10,10,(x,y)=>{if(y<2||y>7||x<1||x>8)return 0;return C(180,150,50)});
const sSmoke=proc(16,16,(x,y)=>{const dx=(x-7.5)/8,dy=(y-7.5)/8,d=dx*dx+dy*dy;
 if(d>1)return 0;const n=hash(x,y,210);if(d>0.7&&n>0.4)return 0;const a=180+n*70;return C(a,a,a)});
const sFire=proc(12,12,(x,y)=>{const dx=(x-5.5)/6,dy=(y-5.5)/6,d=dx*dx+dy*dy;
 if(d>1)return 0;const n=hash(x,y,211);if(d>0.7&&n>0.5)return 0;return C(255,90+n*150,20+n*40)});
const sShot=proc(6,6,(x,y)=>{const dx=x-2.5,dy=y-2.5;if(dx*dx+dy*dy>4.5)return 0;return C(255,240,140)});
const sRocket=proc(12,12,(x,y)=>{const dx=(x-5.5)/6,dy=(y-5.5)/6,d=dx*dx+dy*dy;
