function swapOrReload(){const w=WEAPONS[P.weapon];if(w.ammo&&P.mag[P.weapon]<=0&&P[w.ammo]>0)startReload();else swapWeapon()}
function swapWeapon(){if(state!=='play'||paused())return;const available=(P.weaponSlots||[0,-1]).filter(w=>w>=0);if(!available.length){msg('NO TIENES OTRA ARMA EQUIPADA','#ffb060');return}P.reloading=0;P.reloadTotal=0;const cur=available.indexOf(P.weapon);P.weapon=available[(cur+1)%available.length];SFX.swap();hud(true)}
function wallDist(px,py,dx,dy,m){
 for(let d=0;d<m;d+=.08){const x=px+dx*d,y=py+dy*d;if(isWall(x,y))return d;if(propBlocksAt(x,y))return d}
 return m}
function startReload(){if(P.reloading>0||state!=='play'||paused())return;
 const wi=P.weapon,w=WEAPONS[wi];if(!w.ammo)return;
 if(P.mag[wi]>=w.magMax)return;
 if(P[w.ammo]<=0){msg('SIN MUNICIÓN','#ff6a5a');return}
 P.reloading=w.reload;P.reloadTotal=w.reload;SFX.reload();hud(true)}
function finishReload(){const wi=P.weapon,w=WEAPONS[wi];if(!w.ammo)return;
 const need=w.magMax-P.mag[wi],avail=P[w.ammo],take=Math.min(need,avail);
 P.mag[wi]+=take;P[w.ammo]-=take;SFX.reloadEnd();hud(true)}
function cycleThrowable(){const order=['frag','smoke','molotov'];const cur=order.indexOf(P.currentThrow);
 for(let i=1;i<=3;i++){const next=order[(cur+i)%3];if(P.throwables[next]>0){P.currentThrow=next;msg('SELEC: '+ITEMS[next].name,'#9fd8ff');SFX.ui();hud(true);return}}
 P.currentThrow=order[(cur+1)%3];SFX.ui();hud(true)}
function throwGrenade(){if(state!=='play'||paused())return;if(P.throwCd>0)return;
 const type=P.currentThrow;
 if(!type||P.throwables[type]<=0){msg('SIN '+((ITEMS[type]||{}).name||'ARROJADIZOS'),'#ff6a5a');cycleThrowable();return}
 P.throwCd=.7;P.throwables[type]--;
 const speed=11,dx=Math.cos(P.a),dy=Math.sin(P.a);
 throwables.push({x:P.x+dx*.4,y:P.y+dy*.4,z:.6,vx:dx*speed,vy:dy*speed,vz:4.5,type,fuse:type==='frag'?2.5:.5,bounces:0,life:6,age:0,kills:0});
 SFX.throwG();if(navigator.vibrate)navigator.vibrate(20);hud(true)}
const AI_S={PATROL:'PATROL',SUSPICIOUS:'SUSPICIOUS',SEARCH:'SEARCH',COMBAT:'COMBAT',FLEE:'FLEE'};
function setState(e,s){if(e.state===s)return;e.prevState=e.state;e.state=s;e.stateT=0}
function broadcastToSquad(srcE,pos){
  const op=srcE.outpost;
  if(!op||!pos)return;
  for(const a of op.enemies){
    if(a===srcE||!a.alive)continue;
    if(Math.hypot(a.x-srcE.x,a.y-srcE.y)>24)continue;
    a.lastKnownPos={x:pos.x,y:pos.y};
    if(a.state!=='COMBAT'&&a.state!=='FLEE'&&a.state!=='SEARCH'){setState(a,'SUSPICIOUS');a.suspT=2.5}
  }
}
function raiseAlert(op,level){
  if(!op||op.taken)return;
  const ord={CALM:0,ALERT:1,ALARM:2,CLEARED:-1};
  if(ord[level]>ord[op.alertState||'CALM']){
    op.alertState=level;op.alertT=0;
    if(level==='ALERT')msg('¡'+op.name+' EN ALERTA!','#ffb040');
    if(level==='ALARM'){
      msg('¡'+op.name+' EN ALARMA!','#ff3a3a');SFX.siren();
      if(navigator.vibrate)navigator.vibrate([30,50,30]);
      for(const other of OUTPOSTS){
        if(other===op||other.taken)continue;
        if(Math.hypot(other.x-op.x,other.y-op.y)<40&&(other.alertState||'CALM')==='CALM')other.alertState='ALERT';
      }
    }
  }
}
function findCoverFrom(e,awayX,awayY){
  const dx0=e.x-awayX,dy0=e.y-awayY;
  const d0=Math.hypot(dx0,dy0)||1;
  const fx=dx0/d0,fy=dy0/d0;
  for(let r=3;r<=9;r++){
    for(let spread=0;spread<6;spread++){
      const side=(spread%2)?1:-1;
      const ang=Math.atan2(fy,fx)+side*Math.floor(spread/2)*0.5;
      const tx=e.x+Math.cos(ang)*r,ty=e.y+Math.sin(ang)*r;
      const ix=Math.floor(tx),iy=Math.floor(ty);
      if(ix<2||iy<2||ix>=MW-2||iy>=MH-2)continue;
      if(map[iy*MW+ix])continue;
      if(!canStandProp(tx,ty,0.3))continue;
      if(!los(tx,ty,awayX,awayY))return {x:tx,y:ty};
    }
  }
  return null;
}
function fireEnemyWeapon(e,dt,per,nx,ny){
  const dist=per.dist,tgtAlly=per.tgtAlly;
  if(e.sniper){
    if(e.aimT<=0){e.aimT=1.5;SFX.aim()}
    else{e.aimT-=dt;
      if(e.aimT<=0){e.aimT=0;e.atkCd=2.5+Math.random()*1.5;
        const sp=16;
        projs.push({x:e.x+nx*.5,y:e.y+ny*.5,vx:nx*sp,vy:ny*sp,dmg:e.dmg,life:2.4,srcX:e.x,srcY:e.y,big:true,allyTarget:!!tgtAlly});
        SFX.sniper();}}
    return;
  }
  if(e.meleeType){
    if(dist<1.3){e.atkCd=.7+Math.random()*.4;
      if(tgtAlly){tgtAlly.hp-=e.dmg;if(tgtAlly.hp<=0){tgtAlly.hp=0;tgtAlly.alive=false;msg('¡ALIADO CAÍDO!','#ff6a5a')}}
      else hurt(armor(e.dmg),e.x,e.y);
      SFX.dogBite();}
    return;
  }
  if(e.type==='shotgunner'){
    if(dist<10){e.atkCd=1.4+Math.random()*.6;
      for(let i=0;i<8;i++){const a=Math.atan2(ny,nx)+(Math.random()-.5)*.35;const sp=9;
        projs.push({x:e.x+nx*.3,y:e.y+ny*.3,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,dmg:8,life:1.2,srcX:e.x,srcY:e.y,small:true,allyTarget:!!tgtAlly});}
      SFX.shotgun();}
    return;
  }
  if(dist>1.6){e.atkCd=(e.boss?.5:e.type==='heavy'?1.1:1.3)+Math.random()*.7;
    const sp=e.boss?11:9;
    projs.push({x:e.x+nx*.4,y:e.y+ny*.4,vx:nx*sp,vy:ny*sp,dmg:e.dmg,life:2.4,srcX:e.x,srcY:e.y,allyTarget:!!tgtAlly});
    SFX.bullet();
    if(e.boss&&Math.random()<.25&&!tgtAlly){eGrenades.push({x:e.x+nx*.5,y:e.y+ny*.5,z:.6,vx:nx*8,vy:ny*8,vz:4,fuse:2.2,life:5});SFX.throwG()}
  } else if(dist<1.3){e.atkCd=1.05;
    if(tgtAlly){tgtAlly.hp-=e.dmg;if(tgtAlly.hp<=0){tgtAlly.hp=0;tgtAlly.alive=false;msg('¡ALIADO CAÍDO!','#ff6a5a')}}
    else hurt(armor(e.dmg),e.x,e.y);}
}
function handlePatrolState(e,dt,per){
  if(per.clearLOS){setState(e,'COMBAT');e.lastKnownPos={x:per.tgtX,y:per.tgtY};if(e.outpost)raiseAlert(e.outpost,'ALERT');broadcastToSquad(e,e.lastKnownPos);return}
  if((e.detect||0)>0.7){setState(e,'SUSPICIOUS');e.suspT=3+Math.random()*2;if(e.lastNoise)e.lastKnownPos={x:e.lastNoise.x,y:e.lastNoise.y};return}
  const op=e.outpost;
  if(!op||!op.waypoints||!op.waypoints.length){
    e.wanderT=(e.wanderT||0)-dt;
    if(e.wanderT<=0){e.wanderT=1.5+Math.random()*2.5;e.wander=Math.random()*6.28}
    moveE(e,Math.cos(e.wander)*0.35*dt,Math.sin(e.wander)*0.35*dt);e.face=e.wander;return;
  }
  if(e.waypointIdx===undefined)e.waypointIdx=Math.floor(Math.random()*op.waypoints.length);
  const wp=op.waypoints[e.waypointIdx];if(!wp){e.waypointIdx=0;return}
  const wdx=wp.x-e.x,wdy=wp.y-e.y,wd=Math.hypot(wdx,wdy);
  if(wd<0.6){e.wpWait=(e.wpWait||0)+dt;e.face+=dt*0.8;if(e.wpWait>2){e.wpWait=0;e.waypointIdx=(e.waypointIdx+1)%op.waypoints.length}return}
  e.face=Math.atan2(wdy,wdx);
  const sp=e.speed*0.6;
  moveE(e,(wdx/wd)*sp*dt,(wdy/wd)*sp*dt);
}
function handleSuspiciousState(e,dt,per){
  if(per.clearLOS){setState(e,'COMBAT');e.lastKnownPos={x:per.tgtX,y:per.tgtY};if(e.outpost)raiseAlert(e.outpost,'ALERT');broadcastToSquad(e,e.lastKnownPos);return}
  const targetPos=e.lastKnownPos||e.lastNoise;
  if(targetPos){
    const tdx=targetPos.x-e.x,tdy=targetPos.y-e.y;
    const targetFace=Math.atan2(tdy,tdx);
    let diff=targetFace-e.face;
    while(diff>Math.PI)diff-=Math.PI*2;while(diff<-Math.PI)diff+=Math.PI*2;
    e.face+=clamp(diff,-2*dt,2*dt);
  }
  e.suspT=(e.suspT||2.5)-dt;
  if(e.suspT<=0){setState(e,'SEARCH');e.searchPoint=e.lastKnownPos||e.lastNoise||{x:per.tgtX,y:per.tgtY};e.searchT=8}
}
function handleSearchState(e,dt,per){
  if(per.clearLOS){setState(e,'COMBAT');e.lastKnownPos={x:per.tgtX,y:per.tgtY};if(e.outpost)raiseAlert(e.outpost,'ALERT');broadcastToSquad(e,e.lastKnownPos);return}
  e.searchT=(e.searchT||8)-dt;
  if(e.searchT<=0){setState(e,'PATROL');return}
  if(!e.searchPoint)e.searchPoint=e.lastKnownPos||{x:e.homeX||e.x,y:e.homeY||e.y};
  const sdx=e.searchPoint.x-e.x,sdy=e.searchPoint.y-e.y,sd=Math.hypot(sdx,sdy);
  if(sd<0.8)e.face+=dt*1.2;
  else{const sp=e.speed*0.85;moveE(e,(sdx/sd)*sp*dt,(sdy/sd)*sp*dt);e.face=Math.atan2(sdy,sdx)}
}
function handleFleeState(e,dt){
  if(!e.fleeTarget)e.fleeTarget=findCoverFrom(e,P.x,P.y);
  if(e.fleeTarget){
    const fdx=e.fleeTarget.x-e.x,fdy=e.fleeTarget.y-e.y,fd=Math.hypot(fdx,fdy);
    if(fd<0.6)e.face=Math.atan2(e.y-P.y,e.x-P.x);
    else{moveE(e,(fdx/fd)*e.speed*1.3*dt,(fdy/fd)*e.speed*1.3*dt);e.face=Math.atan2(fdy,fdx)}
  } else {
    const adx=e.x-P.x,ady=e.y-P.y,ad=Math.hypot(adx,ady)||1;
    moveE(e,(adx/ad)*e.speed*1.3*dt,(ady/ad)*e.speed*1.3*dt);
    e.face=Math.atan2(ady,adx);
  }
  if(e.stateT>10){setState(e,'PATROL');e.hp=Math.min(e.maxHp,e.hp+10);e.fleeTarget=null}
}
function handleCombatState(e,dt,per){
