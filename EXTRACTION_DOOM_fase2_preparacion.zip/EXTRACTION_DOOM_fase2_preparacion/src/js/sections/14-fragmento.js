   if(moved<a.speed*dt*0.3){const v=flowDir(a);if(v){moveE(a,v[0]*a.speed*dt,v[1]*a.speed*dt)}}
   a.wt+=dt
  } else if(pd<1.2&&pd>.01){
   if(canStandProp(a.x-pdx/pd*a.speed*.5*dt,a.y,.3))a.x-=pdx/pd*a.speed*.5*dt;
   if(canStandProp(a.x,a.y-pdy/pd*a.speed*.5*dt,.3))a.y-=pdy/pd*a.speed*.5*dt;
   a.wt+=dt
  }
  if(a.atkCd<=0){
   let best=null,bd=144;
   for(const e of enemies){if(!e.alive)continue;const ex=e.x-a.x,ey=e.y-a.y;const d=ex*ex+ey*ey;
    if(d<bd&&los(a.x,a.y,e.x,e.y)){bd=d;best=e}}
   if(best){a.atkCd=0.75;
    const ex=best.x-a.x,ey=best.y-a.y,ed=Math.hypot(ex,ey);
    const rx=ex/ed,ry=ey/ed;const wd=wallDist(a.x,a.y,rx,ry,ed+0.3);
    if(wd>=ed-0.2){best.hp-=14;best.hurtT=.12;
      if(best.state!=='COMBAT'){setState(best,'COMBAT');best.lastKnownPos={x:P.x,y:P.y}}
      if(best.hp<=0)killEnemy(best);else{puff(best.x,best.y,4,C(255,180,80));SFX.enemyHit()}}
    SFX.pistol()}
  }
 }
}
function updProjs(dt){for(let i=projs.length-1;i>=0;i--){const p=projs[i];p.life-=dt;p.x+=p.vx*dt;p.y+=p.vy*dt;
 if(p.life<=0||isWall(p.x,p.y)||propBlocksAt(p.x,p.y)){puff(p.x,p.y,4,C(255,170,40));projs.splice(i,1);continue}
 if(p.allyTarget){let hitAlly=false;
  for(const a of allies){if(!a.alive)continue;const dx=p.x-a.x,dy=p.y-a.y;
   if(dx*dx+dy*dy<.18){a.hp-=p.dmg;if(a.hp<=0){a.hp=0;a.alive=false;msg('¡ALIADO CAÍDO!','#ff6a5a')}
    puff(p.x,p.y,6,C(255,170,40));hitAlly=true;break}}
  if(hitAlly){projs.splice(i,1);continue}
  const dx=P.x-p.x,dy=P.y-p.y;if(dx*dx+dy*dy<.18){hurt(armor(p.dmg),p.srcX||p.x,p.srcY||p.y);puff(p.x,p.y,6,C(255,170,40));projs.splice(i,1);continue}
 } else {const dx=p.x-P.x,dy=p.y-P.y;if(dx*dx+dy*dy<.18){hurt(armor(p.dmg),p.srcX||p.x,p.srcY||p.y);puff(p.x,p.y,6,C(255,170,40));projs.splice(i,1)}}
}}
function updParts(dt){for(let i=parts.length-1;i>=0;i--){const p=parts[i];p.life-=dt;if(p.life<=0){parts.splice(i,1);continue}p.x+=p.vx*dt;p.y+=p.vy*dt;p.vx*=.94;p.vy*=.94}}
function updFx(dt){
 for(let i=hitMarkers.length-1;i>=0;i--){const m=hitMarkers[i];m.life-=dt;if(m.life<=0)hitMarkers.splice(i,1)}
 for(let i=dmgNumbers.length-1;i>=0;i--){const n=dmgNumbers[i];n.life-=dt;n.sy-=28*dt;if(n.life<=0)dmgNumbers.splice(i,1)}
 for(let i=dmgDirs.length-1;i>=0;i--){const d=dmgDirs[i];d.life-=dt;if(d.life<=0)dmgDirs.splice(i,1)}}
function breakWalls(x,y){
 const R=1.7;let broken=0,cracked=0,propsBroken=0;
 // ==== Muros ====
 const x0=Math.max(1,Math.floor(x-R)),x1=Math.min(MW-2,Math.floor(x+R)),y0=Math.max(1,Math.floor(y-R)),y1=Math.min(MH-2,Math.floor(y+R));
 for(let iy=y0;iy<=y1;iy++)for(let ix=x0;ix<=x1;ix++){
  const i=iy*MW+ix,t=map[i];
  if(t!==5&&t!==6&&t!==7)continue;
  if(Math.hypot(ix+.5-x,iy+.5-y)>R)continue;
  if(t===6){map[i]=7;cracked++;puff(ix+.5,iy+.5,6,C(150,140,125));continue}
  map[i]=0;broken++;
  for(let k=decos.length-1;k>=0;k--){const d=decos[k];if(d.spr===sWire&&(d.x|0)===ix&&(d.y|0)===iy)decos.splice(k,1)}
  decos.push({x:ix+.5,y:iy+.5,spr:sRubble,wh:.22,ww:.95,z0:0});
  puff(ix+.5,iy+.5,16,C(150,140,125));puff(ix+.5,iy+.5,6,C(90,84,76));
 }
 // ==== Props sólidos destruibles (erizos, coches, cajas, etc.) ====
 // No destruye torres (r=0.5) ni búnkeres (r=0.75) para no romper la lógica de luces.
 const RP=1.35;
 for(let i=solidProps.length-1;i>=0;i--){
   const p=solidProps[i];
   if(p.r>=0.5)continue;
   if(Math.hypot(p.x-x,p.y-y)>RP)continue;
   // Remover deco asociada (misma posición)
   for(let k=decos.length-1;k>=0;k--){
     const d=decos[k];
     if(Math.abs(d.x-p.x)<.15&&Math.abs(d.y-p.y)<.15){decos.splice(k,1);break}
   }
   puff(p.x,p.y,10,C(120,100,80));puff(p.x,p.y,4,C(180,160,120));
   solidProps.splice(i,1);
   propsBroken++;
 }
 if(broken||cracked||propsBroken){
  rebuildPropGrid();
  rebuildMinimap();
  if(broken||propsBroken)msg('¡EXPLOSIÓN DESTRUCTIVA!','#ffb040');
  else if(cracked)msg('MURO AGRIETADO','#ffd24a');
 }
}
function boom(x,y,armed){
 SFX.boom();
 breakWalls(x,y);
 puff(x,y,28,C(255,150,30));puff(x,y,14,C(255,240,150));puff(x,y,12,C(90,90,90));
 // Destruir pickups cercanos
 for(const p of pickups){
   if(p.taken)continue;
   if(Math.hypot(p.x-x,p.y-y)<2.0){p.taken=true;puff(p.x,p.y,6,C(200,200,200))}
 }
 for(const e of enemies){if(!e.alive)continue;const d=Math.hypot(e.x-x,e.y-y);if(d<2.6&&los(x,y,e.x,e.y))hit(e,Math.round(120*(1-d/2.6)),false,{dist:d})}
 for(const a of allies){if(!a.alive)continue;const d=Math.hypot(a.x-x,a.y-y);if(d<2.6){a.hp-=Math.round(70*(1-d/2.6));if(a.hp<=0){a.hp=0;a.alive=false;msg('¡ALIADO CAÍDO!','#ff6a5a')}}}
 // Solo aplicar daño al jugador si el cohete estaba armado (evita autolesión a bocajarro)
 if(armed!==false){
   const dp=Math.hypot(P.x-x,P.y-y);
   if(dp<2.2)hurt(Math.max(1,Math.round(45*(1-dp/2.2))),x,y);
 }
}
function updRockets(dt){for(let i=rockets.length-1;i>=0;i--){const r=rockets[i];r.life-=dt;
 // Arming: no arma hasta alejarse 1.5 del origen
 if(!r.armed){const pd=Math.hypot(r.x-r.originX,r.y-r.originY);if(pd>1.5)r.armed=true}
 // Ligera resistencia del aire
 r.vx*=.998;r.vy*=.998;
 let h=r.life<=0;
 for(let s=0;s<3&&!h;s++){r.x+=r.vx*dt/3;r.y+=r.vy*dt/3;if(isWall(r.x,r.y)||propBlocksAt(r.x,r.y))h=true;else for(const e of enemies)if(e.alive&&Math.hypot(e.x-r.x,e.y-r.y)<.5){h=true;break}}
 if(Math.random()<.35)parts.push({x:r.x,y:r.y,vx:0,vy:0,life:.3,col:C(150,150,150)});
 if(Math.random()<.4)parts.push({x:r.x-r.vx*.02,y:r.y-r.vy*.02,vx:0,vy:0,life:.18,col:C(255,140+Math.random()*90,40)});
 if(h){r.x-=r.vx*.03;r.y-=r.vy*.03;boom(r.x,r.y,r.armed);rockets.splice(i,1)}}}
function updPlayer(dt){const dx=Math.cos(P.a),dy=Math.sin(P.a);let mx=0,my=0;
 if(keys.w||keys.arrowup)my++;if(keys.s||keys.arrowdown)my--;if(keys.a)mx--;if(keys.d)mx++;
 if(keys.arrowleft)P.a-=2.4*dt;if(keys.arrowright)P.a+=2.4*dt;if(joyOn){mx+=joyX;my+=joyY}
 const ml=Math.hypot(mx,my);if(ml>1){mx/=ml;my/=ml}const mv=Math.abs(mx)>.05||Math.abs(my)>.05,sp=3.6;
 const vx=(dx*my-dy*mx)*sp*dt,vy=(dy*my+dx*mx)*sp*dt;
 if(canStandProp(P.x+vx,P.y,.27))P.x+=vx;if(canStandProp(P.x,P.y+vy,.27))P.y+=vy;
 P.bob+=dt*(mv?9.5:2);if(P.fireCd>0)P.fireCd-=dt;if(P.muzzle>0)P.muzzle-=dt;if(P.hurt>0)P.hurt-=dt;
 if(P.reloading>0){P.reloading-=dt;if(P.reloading<=0){P.reloading=0;finishReload()}}
 if(P.meleeAnim>0)P.meleeAnim-=dt;
 if(P.throwCd>0)P.throwCd-=dt;
 const newPhase=Math.min(1,gt/EXT_AT);dayPhase=newPhase;
 if(!P.extOn&&gt>=EXT_AT){P.extOn=true;msg('¡EXTRACCIÓN DISPONIBLE!','#7dff8f');SFX.win();spawnCommander()}
 noDamageTimer+=dt;
 const ndObj=objectives.find(o=>o.id==='no_damage');
 if(ndObj&&!ndObj.done&&noDamageTimer>=60){ndObj.done=true;msg('¡SOBREVIVISTE 60s SIN DAÑO!','#7dff8f');meta.stats.objectivesDone++;updateDailyProgress('objectives',1)}
 P.food=Math.max(0,P.food-dt*.2);P.water=Math.max(0,P.water-dt*.3);
 if(!P.food||!P.water){P.starve+=dt;if(P.starve>=1.5){P.starve=0;hurt(3);msg(!P.water?'¡TIENES SED!':'¡TIENES HAMBRE!','#ff8a5a')}}
 if(fireHeld)shoot();
 for(const p of pickups){if(p.taken)continue;const a=p.x-P.x,b=p.y-P.y;if(a*a+b*b<.36&&addInv(p.type,1,1)){p.taken=true;SFX.pickup();msg('+ '+ITEMS[p.type].name,'#9fffa0')}}
 nearC=null;let bd=2.56;
 for(const c of corpses){const a=c.x-P.x,b=c.y-P.y,d=a*a+b*b;if(d<bd&&!(c.perm&&!c.loot.length)){bd=d;nearC=c}}
 nearSafe=null;for(const box of SAFE_BOXES){if(box.opened&&!box.loot.length)continue;const d=Math.hypot(box.x-P.x,box.y-P.y);if(d<1.6&&d*d<bd){bd=d*d;nearC=box;nearSafe=box}}
 nearAlly=null;let ba=2.56;
 for(const a of allies){if(!a.alive||a.following)continue;const ddx=a.x-P.x,ddy=a.y-P.y,dd=ddx*ddx+ddy*ddy;
  if(dd<ba){ba=dd;nearAlly=a}}
 const btnL=$('btnLoot');
 if(nearAlly){btnL.textContent='LIBERAR';btnL.classList.add('on');btnL.classList.add('ally')}
 else if(nearC){btnL.textContent=nearC.isSafe?(nearC.opened?'REVISAR CAJA':'FORZAR CAJA FUERTE'):(nearC.cache?'ABRIR COFRE':'SAQUEAR');btnL.classList.add('on');btnL.classList.remove('ally')}
 else{btnL.classList.remove('on');btnL.classList.remove('ally')}
 updateOutpostBanner();
 const bx=BEACON.x-P.x,by=BEACON.y-P.y;
 if(gt>=EXT_AT&&Math.hypot(bx,by)<1.8){ext+=dt;$('extwrap').classList.add('on');$('extfill').style.width=Math.min(100,ext/3.5*100)+'%';
  if(ext>=3.5){state='win';fireHeld=false;SFX.win();
   const earned=onWin();
   const t=gt;
   screen('winScreen');
   const ecoHtml='<div class="ecoBreakdown">'+
