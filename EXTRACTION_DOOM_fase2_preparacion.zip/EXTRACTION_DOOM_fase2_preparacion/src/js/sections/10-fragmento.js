 if(roll<.80)pool=['bronze_lion','bronze_eagle','bronze_bust'];
 else if(roll<.96)pool=['silver_watch','silver_chalice','silver_teapot'];
 else pool=['gold_ring','gold_watch','gold_lion'];
 const id=pool[Math.floor(Math.random()*pool.length)];
 return [{id,count:1}];
}
function beginSafeCrack(safe){
 if(!safe||safe.opened||safeCrack)return;
 safeCrack={safe,elapsed:0};$('safeCrackUI').style.display='block';$('safeCrackBar').style.width='0%';$('safeCrackTime').textContent='30 segundos restantes';fireHeld=false;SFX.ui();
}
function cancelSafeCrack(reason){
 if(!safeCrack)return;safeCrack=null;$('safeCrackUI').style.display='none';$('safeCrackBar').style.width='0%';
 if(reason)msg(reason,'#ffb060');SFX.ui();
}
function updateSafeCrack(dt){
 if(!safeCrack)return;
 if(state!=='play'){cancelSafeCrack();return}
 const safe=safeCrack.safe;
 if(Math.hypot(P.x-safe.x,P.y-safe.y)>2.2){cancelSafeCrack('FORZADO CANCELADO: TE ALEJASTE DE LA CAJA');return}
 safeCrack.elapsed=Math.min(30,safeCrack.elapsed+dt);
 const pct=safeCrack.elapsed/30*100;$('safeCrackBar').style.width=pct+'%';
 $('safeCrackTime').textContent=Math.ceil(30-safeCrack.elapsed)+' segundos restantes';
 if(safeCrack.elapsed>=30){
  safe.opened=true;safe.loot=safeLootRoll();const opened=safe;safeCrack=null;$('safeCrackUI').style.display='none';
  nearC=opened; $('lootPanel').firstElementChild.textContent='BOTÍN DE CAJA FUERTE';renderLoot(opened);$('lootPanel').classList.add('on');fireHeld=false;SFX.win();msg('¡CAJA FUERTE ABIERTA!','#ffd24a');
 }
}
function reset(){
 map.set(mapOrig);rebuildMinimap();
 P={x:2.5,y:2.5,a:.9,hp:100,maxHp:100,food:100,water:100,starve:0,extOn:false,eq:{helmet:null,vest:null},weaponSlots:[0,-1],weapons:[true,false,false,false,false,false,false],weapon:0,ammo9:0,ammo12g:0,ammo556:0,ammo76239:0,ammo792:0,ammo76251:0,rockets:0,inventory:new Array(12).fill(null),fireCd:0,bob:0,hurt:0,muzzle:0,
   mag:[15,0,0,0,0,0,0],reloading:0,reloadTotal:0,meleeAnim:0,
  throwables:{frag:0,smoke:0,molotov:0},currentThrow:'frag',throwCd:0,fireHurtCd:0};
 for(let i=0;i<12;i++){if(meta.stash[i])P.inventory[i]={...meta.stash[i]}}
 for(let i=0;i<12;i++){const it=P.inventory[i];if(!it)continue;const d=ITEMS[it.id];
  if(d.slot&&!P.eq[d.slot]){P.eq[d.slot]={id:it.id,dur:d.dur};P.inventory[i]=null}
  else if(d.weapon!==undefined){ /* Las armas del alijo permanecen en el inventario */ }
  else if(d.throwable){P.throwables[it.id]=(P.throwables[it.id]||0)+it.count;P.inventory[i]=null}
  else if(d.ammo){P[d.ammo]+=d.amount*it.count;P.inventory[i]=null}
 }
 hitMarkers=[];dmgNumbers=[];dmgDirs=[];decals=[];visibleEnemies=[];
 objectives=[];allies=[];noDamageTimer=0;milBoxesLooted=0;nearAlly=null;lastObjHtml='';nearCache=null;
 runStats={longKills:0,meleeKills:0,headshots:0,damageTaken:false,itemsAtEnd:0,explodedKills:0,rifleKills:0};
 lastEco={gross:0,tax:0,net:0};outpostsTaken=0;
 revealedOutposts=new Set();
 enemies=[];resetOutposts();
 allies=[
  {x:2.5,y:5.5,hp:80,maxHp:80,alive:true,following:false,atkCd:0,speed:3.0,name:'ALIADO',color:'#9fd8ff',wt:0,fr:sALLY,corpse:cALLY,height:.62},
  {x:5.5,y:2.5,hp:80,maxHp:80,alive:true,following:false,atkCd:0,speed:3.0,name:'ALIADO',color:'#9fd8ff',wt:0,fr:sALLY,corpse:cALLY,height:.62}
 ];
 corpses=[];projs=[];parts=[];decos=[];rockets=[];throwables=[];smokes=[];fires=[];noises=[];eGrenades=[];rain=[];
 solidProps.length=0;
 for(const fp of fortProps)solidProps.push(fp);
 for(const fd of fortDecos)decos.push(fd);
 const free=(x,y)=>x>=1&&y>=1&&x<MW-1&&y<MH-1&&!map[y*MW+x];
 for(const[x0,y0,x1,y1]of PARKS){
  for(let y=y0+1;y<y1;y++)for(let x=x0+1;x<x1;x++){
   if(Math.random()<0.18&&free(x,y)){
    const d={x:x+.5,y:y+.5,spr:sTree,wh:2.8,ww:2.8*sTree.w/sTree.h,z0:0};
    decos.push(d);addSolidProp(d.x,d.y,.35);
   } else if(Math.random()<0.06&&free(x,y)){
    decos.push({x:x+.5,y:y+.5,spr:sBush,wh:.5,ww:.5*sBush.w/sBush.h,z0:0});
   }
  }
 }
 const ct={c:[sCrate,.65],s:[sShelf,.9],b:[sBag,.45],l:[sLocker,1],m:[sMil,.6]};
 for(const t of CONTS){
  if(!free(t[0],t[1]))continue;
  const k=ct[t[2]]||ct.c;
  corpses.push({x:t[0]+.5,y:t[1]+.5,spr:k[0],wh:k[1],ww:k[1]*k[0].w/k[0].h,z0:0,perm:true,loot:contLoot(t[2]),military:t[2]==='m'});
  if(t[2]==='l')addSolidProp(t[0]+.5,t[1]+.5,.35);
  else if(t[2]==='c'||t[2]==='m')addSolidProp(t[0]+.5,t[1]+.5,.3);
 }
 const FURN={sofa:{s:sSofa,h:.55,w:1.3},sofa2:{s:sSofa2,h:.55,w:1.3},bed:{s:sBed,h:.5,w:1.2},bed2:{s:sBed2,h:.5,w:1.2},table:{s:sTable,h:.4,w:1.0},rug:{s:sRug,h:.04,w:1.6}};
 for(const f of FURNITURE){
  const[x,y,type]=f;const def=FURN[type];if(!def)continue;
  if(free(x,y)){
   const z0=(type==='rug')?0.001:0;
   decos.push({x:x+.5,y:y+.5,spr:def.s,wh:def.h,ww:def.w,z0:z0});
   if(type==='sofa'||type==='sofa2')addSolidProp(x+.5,y+.5,.42);
   else if(type==='bed'||type==='bed2')addSolidProp(x+.5,y+.5,.45);
   else if(type==='table')addSolidProp(x+.5,y+.5,.3);
  }
 }
 const lampStep=12;
 for(let y=3;y<MH-2;y+=lampStep)for(let x=3;x<MW-2;x+=lampStep){
  if(free(x,y)&&!isInsideBuilding(x+.5,y+.5)){
   decos.push({x:x+.5,y:y+.5,spr:sLamp,wh:3.2,ww:3.2*sLamp.w/sLamp.h,z0:0});
  }
 }
 rebuildPropGrid();
 spawnSafeBoxes();
 for(const op of OUTPOSTS)computeOutpostWaypoints(op);
 for(const op of OUTPOSTS)spawnOutpostEnemies(op);
 total=enemies.length;
 pickups=PICKUP_SPOTS.map(p=>({...p,taken:false}));
 kills=0;ext=0;gt=0;nearC=null;fireHeld=false;
 lastHp=lastAm=lastW=lF=lW=lO=lWt=-1;lastBtnSwap='';lTh='';
 flowT=0;rollObjectives();
 const wr=Math.random();
 weather=wr<.5?'clear':wr<.75?'rain':wr<.9?'fog':'sandstorm';
 dayPhase=0;applyAtmosphere();
}

let actx=null;
function ensureAudio(){if(!actx){try{actx=new(window.AudioContext||window.webkitAudioContext)()}catch(e){}}if(actx&&actx.state==='suspended')actx.resume()}
function noise(dur,f,g,type){if(!actx)return;const n=Math.max(1,actx.sampleRate*dur|0),b=actx.createBuffer(1,n,actx.sampleRate),d=b.getChannelData(0);
 for(let i=0;i<n;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/n,2.2);const s=actx.createBufferSource();s.buffer=b;
 const fl=actx.createBiquadFilter();fl.type=type||'lowpass';fl.frequency.value=f;const ga=actx.createGain();ga.gain.value=g;s.connect(fl);fl.connect(ga);ga.connect(actx.destination);s.start()}
function tone(f0,f1,dur,g,t){if(!actx)return;const o=actx.createOscillator(),ga=actx.createGain(),n=actx.currentTime;o.type=t||'square';
 o.frequency.setValueAtTime(f0,n);o.frequency.exponentialRampToValueAtTime(Math.max(20,f1),n+dur);ga.gain.setValueAtTime(g,n);ga.gain.exponentialRampToValueAtTime(.0001,n+dur);
 o.connect(ga);ga.connect(actx.destination);o.start();o.stop(n+dur+.02)}
const SFX={pistol(){noise(.13,2200,.26);tone(320,60,.09,.13)},shotgun(){noise(.3,1300,.4);tone(160,40,.2,.19,'sawtooth')},rifle(){noise(.1,3000,.22);tone(420,90,.07,.12)},
 enemyHit(){tone(220,90,.1,.09)},enemyDie(){tone(180,40,.45,.15,'sawtooth');noise(.35,700,.18)},playerHurt(){tone(260,70,.25,.2,'sawtooth')},
 pickup(){tone(700,1300,.12,.13)},bullet(){tone(600,250,.14,.09,'triangle')},empty(){tone(140,90,.06,.09)},swap(){tone(400,700,.08,.09)},ui(){tone(600,900,.06,.1)},rocket(){noise(.35,900,.3);tone(220,60,.3,.14,'sawtooth')},boom(){noise(.7,500,.55);tone(110,30,.5,.22,'sawtooth')},
 reload(){tone(220,180,.08,.15);setTimeout(()=>tone(180,140,.1,.14),110);setTimeout(()=>tone(280,320,.08,.13),220)},
 reloadEnd(){tone(420,560,.06,.15)},
 punch(){noise(.09,700,.22);tone(160,60,.1,.14,'sawtooth')},
 hitmark(){tone(1200,1500,.04,.11)},
 crit(){tone(1400,1800,.06,.13,'square');setTimeout(()=>tone(1600,2000,.05,.11,'square'),50)},
 throwG(){tone(380,200,.14,.13,'triangle')},
 bounce(){tone(700,400,.06,.1)},
 smoke(){noise(.8,900,.3,'lowpass');tone(300,150,.4,.1,'triangle')},
 fire(){noise(1.2,700,.35);tone(150,80,.6,.14,'sawtooth')},
 shout(){tone(280,520,.15,.22,'sawtooth');setTimeout(()=>tone(500,300,.15,.2,'sawtooth'),120)},
 sniper(){noise(.5,2400,.5);tone(200,50,.3,.25,'sawtooth')},
 dogBite(){noise(.08,1400,.28);tone(180,80,.1,.16,'sawtooth')},
 aim(){tone(900,1100,.25,.08,'sine')},
 detect(){tone(600,900,.08,.12,'triangle')},
 ally(){tone(500,900,.12,.15,'sine');setTimeout(()=>tone(700,1100,.1,.13,'sine'),100)},
 buy(){tone(800,1200,.08,.14,'square');setTimeout(()=>tone(1000,1400,.06,.12,'square'),50)},
 sell(){tone(600,400,.08,.14,'square')},
 error(){tone(200,100,.15,.15,'sawtooth')},
 siren(){tone(880,440,.55,.14,'sawtooth');setTimeout(()=>tone(440,880,.55,.14,'sawtooth'),350);setTimeout(()=>tone(880,440,.55,.14,'sawtooth'),700)},
 heal(){tone(700,1200,.15,.15,'sine');setTimeout(()=>tone(900,1500,.12,.13,'sine'),80)},
 win(){tone(400,900,.5,.17);setTimeout(()=>tone(700,1400,.6,.17),160)},dead(){tone(300,50,.9,.2,'sawtooth')}};
function whoosh(){
 if(!actx)return;
 const o=actx.createOscillator(),g=actx.createGain(),n=actx.currentTime;
 o.type='sawtooth';
 o.frequency.setValueAtTime(140,n);
 o.frequency.exponentialRampToValueAtTime(50,n+1.2);
 g.gain.setValueAtTime(.08,n);
 g.gain.exponentialRampToValueAtTime(.0001,n+1.2);
 o.connect(g);g.connect(actx.destination);
 o.start(n);o.stop(n+1.25);
}

