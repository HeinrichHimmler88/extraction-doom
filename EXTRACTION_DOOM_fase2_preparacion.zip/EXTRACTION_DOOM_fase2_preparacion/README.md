# EXTRACTION DOOM — estructura modular conservadora

Esta carpeta parte de `EXTRACTION_DOOM_cajas_fuertes_miscelaneas.html`, la versión de trabajo que se entregó para modularizar. La página conserva la lógica del juego y sus estilos; aquí solo se trasladan el CSS y el JavaScript a archivos separados.

## Archivos

- `index.html`: estructura visual del juego; carga el CSS y el JavaScript compilado.
- `src/css/game.css`: estilos extraídos del HTML original.
- `src/js/sections/01-fragmento.js` ... `21-fragmento.js`: fragmentos ordenados del JavaScript original.
- `dist/game.js`: JavaScript concatenado que ejecuta el navegador.
- `EXTRACTION_DOOM_original.html`: respaldo íntegro del HTML original.
- `build.py`: vuelve a unir los fragmentos en el orden correcto y revisa la sintaxis con Node.js.
- `validate.py`: verifica que CSS y JavaScript sigan coincidiendo exactamente con el original guardado.

## Cómo probarlo

1. Conserva todos los archivos y carpetas en sus ubicaciones relativas.
2. Abre `index.html` a través de un servidor estático o de GitHub Pages. Si abres el archivo directamente y algo no carga, prueba un servidor local.
3. Antes de modificar el juego, ejecuta `python build.py` después de cambiar cualquier fragmento JavaScript.
4. Ejecuta `python validate.py` para detectar si los fragmentos ya difieren del original. Es normal que la validación de igualdad deje de pasar después de modificar intencionalmente el código.
5. Prueba el menú, iniciar partida, movimiento, armas, inventario, enemigos, tienda, extracción y cajas fuertes.

## Regla importante de esta primera etapa

Los archivos JavaScript son **fragmentos ordenados**, no módulos ES independientes. El juego original usa muchas variables y funciones compartidas dentro de una misma función envolvente (IIFE); separarlas en `<script>` distintos o añadir `import/export` de golpe puede romper el ámbito compartido y el orden de inicialización. Por eso `build.py` concatena los fragmentos para mantener el comportamiento. La separación semántica real se hará en una etapa posterior y con pruebas.

## GitHub

Sube el contenido de esta carpeta a la rama `refactorización/modularización`, conservando la estructura de carpetas. No reemplaces `principal` ni borres la rama `backup/antes-de-modularizar`. Si quieres que el juego publicado se ejecute directamente en GitHub Pages, configura Pages para publicar la raíz de esta rama o de la carpeta donde queden `index.html`, `src/` y `dist/`.
