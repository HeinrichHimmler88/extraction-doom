 if(d>1)return 0;const n=hash(x,y,300);
 if(d<.1)return C(255,250,210);
 if(d<.3)return C(255,185+n*40,60);
 if(d<.6)return C(86+n*14,102+n*14,70+n*10);
 if(n>.45)return 0;return C(255,110+n*80,30)});
const sRubble=proc(16,8,(x,y)=>{const n=hash(x,y,310),n2=hash(x>>1,y>>1,311);
 const h=Math.sin(x*.5)*1.6+3.5;if(y<7-h||n2>.8)return 0;
 const v=95+n*70;return C(v,v*.95,v*.86)});
const sFragGren=proc(10,10,(x,y)=>{const dx=(x-4.5)/5,dy=(y-4.5)/5,d=dx*dx+dy*dy;
 if(d>1.05)return 0;const n=hash(x,y,220);if(d>0.8&&n>0.4)return 0;return C(70+n*30,90+n*30,50+n*20)});
const sSmokeGren=proc(10,10,(x,y)=>{const dx=(x-4.5)/5,dy=(y-4.5)/5,d=dx*dx+dy*dy;
 if(d>1.05)return 0;const n=hash(x,y,221);if(d>0.8&&n>0.4)return 0;return C(120+n*40,130+n*40,140+n*30)});
const sMolotov=proc(10,10,(x,y)=>{const dx=(x-4.5)/5,dy=(y-4.5)/5,d=dx*dx+dy*dy;
 if(d>1.05)return 0;const n=hash(x,y,222);if(d>0.8&&n>0.4)return 0;return C(200+n*30,120+n*20,40+n*20)});
const sBeacon=proc(24,48,(x,y)=>{
 if(x>=10&&x<=14&&y>=14&&y<=42){const n=hash(x,y,230);return C(120+n*30,110+n*30,100+n*30)}
 if(y>=40&&y<=46&&x>=8&&x<=16){const n=hash(x,y,231);return C(90+n*20,80+n*20,70+n*20)}
 if(y>=4&&y<=14&&x>=10&&x<=22){const n=hash(x,y,232);const w=(y-4);if(x>10+w)return 0;return C(220+n*30,50+n*30,50+n*30)}
 return 0});
const sSofa=proc(20,12,(x,y)=>{const n=hash(x,y,240);
 if(y<3)return C(140+n*30,60+n*20,50+n*15);
 if(x<2||x>17)return C(160+n*25,80+n*20,60+n*15);
 if(y<=8)return C(180+n*25,100+n*20,80+n*15);return C(120+n*20,60+n*15,40+n*10)});
const sSofa2=proc(20,12,(x,y)=>{const n=hash(x,y,241);
 if(y<3)return C(50+n*20,90+n*30,60+n*20);
 if(x<2||x>17)return C(60+n*20,110+n*30,80+n*20);
 if(y<=8)return C(80+n*25,140+n*30,100+n*20);return C(40+n*15,70+n*20,50+n*15)});
const sBed=proc(20,16,(x,y)=>{const n=hash(x,y,242);
 if(y<4&&x>=2&&x<=17)return C(230+n*20,230+n*20,240+n*15);
 if(y>=4&&y<=14&&x>=1&&x<=18){const stripe=((x+y)>>2)%2;return stripe?C(60+n*20,90+n*40,150+n*30):C(80+n*20,120+n*40,180+n*30)}
 return C(80,60,50)});
const sBed2=proc(20,16,(x,y)=>{const n=hash(x,y,243);
 if(y<4&&x>=2&&x<=17)return C(230+n*20,230+n*20,240+n*15);
 if(y>=4&&y<=14&&x>=1&&x<=18){const stripe=((x+y)>>2)%2;return stripe?C(80+n*20,60+n*20,50+n*20):C(110+n*20,80+n*20,60+n*20)}
 return C(80,60,50)});
const sTable=proc(20,14,(x,y)=>{const n=hash(x,y,244);
 if(y>=10){if(x<3||x>16)return C(80+n*20,50+n*15,30+n*15);return 0}
 if(y<3)return C(160+n*30,110+n*25,60+n*20);return C(140+n*30,95+n*25,50+n*20)});
const sRug=proc(24,16,(x,y)=>{const n=hash(x,y,245);const border=(x<1||x>22||y<1||y>14);
 if(border)return C(140+n*30,80+n*25,50+n*20);
 const stripe=((x>>1)+(y>>1))%2;return stripe?C(160+n*30,40+n*20,40+n*20):C(120+n*20,30+n*15,30+n*15)});
const sBagWall=proc(20,16,(x,y)=>{
  const rowH=8,row=Math.floor(y/rowH),rowY=y%rowH;
  const offsetX=row*5;
  const bagX=(x+offsetX)%10;
  if(bagX<1)return C(55,45,30);
  if(rowY<1||rowY>=rowH-1)return C(45,38,24);
  const bulgeX=1-Math.abs(bagX-5)/5;
  const bulgeY=1-Math.abs(rowY-3.5)/3.5;
  const bulge=Math.max(0,bulgeX*bulgeY);
  const n=hash(x,y,700),v=130+n*25+bulge*35;
  return C(v*0.9,v*0.82,v*0.6);
});
const sBagWall2=sBagWall;
const sWire=proc(16,10,(x,y)=>{
  if(y===2||y===5)return C(130,130,130);
  if(x%3===0&&(y===0||y===1||y===7||y===8))return C(160,160,160);
  if(x%3===1&&(y===1||y===3||y===5))return C(150,150,150);
  return 0;
});
const sCzech=proc(20,20,(x,y)=>{
  const cx=9.5,cy=9.5,dx=x-cx,dy=y-cy,dist=Math.hypot(dx,dy);
  if(dist>9.5)return 0;
  const dDiag1=Math.abs(dx-dy)/Math.SQRT2;
  const dDiag2=Math.abs(dx+dy)/Math.SQRT2;
  const t=1.6;
  const onVertical=Math.abs(dx)<1.2&&dist<7;
  const inCrossing=(dDiag1<t&&dDiag2<t);
  if(dDiag1>=t&&dDiag2>=t&&!onVertical)return 0;
  const n=hash(x,y,500);
  let brightness=1.0;
  if(onVertical)brightness=0.85;
  if(inCrossing)brightness=0.68;
  if(dy<-2)brightness*=0.8;
  const base=105,v=base*brightness+n*25-15;
  return C(v,v*1.0,v*1.08);
});
const sTower=proc(22,48,(x,y)=>{
  if(y<5){if(x<2||x>19)return 0;return C(55,48,40)}
  if(y>=5&&y<32){
    if(x<2||x>19)return 0;
    if(y>=8&&y<=15){if(x>=5&&x<=7)return C(20,20,25);if(x>=14&&x<=16)return C(20,20,25)}
    if(y>=18&&y<=26&&(x===10||x===11))return C(30,30,35);
    const n=hash(x,y,450);return C(85+n*20,75+n*20,65+n*20);
  }
  if(y>=32&&y<47){if(x>=2&&x<=5)return C(60,52,45);if(x>=16&&x<=19)return C(60,52,45);return 0}
  return 0;
});
const sTent=proc(30,22,(x,y)=>{
  const cx=14.5;
  const halfW=Math.max(0,Math.floor((y/22)*14));
  const dxFromCx=x-cx,absDx=Math.abs(dxFromCx);
  if(absDx>halfW)return 0;
  if(y<=1){const n=hash(x,y,460);return C(40+n*15,38+n*15,32+n*15)}
  const cellX=Math.floor(x/3),cellY=Math.floor(y/3);
  const n=hash(cellX,cellY,461);
  let r,g,b;
  if(n<0.3){r=68;g=88;b=52}
  else if(n<0.55){r=88;g=72;b=48}
  else if(n<0.8){r=48;g=60;b=38}
  else{r=100;g=100;b=60}
  const doorTop=10;
  if(y>=doorTop){const doorW=(y-doorTop)*0.8;if(absDx<doorW)return C(15,15,12)}
  const side=dxFromCx<0?0.85:1.1;
  if(absDx>=halfW-1&&absDx<=halfW){r=Math.min(255,r*1.3);g=Math.min(255,g*1.3);b=Math.min(255,b*1.3)}
  return C(r*side,g*side,b*side);
});
const sBunker=proc(26,20,(x,y)=>{
  if(x<1||x>24||y<1||y>18)return C(90,90,100);
  if(y<3)return C(110,110,118);
  if(y>=8&&y<=10&&x>=5&&x<=20)return C(15,15,20);
  if(x<3||x>22)return C(100,100,110);
  const n=hash(x,y,470);return C(140+n*20,140+n*20,145+n*20);
});
const sGate=proc(16,20,(x,y)=>{
  if(y<2||y>17||x<2||x>13)return C(70,60,50);
  if(x%3===0)return C(100,90,80);
  if((x+y)%6===0)return C(90,80,70);
  if(x>=6&&x<=9&&y>=8&&y<=11)return C(40,35,30);
  return 0;
});
const sGateLight=proc(16,14,(x,y)=>{
  if(y<1||y>12||x<1||x>14)return C(60,50,40);
  if(x%4===0)return C(120,100,80);
  return 0;
});
// ==== NUEVOS PROPS ====
// Generador militar (motor diesel con carcasa)
const sGenerator=proc(22,18,(x,y)=>{
  if(x<1||x>20||y<1||y>16)return 0;
  // Carcasa superior
  if(y<3)return C(120,110,90);
  // Panel frontal
  if(x<2||x>19){
    const n=hash(x,y,900);return C(70+n*20,60+n*20,50+n*20);
  }
  // Rejillas de ventilación
  const rx=x%3,ry=Math.floor(y/2)%3;
  if(rx===0&&ry<2)return C(30,30,35);
  // Indicadores
  if(y>=4&&y<=6&&x>=4&&x<=8)return C(220,60,40);
  if(y>=4&&y<=6&&x>=10&&x<=14)return C(60,200,80);
  // Cuerpo
