function useItemAction(i){const it=P.inventory[i];if(!it)return;const d=ITEMS[it.id];if(d.ammo){P[d.ammo]+=d.amount*it.count;P.inventory[i]=null;msg('MUNICIÓN AÑADIDA','#ffd24a');SFX.pickup();hud(true);renderInv()}else if(d.slot){const old=P.eq[d.slot];P.eq[d.slot]={id:it.id,dur:it.dur!==undefined?it.dur:d.dur};P.inventory[i]=old?{id:old.id,count:1,dur:old.dur}:null;msg('EQUIPADO: '+d.name,'#9fd8ff');SFX.swap();hud(true);renderInv()}else if(d.heal||d.food||d.water){useItem(i)}else if(d.throwable){P.throwables[it.id]=(P.throwables[it.id]||0)+it.count;P.inventory[i]=null;msg('PREPARADO: '+d.name,'#9fd8ff');SFX.pickup();hud(true);renderInv()}else if(it.id==='briefcase'){msg('MALETÍN: SE VENDERÁ AL EXTRAER','#9fd8ff')}}
function equipInventoryWeapon(i){const it=P.inventory[i];if(!it)return;const wi=ITEMS[it.id].weapon;const slots=P.weaponSlots||(P.weaponSlots=[0,-1]);if(slots.includes(wi)){msg('ESA ARMA YA ESTÁ EQUIPADA','#ffb060');return}let slot=slots.indexOf(-1);if(slot<0){msg('DOS ARMAS EQUIPADAS: GUARDA UNA PRIMERO','#ffb060');return}slots[slot]=wi;P.weapons[wi]=true;P.weapon=wi;P.inventory[i]=null;P.reloading=0;P.reloadTotal=0;SFX.swap();hud(true);renderInv();msg('EQUIPADA: '+ITEMS[it.id].name,'#9fd8ff')}
function totalWeaponCount(){let n=(P.weaponSlots||[]).filter(w=>w!==-1&&w!=null).length;for(const it of P.inventory){if(it&&ITEMS[it.id]&&ITEMS[it.id].weapon!==undefined)n+=Math.max(1,it.count||1)}return n}
function openEquippedWeaponActions(slot){const wi=P.weaponSlots[slot];if(wi==null||wi<0)return;const id=WID[wi],el=$('itemActionButtons');el.innerHTML='';$('itemActionTitle').textContent=ITEMS[id].name;const total=totalWeaponCount(),locked=(slot===0&&total<3);$('itemActionDesc').textContent=locked?'Arma principal protegida: solo puedes guardarla o arrojarla cuando tengas 3 armas en total (equipadas y en inventario). Ahora tienes '+total+'.':itemDescription(id,ITEMS[id]);const add=(label,fn)=>{const b=document.createElement('button');b.textContent=label;b.onclick=()=>{$('itemActionScreen').classList.remove('on');fn()};el.appendChild(b)};if(locked){add('CERRAR',()=>{});}else{add('DESEQUIPAR / GUARDAR',()=>{const idx=P.inventory.findIndex(x=>!x);if(idx<0){msg('INVENTARIO LLENO','#ff6a5a');return}P.inventory[idx]={id,count:1};P.weaponSlots[slot]=-1;if(P.weapon===wi)P.weapon=(P.weaponSlots.find(x=>x>=0)??0);P.weapons[wi]=false;SFX.swap();hud(true);renderInv()});add('ARROJAR',()=>{P.weaponSlots[slot]=-1;P.weapons[wi]=false;if(P.weapon===wi)P.weapon=(P.weaponSlots.find(x=>x>=0)??0);msg('ARMA ARROJADA','#ffb060');SFX.ui();hud(true);renderInv()})}$('itemActionScreen').classList.add('on')}
function renderInv(){grid($('invGrid'),P.inventory,(i)=>openItemActions(i),(i)=>toSafe(i));renderEq();renderWeaponSlots();renderTh();renderSafe();
 const w=weight();$('invInfo').innerHTML='PESO <b>'+w.toFixed(1)+'</b>/'+MAXW+' KG · VALOR <b>$'+Math.round(sum('v'))+'</b> · REVENTA <b>$'+Math.round(sum('v')*RESALE_RATE)+'</b>'}
function toggleInv(){if(state!=='play')return;const p=$('invPanel');if(p.classList.contains('on'))p.classList.remove('on');else{if(!$('lootPanel').classList.contains('on')){renderInv();p.classList.add('on');fireHeld=false;SFX.ui()}}}
function openLoot(){
 if(state!=='play'||paused())return;
 if(nearAlly){nearAlly.following=true;nearAlly.awake=true;msg('¡ALIADO LIBERADO!','#9fd8ff');SFX.ally();hud(true);updateDailyProgress('allies',1);return}
 if(!nearC)return;
 if(nearC.isSafe){if(!nearC.opened){beginSafeCrack(nearC);return}if(!nearC.loot.length)return;$('lootPanel').firstElementChild.textContent='BOTÍN DE CAJA FUERTE';renderLoot(nearC);$('lootPanel').classList.add('on');fireHeld=false;SFX.ui();return}
 // NUEVO: curación al abrir cofre del puesto por primera vez
 if(nearC.cache&&nearC.healAvailable&&!nearC.healUsed){
   nearC.healUsed=true;
   if(P.hp<P.maxHp){
     const heal=30;
     P.hp=Math.min(P.maxHp,P.hp+heal);
     SFX.heal();
     msg('+'+heal+' HP · PUNTO DE CURACIÓN','#7dff8f');
     hud(true);
   }
 }
 if(nearC.cache){nearC.spr=sCacheOpen}
 $('lootPanel').firstElementChild.textContent=nearC.cache?'COFRE DEL PUESTO':(nearC.perm?'REGISTRAR CONTENEDOR':'SAQUEAR SOLDADO CAÍDO');
 renderLoot(nearC);$('lootPanel').classList.add('on');fireHeld=false;SFX.ui()
}
function renderLoot(c){grid($('lootGrid'),c.loot,i=>{const it=c.loot[i];if(!it)return;
 if(addInv(it.id,it.count)){
  c.loot.splice(i,1);
  SFX.pickup();msg('+ '+ITEMS[it.id].name,'#9fffa0');
  if(!c.loot.length){
   if(c.isSafe){SAFE_BOXES=SAFE_BOXES.filter(box=>box!==c);if(nearSafe===c)nearSafe=null;}
   else if(!c.perm)corpses.splice(corpses.indexOf(c),1);
   $('lootPanel').classList.remove('on');nearC=null;
   $('btnLoot').classList.remove('on','ally');$('btnLoot').textContent='SAQUEAR';
  } else renderLoot(c);
  hud(true)
 }})}

const SHOP_ITEMS={weapons:['shotgun','rifle','ak47','mg42','m24','rocketl'],armor:['helm1','helm2','helm3','vest1','vest2','vest3'],consumables:['ammo9','shells','bullets','ammo76239','ammo792','ammo76251','rockets','medkit','bandage','frag','smoke','molotov']};
function refreshMenuStats(){
 const el=$('menuStats');if(!el)return;
 const st=meta.stats,totalAch=Object.keys(meta.achievements).length;
 el.innerHTML='💵 <b>$'+meta.money+'</b> · NIVEL <b>'+meta.level+'</b> · XP <b>'+meta.xp+'/'+xpNeeded()+'</b><br>'+
  'PARTIDAS: <b>'+st.runs+'</b> · EXITOSAS: <b>'+st.wins+'</b>'+(st.runs>0?' ('+Math.round(st.wins*100/st.runs)+'%)':'')+'<br>'+
  'BAJAS: <b>'+st.kills+'</b> · PUESTOS: <b>'+(st.outpostsTaken||0)+'</b> · ALIADOS: <b>'+st.alliesRescued+'</b><br>'+
  'LOGROS: <b>'+totalAch+'/'+ACHIEVEMENTS.length+'</b><br>'+
  'IMPUESTOS: <b>$'+(st.totalTaxPaid||0)+'</b> · PERDIDO: <b>$'+(st.totalLostOnDeath||0)+'</b><br>'+
  (st.bestTime?'MEJOR TIEMPO: <b>'+st.bestTime.toFixed(1)+'s</b>':'')+
  (st.bestLoot?' · MEJOR: <b>$'+st.bestLoot+'</b>':'');
 const nb=$('nightmareBtn');
 if(meta.nightmareUnlocked){nb.style.display='';
  if(meta.nightmareActive){nb.classList.add('on');nb.textContent='💀 PESADILLA ON'}
  else{nb.classList.remove('on');nb.textContent='💀 PESADILLA'}
 } else nb.style.display='none'
}
function openShop(){refreshMarket();renderShop(shopTab);$('shopScreen').classList.add('on');$('menuScreen').classList.remove('on');SFX.ui()}
function closeShop(){$('shopScreen').classList.remove('on');$('menuScreen').classList.add('on');refreshMenuStats();SFX.ui()}
function openDaily(){rollDailyMissions();renderDaily();$('dailyScreen').classList.add('on');$('menuScreen').classList.remove('on');SFX.ui()}
function closeDaily(){$('dailyScreen').classList.remove('on');$('menuScreen').classList.add('on');refreshMenuStats();SFX.ui()}
function openAch(){renderAch();$('achScreen').classList.add('on');$('menuScreen').classList.remove('on');SFX.ui()}
function closeAch(){$('achScreen').classList.remove('on');$('menuScreen').classList.add('on');refreshMenuStats();SFX.ui()}
function renderAch(){
 const unlocked=Object.keys(meta.achievements).length;
 $('achCount').textContent=unlocked+'/'+ACHIEVEMENTS.length;
 const grid=$('achGrid');grid.innerHTML='';
 for(const a of ACHIEVEMENTS){
  const card=document.createElement('div');
  card.className='achCard'+(meta.achievements[a.id]?' unlocked':'');
  card.innerHTML='<div class="ic">'+a.icon+'</div><div class="info"><div class="nm">'+a.name+'</div><div class="ds">'+a.desc+'</div></div>';
  grid.appendChild(card)
 }
}
function renderDaily(){
 const grid=$('dailyGrid');grid.innerHTML='';
 const done=meta.dailyMissions.filter(m=>m.done).length;
 $('dailyCount').textContent=done+'/'+meta.dailyMissions.length;
 for(let i=0;i<meta.dailyMissions.length;i++){
  const m=meta.dailyMissions[i];
  const card=document.createElement('div');
  card.className='missionCard'+(m.claimed?' claimed':m.done?' done':'');
  const barPct=Math.min(100,(m.progress/m.target)*100);
  card.innerHTML='<div class="mt">'+m.desc+'</div>'+
   '<div class="md">Recompensa: <span style="color:#ffd24a">$'+m.reward+'</span></div>'+
   '<div class="mp">['+Math.min(m.progress,m.target)+'/'+m.target+'] '+barPct.toFixed(0)+'%'+(m.claimed?' · ✓ COBRADO':'')+'</div>'+
   (m.done&&!m.claimed?'<button class="mb">COBRAR RECOMPENSA</button>':'');
  if(m.done&&!m.claimed){const btn=card.querySelector('button');onTap(btn,()=>claimDailyMission(i))}
  grid.appendChild(card)
 }
}
function renderInsuranceBox(){
 const el=$('insuranceBox');
 const cost=insuranceCost(),totalVal=stashValue(meta.stash);
 if(meta.insuranceActive){
  el.className='insuranceBox active';
  el.innerHTML='<div class="it">🛡️ SEGURO ACTIVO</div>'+
   '<div class="id">Cubrirá el 50% ($'+Math.round(totalVal*INSURANCE_RECOVER)+') del stash si mueres.</div>'+
   '<button id="insBtn" style="background:#ff5a5a;color:#fff;border-bottom-color:#8a1a1a">CANCELAR SEGURO</button>';
 } else {
  el.className='insuranceBox';
  el.innerHTML='<div class="it">🛡️ SEGURO DE EQUIPO</div>'+
   '<div class="id">Coste: $'+cost+' · Recupera 50% ($'+Math.round(totalVal*INSURANCE_RECOVER)+') al morir.</div>'+
   '<button id="insBtn" style="background:#9fd8ff;color:#001a2a;border-bottom-color:#3a6a8a">CONTRATAR POR $'+cost+'</button>';
 }
 onTap($('insBtn'),()=>{
  if(meta.insuranceActive){meta.insuranceActive=false;meta.money+=insuranceCost();msg('SEGURO CANCELADO +$'+insuranceCost(),'#7dff8f')}
  else{const c=insuranceCost();
   if(meta.money<c){SFX.error();msg('SIN DINERO','#ff6a5a');return}
   if(stashValue(meta.stash)<=0){SFX.error();msg('NADA QUE ASEGURAR','#ff6a5a');return}
   meta.money-=c;meta.insuranceActive=true;msg('SEGURO ACTIVADO -$'+c,'#9fd8ff')}
  SFX.buy();saveMeta();renderShop(shopTab);refreshMenuStats()
 })
}
function renderShop(tab){
 $('shopMoney').textContent=meta.money;
 const mb=$('marketBanner');
 const mult=meta.marketMult;
 const color=mult<1?'#7dff8f':mult>1.2?'#ff6a5a':'#ffd24a';
 const label=mult<1?'OFERTA':mult>1.2?'CARO':'NORMAL';
 mb.innerHTML='📈 MERCADO: <b style="color:'+color+'">×'+mult.toFixed(2)+'</b> ('+label+') · Cambia cada día';
 renderInsuranceBox();
 document.querySelectorAll('.shopTabs button').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));
 const grid=$('shopGrid');grid.innerHTML='';
 const ids=SHOP_ITEMS[tab]||[];
 for(const id of ids){
  const d=ITEMS[id];
  const has=stashHasItem(id);
  const levelOK=!d.minLevel||meta.level>=d.minLevel;
  const price=marketPrice(d.v);
  const cant=has||!stashHasSpace()||meta.money<price||!levelOK;
  const card=document.createElement('div');
  card.className='shopCard'+(cant?' cant':'');
  const wInfo=d.weapon!==undefined?'ARMA · '+WEAPONS[d.weapon].name:(d.slot?('ARMADURA N'+d.lvl):(d.ammo?('+'+d.amount+' por unidad'):(d.heal?('+'+d.heal+' PS'):(d.throwable?'ARROJADIZO':''))));
  const lvlTag=d.minLevel?'<span class="lvlTag">N'+d.minLevel+'</span>':'';
  const priceColor=meta.marketMult<1?'#7dff8f':meta.marketMult>1.2?'#ff8a8a':'#ffd24a';
