  ctx.fillStyle=col+a+')';ctx.fillText(sym,sp.x,sp.y)
 }}
function hexA(hex,a){const r=parseInt(hex.slice(1,3),16),g=parseInt(hex.slice(3,5),16),b=parseInt(hex.slice(5,7),16);return'rgba('+r+','+g+','+b+','+a+')'}
function render(){
 const W=RW,H=RH,hh=H/2|0,dx=Math.cos(P.a),dy=Math.sin(P.a),px=-dy*PL,py=dx*PL;
 const playerIndoor=isInsideBuilding(P.x,P.y);
 const r0x=dx-px,r0y=dy-py,r1x=dx+px,r1y=dy+py,posZ=.5*projDist;
 if(playerIndoor){
  for(let y=0;y<hh;y++){const pyc=hh-y;if(pyc<=0)continue;
   const rd=posZ/pyc;
   if(rd>30){const fogC=C(FOG[0],FOG[1],FOG[2]);buf.fill(fogC,y*W,y*W+W);continue}
   const sx=rd*(r1x-r0x)/W,sy=rd*(r1y-r0y)/W;
   let fx=P.x+rd*r0x,fy=P.y+rd*r0y;
   const si=Math.max(3,Math.min(SH-1,(SH-1)*(1-rd/40)|0));
   const sd=gShCeil[si],o=y*W;
   for(let x=0;x<W;x++){const tx=((fx*32)|0)&63,ty=((fy*32)|0)&63;buf[o+x]=sd[(ty<<6)+tx];fx+=sx;fy+=sy}}
 } else {
  const off=Math.floor(((P.a/6.283185)%1+1)%1*SW),first=Math.min(W,SW-off);
  for(let y=0;y<hh;y++){buf.set(sky.subarray(y*SW+off,y*SW+off+first),y*W);if(first<W)buf.set(sky.subarray(y*SW,y*SW+W-first),y*W+first)}
 }
 const fogC=C(FOG[0],FOG[1],FOG[2]);
 for(let y=hh;y<H;y++){const p=y-hh;if(p<=0)continue;const rd=posZ/p;if(rd>45){buf.fill(fogC,y*W,y*W+W);continue}
  const sx=rd*(r1x-r0x)/W,sy=rd*(r1y-r0y)/W;let fx=P.x+rd*r0x,fy=P.y+rd*r0y;const si=shadeAt(rd),o=y*W;
  for(let x=0;x<W;x++){const ix=fx|0,iy=fy|0;let g=2;if(ix>=0&&iy>=0&&ix<MW&&iy<MH)g=gmap[iy*MW+ix];
   let col=gSh[g]?gSh[g][si][((((fy*32)|0)&63)<<6)+(((fx*32)|0)&63)]:gSh[0][si][((((fy*32)|0)&63)<<6)+(((fx*32)|0)&63)];
   if(g===4){const frac=fx-Math.floor(fx);if(frac>0.44&&frac<0.56){const dashFrac=(fy*4)%1;if(dashFrac<0.6)col=C(220,180,50)}}
   else if(g===5){const frac=fy-Math.floor(fy);if(frac>0.44&&frac<0.56){const dashFrac=(fx*4)%1;if(dashFrac<0.6)col=C(220,180,50)}}
   buf[o+x]=col;fx+=sx;fy+=sy}}
 for(let x=0;x<W;x++){const cx=2*x/W-1,rx=dx+px*cx,ry=dy+py*cx;let mx=P.x|0,my=P.y|0;const ddx=rx===0?1e30:Math.abs(1/rx),ddy=ry===0?1e30:Math.abs(1/ry);
  let stx,sty,sdx,sdy;if(rx<0){stx=-1;sdx=(P.x-mx)*ddx}else{stx=1;sdx=(mx+1-P.x)*ddx}if(ry<0){sty=-1;sdy=(P.y-my)*ddy}else{sty=1;sdy=(my+1-P.y)*ddy}
  let side=0,tv=0,g=0;while(g++<200){if(sdx<sdy){sdx+=ddx;mx+=stx;side=0}else{sdy+=ddy;my+=sty;side=1}
   if(mx<0||my<0||mx>=MW||my>=MH){tv=1;break}tv=map[my*MW+mx];if(tv)break}
  let pd=side===0?sdx-ddx:sdy-ddy;if(pd<.02)pd=.02;zbuf[x]=pd;
  const lh=projDist/pd,ds=(-lh/2+H/2)|0,de=(lh/2+H/2)|0;let wx=side===0?P.y+pd*ry:P.x+pd*rx;wx-=Math.floor(wx);
  let tx=(wx*TEX)|0;if((side===0&&rx>0)||(side===1&&ry<0))tx=TEX-tx-1;tx=clamp(tx,0,TEX-1);
  const ti=(tv>=1&&tv<=7)?tv:1,sd=(side?wShD:wSh)[ti][shadeAt(pd)],st=TEX/lh;let tp=(ds-H/2+lh/2)*st;
  const y0=ds<0?0:ds,y1=de>H?H:de;if(ds<0)tp=(0-H/2+lh/2)*st;
  for(let y=y0;y<y1;y++){let ty=tp|0;if(ty>=TEX)ty=TEX-1;tp+=st;buf[y*W+x]=sd[(ty<<6)+tx]}}
 SL.length=0;pn=0;visibleEnemies.length=0;
 for(const d of decals)add(d.x,d.y,d.spr,d.wh,d.ww,0,0,0,0,0);
 for(const d of decos)if((d.x-P.x)**2+(d.y-P.y)**2<2000)add(d.x,d.y,d.spr,d.wh,d.ww,d.z0||0,0,0,0,0);
 for(const box of SAFE_BOXES)if(!box.opened&&(box.x-P.x)**2+(box.y-P.y)**2<2000)add(box.x,box.y,box.spr,box.wh,box.ww,0,0,0,0,0);
 for(const s of smokes){if((s.x-P.x)**2+(s.y-P.y)**2>1200)continue;
  const fadeIn=Math.min(1,(s.maxLife-s.life)/.6),fadeOut=Math.min(1,s.life/1.5),fade=fadeIn*fadeOut;
  for(let i=0;i<8;i++){const a=(i/8)*6.28+s.life*.4+s.seed,r=s.radius*(.25+hash(i,0,90)*.55);
   const px2=s.x+Math.cos(a)*r,py2=s.y+Math.sin(a)*r,pz=.4+hash(i,1,90)*1.6+Math.sin(gt+i)*.15;
   add(px2,py2,sSmoke,1.9*fade,1.9*fade,pz,false,false,0,0)}}
 for(const f of fires){if((f.x-P.x)**2+(f.y-P.y)**2>900)continue;
  const fade=Math.min(1,f.life/.5);
  for(let i=0;i<5;i++){const a=(i/5)*6.28+gt*2+hash(i,0,91)*6,r=f.radius*(.3+hash(i,1,91)*.5);
   const px2=f.x+Math.cos(a)*r*(.8+Math.sin(gt*3+i)*.15),py2=f.y+Math.sin(a)*r*(.8+Math.cos(gt*3+i)*.15);
   const pz=.2+Math.abs(Math.sin(gt*4+i))*.7;
   add(px2,py2,sFire,.9*fade,.9*fade,pz,false,false,0,0)}}
 for(const e of enemies){
  if(!e.alive)continue;
  const f=(e.wt*4|0)%2;const sp2=e.fr[f]||e.fr[0];
  const beforePn=pn;
  add(e.x,e.y,sp2,e.height,e.height*sp2.w/sp2.h,0,e.hurtT>0,((e.wt*2|0)%2)===1,0,0);
  const o=pool[beforePn];o.e=e;o.isEnemy=true
 }
 for(const a of allies){
  if(!a.alive)continue;
  const f=(a.wt*4|0)%2;const sp2=a.fr[f]||a.fr[0];
  const beforePn=pn;
  add(a.x,a.y,sp2,a.height||.62,(a.height||.62)*sp2.w/sp2.h,0,0,0,0,0);
  const o=pool[beforePn];o.e=a;o.isEnemy=true;o.isAlly=true
 }
 for(const c of corpses)if((c.x-P.x)**2+(c.y-P.y)**2<1200)add(c.x,c.y,c.spr,c.wh,c.ww,0,0,0,0,0);
 for(const p of pickups)if(!p.taken)add(p.x,p.y,p.spr,.42,.42,.04,0,0,Math.sin(gt*3+p.x)*.04,0);
 for(const p of projs){const h=p.big?.5:p.small?.18:.3;add(p.x,p.y,sShot,h,h,.35,0,0,0,0)}
 for(const p of rockets)add(p.x,p.y,sRocket,.45,.45,.4,0,0,0,1);
 for(const g of throwables){const sp3=g.type==='frag'?sFragGren:g.type==='smoke'?sSmokeGren:sMolotov;add(g.x,g.y,sp3,.32,.32,g.z,false,false,0,0)}
 for(const g of eGrenades){add(g.x,g.y,sFragGren,.32,.32,g.z,false,false,0,0)}
 add(BEACON.x,BEACON.y,sBeacon,2.2,1.1,0,gt<EXT_AT,0,0,1);
 SL.sort((a,b)=>b.d2-a.d2);
 const inv=1/(px*dy-dx*py);
 for(const s of SL){
  const sx=s.x-P.x,sy=s.y-P.y,tX=inv*(dy*sx-dx*sy),tY=inv*(-py*sx+px*sy);
  if(tY<.25)continue;
  const scX=(W/2)*(1+tX/tY),sc=projDist/tY,sH=s.wh*sc,sW=s.ww*sc,bY=H/2+(.5-s.z0+s.bob)*sc,tp=bY-sH;
  const dsx=Math.floor(scX-sW/2),dex=Math.ceil(scX+sW/2);
  let sh=shadeAt(tY);if(s.br)sh=SH-1;
  const sp4=s.sp,tbl=s.hurt?(sp4.red||(sp4.red=shades(sp4.data,1,1))):sp4.sh,sd=tbl[sh];
  const x0=Math.max(0,dsx),x1=Math.min(W,dex),ys=Math.max(0,Math.floor(tp)),ye=Math.min(H,Math.ceil(bY)),iw=1/Math.max(1e-4,sW),ih=1/Math.max(1e-4,sH);
  let drewAny=false;
  for(let x=x0;x<x1;x++){
   if(tY>=zbuf[x])continue;
   drewAny=true;
   let tx=((x-dsx)*sp4.w*iw)|0;tx=clamp(tx,0,sp4.w-1);if(s.flip)tx=sp4.w-1-tx;
   for(let y=ys;y<ye;y++){let ty=((y-tp)*sp4.h*ih)|0;ty=clamp(ty,0,sp4.h-1);const c=sd[ty*sp4.w+tx];if(c)buf[y*W+x]=c}}
  if(s.isEnemy&&drewAny){
   const e=s.e;const centerX=Math.floor(scX);
   if(centerX>=0&&centerX<W&&tY<zbuf[centerX]){
    visibleEnemies.push({e:e,x:scX,y:tp-6,dist:tY,sc:sc,isAlly:s.isAlly})
   }
  }
 }
 for(const p of parts){const sx=p.x-P.x,sy=p.y-P.y,tX=inv*(dy*sx-dx*sy),tY=inv*(-py*sx+px*sy);if(tY<.3)continue;
  const X=((W/2)*(1+tX/tY))|0,sc=projDist/tY,sz=Math.max(1,.05*sc|0),Y=(H/2+.1*sc)|0;
  for(let a=-sz;a<=sz;a++)for(let b=-sz;b<=sz;b++){const u=X+a,v=Y+b;if(u<0||u>=W||v<0||v>=H||tY>=zbuf[u])continue;buf[v*W+u]=p.col}}
 // Reflectores de torre (después de las partículas, sobre el framebuffer)
 const reflectR=0;
 for(const t of fortTowers){
  const dxr=t.x-P.x,dyr=t.y-P.y;const dd=dxr*dxr+dyr*dyr;
  if(dd>200)continue;
  const sxr=dxr*dx-dyr*dy,syr=dxr*dy+dyr*dx;
  if(syr<=0.3)continue;
  const scrX=(W/2)*(1+sxr/syr),scrY=H/2+(0.5-t.z)*(projDist/syr),sc=projDist/syr;
  // Halo del reflector
  const a=t.phase+gt*t.speed;
  const rx=Math.cos(a)*0.3,ry=Math.sin(a)*0.3;
  const ang=Math.atan2(ry,rx);
  const len=Math.min(40,30*sc/60);
  ctx.save();
  ctx.globalAlpha=0.12+0.08*Math.sin(gt*3);
  const g=ctx.createRadialGradient(scrX,scrY,0,scrX,scrY,len*sc*0.4);
  g.addColorStop(0,'rgba(255,255,220,0.65)');
  g.addColorStop(0.5,'rgba(255,240,180,0.25)');
  g.addColorStop(1,'rgba(255,220,120,0)');
  ctx.fillStyle=g;
  ctx.beginPath();
  ctx.moveTo(scrX,scrY);
  ctx.arc(scrX,scrY,len*sc*0.4,ang-0.35,ang+0.35);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
 }
 ctx.putImageData(img,0,0);
 const tint=currentTint();if(tint){ctx.fillStyle=tint;ctx.fillRect(0,0,W,H)}
 if(weather==='rain'){ctx.strokeStyle='rgba(180,200,220,.55)';ctx.lineWidth=1;ctx.beginPath();
  for(const r of rain){ctx.moveTo(r.x,r.y);ctx.lineTo(r.x+r.vx*.02,r.y+r.vy*.02)}ctx.stroke()}
 drawHudFx(W,H);drawEnemyBars(W,H);weapon(W,H);minimap()
}
const WP=[
 [['#2a2a32',-7,62,14,52],['#46465a',-9,34,18,34],['#62627a',-11,20,22,20],['#16161c',-3,70,6,12],['#a0a0b4',-2,68,4,3],['#d9a77c',-12,14,24,14]],
 [['#22242c',-14,74,12,60],['#22242c',2,74,12,60],['#3c404e',-15,44,30,30],['#565a6c',-17,26,34,26],['#14161c',-12,82,10,10],['#14161c',2,82,10,10],['#7c8196',-11,78,8,3],['#d9a77c',-14,14,28,14]],
 [['#1c1d22',-5,92,10,70],['#30333a',-12,50,24,34],['#44474f',-14,28,28,24],['#0e0f12',-3,100,6,12],['#5a5d68',-9,68,18,6],['#22242c',-6,40,12,22],['#d9a77c',-14,14,28,14]],
 [['#5a4329',-10,94,20,74],['#25292a',-5,76,10,50],['#6b5232',-14,46,28,30],['#313538',-17,30,34,18],['#17191a',-4,24,8,28],['#25292a',-3,98,6,14],['#d9a77c',-14,14,28,14]],
 [['#333638',-15,96,30,72],['#505457',-20,60,40,28],['#222629',-24,40,48,18],['#17191b',-5,25,10,35],['#62676a',-7,75,14,8],['#242729',-17,100,34,14],['#d9a77c',-14,14,28,14]],
 [['#333b32',-5,100,10,78],['#3e493b',-12,68,24,32],['#68745e',-14,42,28,24],['#171b17',-3,27,6,34],['#242b23',-8,83,16,8],['#d9a77c',-13,14,26,14]],
 [['#2e332a',-10,34,20,14],['#0e0f0c',-6,33,12,8],
  ['#3a3f36',-6,78,12,54],['#555c4d',-5,78,3,54],['#262a22',3,78,3,54],
  ['#8b5a2b',-9,62,18,24],['#6b4220',-9,62,18,3],['#6b4220',-9,41,18,3],['#a06a35',-6,59,3,17],
  ['#1b1d1b',-17,72,9,24],['#7fb2e5',-16,71,7,3],['#101210',-16,50,7,3],['#2a2d29',-9,64,3,5],
  ['#5d6f4a',-10,94,20,16,1],['#2b2b2b',-10,87,20,3,1],['#4a5a3c',-7,103,14,9,1],['#35352f',-4,108,8,5,1],['#b8b8b0',-1.5,111,3,3,1],
  ['#d9a77c',-11,54,22,9],['#b98a62',-11,54,22,2],['#d9a77c',-14,14,28,14]]
 ];
 function weapon(W,H){const u=H/243,cx=W/2+Math.sin(P.bob)*W*.012;
