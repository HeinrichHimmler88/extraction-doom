# EXTRACTION DOOM — Fase 2: plan de modularización real

## Estado de esta entrega

Esta entrega es una preparación conservadora. **No cambia el comportamiento del juego** ni sustituye la versión estable. La fase 1 está validada: `dist/game.js` se reconstruye exactamente desde los 21 fragmentos y pasa la comprobación de sintaxis.

Los 21 archivos actuales son cortes consecutivos del mismo JavaScript, no módulos funcionales independientes. No deben convertirse en `import/export` ni reordenarse a ciegas porque el juego comparte muchas variables y depende del orden de inicialización.

## Objetivo de la fase 2

Migrar gradualmente de fragmentos consecutivos a módulos funcionales reales, preservando el juego entre cada paso.

### Orden propuesto

1. **Inventario de dependencias**: identificar las variables globales del IIFE y quién las lee/escribe.
2. **Datos de configuración**: separar primero tablas de datos que no muten durante la partida (por ejemplo, definiciones de armas y objetos), después de confirmar sus dependencias.
3. **Interfaz**: aislar renderizado de inventario/tienda/HUD sin cambiar reglas de juego.
4. **Sistemas**: extraer un sistema de bajo acoplamiento por vez; por ejemplo, cajas fuertes y coleccionables.
5. **Combate y mundo**: abordar armas, enemigos, mapa y extracción solo cuando exista un contrato de estado claro.
6. **Retirada gradual del concatenador**: pasar a módulos ES (`import/export`) únicamente cuando cada sistema tenga interfaces definidas.

## Reglas de seguridad

- Nunca trabajar sobre `principal`.
- Mantener `backup/antes-de-modularizar` intacta.
- Hacer cada cambio en `refactorización/modularización`.
- Un cambio por commit y describirlo en el mensaje.
- Ejecutar `python build.py` y `python validate.py` antes de los cambios intencionales.
- Después de cada cambio, probar el menú, iniciar partida, movimiento móvil, disparo/recarga, cambio de armas, inventario, botín/cajas fuertes, extracción, muerte/retorno al menú y persistencia.
- No borrar el HTML original ni `dist/game.js` hasta que la nueva arquitectura esté verificada.
- Si una prueba falla, revertir solo el último cambio.

## Criterio de aceptación

La fase 2 no se considera completada solo porque existan más archivos. Debe haber módulos con responsabilidades claras, interfaces explícitas y una prueba de regresión por cada extracción, sin diferencias involuntarias en la jugabilidad.
