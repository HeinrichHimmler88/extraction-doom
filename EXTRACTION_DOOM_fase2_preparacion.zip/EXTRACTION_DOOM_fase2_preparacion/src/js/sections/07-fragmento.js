const ACHIEVEMENTS=[
 {id:'first_blood',name:'Primera Sangre',desc:'Elimina a tu primer enemigo',icon:'🩸'},
 {id:'sniper_ace',name:'Francotirador',desc:'5 bajas a más de 20m',icon:'🎯'},
 {id:'berserker',name:'Berserker',desc:'10 bajas con cuerpo a cuerpo',icon:'👊'},
 {id:'ghost',name:'Fantasma',desc:'Extrae sin recibir daño',icon:'👻'},
 {id:'rich',name:'Magnate',desc:'Extrae con $5000 o más',icon:'💰'},
 {id:'speedrun',name:'Velocista',desc:'Extrae antes de los 4:00',icon:'⏱️'},
 {id:'demolisher',name:'Demoledor',desc:'3 bajas con 1 granada',icon:'💥'},
 {id:'surgeon',name:'Cirujano',desc:'10 headshots acumulados',icon:'🔪'},
 {id:'survivor',name:'Superviviente',desc:'Alcanza nivel 10',icon:'⭐'},
 {id:'commander_down',name:'Comandante Caído',desc:'Elimina al comandante',icon:'🎖️'},
 {id:'collector',name:'Coleccionista',desc:'Extrae con 12 items',icon:'📦'},
 {id:'veteran',name:'Veterano',desc:'Completa 10 partidas',icon:'🏅'},
];
const MISSION_TYPES=[
 {id:'kill3',desc:'Elimina 3 enemigos',target:3,reward:200,type:'kills'},
 {id:'kill6',desc:'Elimina 6 enemigos',target:6,reward:450,type:'kills'},
 {id:'outpost1',desc:'Toma 1 puesto de vigilancia',target:1,reward:600,type:'outposts'},
 {id:'outpost2',desc:'Toma 2 puestos de vigilancia',target:2,reward:1200,type:'outposts'},
 {id:'extract500',desc:'Extrae con $500+ en botín',target:500,reward:250,type:'extract_money'},
 {id:'extract1000',desc:'Extrae con $1000+ en botín',target:1000,reward:500,type:'extract_money'},
 {id:'headshot2',desc:'Consigue 2 headshots',target:2,reward:300,type:'headshots'},
 {id:'obj1',desc:'Completa 1 objetivo secundario',target:1,reward:400,type:'objectives'},
 {id:'ally1',desc:'Rescata a 1 aliado',target:1,reward:350,type:'allies'},
 {id:'nodeath',desc:'Extrae sin morir',target:1,reward:300,type:'no_death_win'},
 {id:'survive4',desc:'Sobrevive 4 minutos en partida',target:240,reward:400,type:'survive_time'},
 {id:'rifle_kill',desc:'Mata 2 enemigos con rifle',target:2,reward:350,type:'rifle_kills'},
];
function getTodayStr(){const d=new Date();return d.getFullYear()+'-'+(d.getMonth()+1)+'-'+d.getDate()}
function rollDailyMissions(){
 const today=getTodayStr();
 if(meta.dailyDate===today&&meta.dailyMissions&&meta.dailyMissions.length===3)return;
 meta.dailyDate=today;
 const pool=[...MISSION_TYPES].sort(()=>Math.random()-0.5);
 meta.dailyMissions=pool.slice(0,3).map(m=>({...m,progress:0,done:false,claimed:false}));
 saveMeta();
}
function updateDailyProgress(type,amount){
 if(!meta.dailyMissions)return;
 for(const m of meta.dailyMissions){
  if(m.claimed||m.type!==type)continue;
  if(type==='extract_money'||type==='survive_time'){if(amount>m.progress)m.progress=Math.min(m.target,amount)}
  else if(type==='no_death_win')m.progress=1;
  else m.progress=Math.min(m.target,m.progress+amount);
  if(m.progress>=m.target&&!m.done){m.done=true;showAchievementPopup({name:'¡MISIÓN COMPLETADA!',desc:m.desc,icon:'📋'});SFX.win()}
 }
 saveMeta();
}
function claimDailyMission(idx){
 const m=meta.dailyMissions[idx];
 if(!m||!m.done||m.claimed)return;
 m.claimed=true;meta.money+=m.reward;
 SFX.buy();saveMeta();renderDaily();refreshMenuStats();
 msg('RECOMPENSA: +$'+m.reward,'#7dff8f');
}
function refreshMarket(){
 const today=getTodayStr();
 if(meta.marketDate===today&&meta.marketMult>0)return;
 meta.marketDate=today;meta.marketMult=0.75+Math.random()*0.75;saveMeta();
}
function marketPrice(base){return Math.round(base*meta.marketMult)}

let P,enemies,corpses,decos,projs,parts,pickups,rockets=[],throwables=[],smokes=[],fires=[],noises=[],eGrenades=[],rain=[],state='menu',kills=0,total=0,ext=0,gt=0,fireHeld=false,nearC=null,lastHp=-1,lastAm=-1,lastW=-1,lF=-1,lW=-1,lO=-1,lWt=-1,lTh='',lastBtnSwap='';
let hitMarkers=[],dmgNumbers=[],dmgDirs=[],decals=[],visibleEnemies=[];
let objectives=[],allies=[],noDamageTimer=0,milBoxesLooted=0,nearAlly=null,lastObjHtml='',nearCache=null;
let weather='clear',dayPhase=0,shopTab='weapons',runStats={},lastEco={gross:0,tax:0,net:0},outpostsTaken=0,currentOutpostShown=null;
let revealedOutposts=new Set();

const DEFAULT_META={
 money:0,xp:0,level:1,stash:new Array(12).fill(null),safeStash:new Array(2).fill(null),
 insuranceActive:false,marketMult:1.0,marketDate:'',dailyMissions:[],dailyDate:'',
 stats:{runs:0,wins:0,kills:0,bestTime:0,bestLoot:0,totalEarned:0,kills_soldier:0,kills_heavy:0,kills_sniper:0,kills_shotgunner:0,kills_officer:0,kills_dog:0,kills_commander:0,objectivesDone:0,alliesRescued:0,totalTaxPaid:0,totalLostOnDeath:0,outpostsTaken:0},
 achievements:{},achievementProgress:{longKills:0,meleeKills:0,headshots:0},
 nightmareUnlocked:false,nightmareActive:false
};
let meta=JSON.parse(JSON.stringify(DEFAULT_META));
function loadMeta(){
 try{const s=localStorage.getItem('exd_meta');
  if(s){const m=JSON.parse(s);
   if(m&&typeof m==='object'){Object.assign(meta,m);
    if(!Array.isArray(meta.stash)||meta.stash.length!==12)meta.stash=new Array(12).fill(null);
    if(!Array.isArray(meta.safeStash)||meta.safeStash.length!==2)meta.safeStash=new Array(2).fill(null);
    if(typeof meta.insuranceActive!=='boolean')meta.insuranceActive=false;
    if(typeof meta.marketMult!=='number'||meta.marketMult<=0)meta.marketMult=1.0;
    if(typeof meta.marketDate!=='string')meta.marketDate='';
    if(!Array.isArray(meta.dailyMissions))meta.dailyMissions=[];
    if(typeof meta.dailyDate!=='string')meta.dailyDate='';
    if(!meta.stats)meta.stats={...DEFAULT_META.stats};
    else meta.stats={...DEFAULT_META.stats,...meta.stats};
    if(!meta.achievements)meta.achievements={};
    if(!meta.achievementProgress)meta.achievementProgress={longKills:0,meleeKills:0,headshots:0};
    else meta.achievementProgress={longKills:0,meleeKills:0,headshots:0,...meta.achievementProgress};
    if(typeof meta.nightmareUnlocked!=='boolean')meta.nightmareUnlocked=false;
    if(typeof meta.nightmareActive!=='boolean')meta.nightmareActive=false}
  }}catch(e){}
}
function saveMeta(){try{localStorage.setItem('exd_meta',JSON.stringify(meta))}catch(e){}}
function xpForLevel(l){return Math.round(100*Math.pow(l,1.6))}
function xpNeeded(){return xpForLevel(meta.level)}
function addXp(amount){
 meta.xp+=amount;let leveled=false;
 while(meta.xp>=xpNeeded()){meta.xp-=xpNeeded();meta.level++;meta.money+=500;leveled=true}
 if(leveled){msg('¡NIVEL '+meta.level+'! +$500','#ffd24a');SFX.win()}
 if(meta.level>=10)unlockAchievement('survivor');
 saveMeta();
}
function unlockAchievement(id){
 if(meta.achievements[id])return;
 const ach=ACHIEVEMENTS.find(a=>a.id===id);
 if(!ach)return;
 meta.achievements[id]=Date.now();
 saveMeta();showAchievementPopup(ach);SFX.win();
}
function showAchievementPopup(ach,customClass){
 const popup=document.createElement('div');
 popup.className='achievement-popup'+(customClass?' '+customClass:'');
 popup.innerHTML='<div class="ic">'+ach.icon+'</div>'+
  '<div class="info"><div class="t1">'+(customClass==='outpost'?'PUESTO TOMADO':'DESBLOQUEADO')+'</div>'+
  '<div class="t2">'+ach.name+'</div>'+
  '<div class="t3">'+ach.desc+'</div></div>';
 document.body.appendChild(popup);
 setTimeout(()=>popup.classList.add('show'),60);
 setTimeout(()=>{popup.classList.remove('show');setTimeout(()=>popup.remove(),600)},4200);
}
const EXT_AT=240;

function updateFogFromPhase(){
 let base=[196,212,230];
 if(weather==='rain')base=[base[0]*.7,base[1]*.72,base[2]*.8];
 else if(weather==='fog')base=[base[0]*.9+20,base[1]*.9+20,base[2]*.9+20];
 else if(weather==='sandstorm')base=[base[0]*1.05+30,base[1]*.85+15,base[2]*.55];
 FOG=base.map(v=>Math.max(0,Math.min(255,v)));
}
function applyAtmosphere(){
 updateFogFromPhase();
 if(weather!==bakedKey){
  bakedKey=weather;
  gSh=[shades(tAsph),shades(tSide),shades(tGrass),shades(tDirt),shades(tAsph),shades(tAsph),shades(tMilFloor)];
  gShCeil=shades(tCeil);buildWallShades();
  for(const q of ALLSPR){q.sh=shades(q.data);q.red=null}
  buildSky();
 }
}
function currentTint(){
 if(dayPhase<.35)return null;
 const t=(dayPhase-.35)/.65;return'rgba(255,176,96,'+(t*0.16).toFixed(3)+')';
}
function updWeather(dt){
 if(weather==='rain'){for(let i=rain.length-1;i>=0;i--){const r=rain[i];r.y+=r.vy*dt;r.x+=r.vx*dt;if(r.y>RH+10||r.x<-10||r.x>RW+10)rain.splice(i,1)}
  while(rain.length<120)rain.push({x:Math.random()*RW,y:Math.random()*RH,vy:400+Math.random()*200,vx:-30-Math.random()*40})}
 if(weather==='sandstorm'&&Math.random()<.5)parts.push({x:P.x+(Math.random()-.5)*30,y:P.y+(Math.random()-.5)*30,vx:-8,vy:0,life:1,col:C(200,160,90)});
}

