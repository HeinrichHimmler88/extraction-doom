#!/usr/bin/env python3
"""Comprueba que los fragmentos reconstruyen exactamente el JS y CSS originales."""
from pathlib import Path
import re, subprocess, sys
ROOT = Path(__file__).resolve().parent
original = (ROOT / "EXTRACTION_DOOM_original.html").read_text(encoding="utf-8")
css = re.search(r"<style>(.*?)</style>", original, re.S | re.I)
js = re.search(r"<script>(.*?)</script>", original, re.S | re.I)
if not css or not js:
    raise SystemExit("ERROR: no se pudieron localizar los bloques originales.")
css_now = (ROOT / "src" / "css" / "game.css").read_text(encoding="utf-8")
parts = sorted((ROOT / "src" / "js" / "sections").glob("*-fragmento.js"))
js_now = "".join(p.read_text(encoding="utf-8") for p in parts)
if css.group(1) != css_now:
    raise SystemExit("ERROR: game.css ya no coincide con el CSS original.")
if js.group(1) != js_now:
    raise SystemExit("ERROR: los fragmentos JS ya no coinciden exactamente con el JS original.")
print(f"OK: CSS exacto; JavaScript reconstruido exactamente desde {len(parts)} fragmentos.")
try:
    r = subprocess.run(["node", "--check", str(ROOT / "dist" / "game.js")], check=False)
except FileNotFoundError:
    print("AVISO: Node.js no está instalado; no se verificó sintaxis de dist/game.js.")
    sys.exit(0)
if r.returncode:
    raise SystemExit("ERROR: la sintaxis de dist/game.js es inválida.")
print("OK: sintaxis de dist/game.js válida.")
