 const earned=gross-tax;
 lastEco.gross=gross;lastEco.tax=tax;lastEco.net=earned;
 meta.money+=earned;meta.stats.runs++;meta.stats.wins++;meta.stats.kills+=kills;
 if(!meta.stats.bestTime||gt<meta.stats.bestTime)meta.stats.bestTime=gt;
 if(earned>meta.stats.bestLoot)meta.stats.bestLoot=earned;
 meta.stats.totalEarned+=earned;meta.stats.objectivesDone+=objBonus;meta.stats.alliesRescued+=allyBonus;meta.stats.totalTaxPaid+=tax;
 updateDailyProgress('extract_money',currentVal);
 updateDailyProgress('objectives',objBonus);
 updateDailyProgress('allies',allyBonus);
 updateDailyProgress('no_death_win',1);
 updateDailyProgress('survive_time',gt);
 if(meta.stats.wins>=3&&!meta.nightmareUnlocked){
  meta.nightmareUnlocked=true;saveMeta();
  setTimeout(()=>{const p=document.createElement('div');p.className='achievement-popup';
   p.innerHTML='<div class="ic">💀</div><div class="info"><div class="t1">MODO DESBLOQUEADO</div><div class="t2">PESADILLA</div><div class="t3">Actívalo en el menú principal</div></div>';
   document.body.appendChild(p);setTimeout(()=>p.classList.add('show'),60);
   setTimeout(()=>{p.classList.remove('show');setTimeout(()=>p.remove(),600)},4200)},500)
 }
 if(meta.stats.runs>=10)unlockAchievement('veteran');
 addXp(100);meta.stash=new Array(12).fill(null);saveMeta();
 return earned;
}

let lastT=0,running=true;
function loop(t){
 requestAnimationFrame(loop);if(!running)return;
 const dt=Math.min(.05,(t-lastT)/1000)||0;lastT=t;
 if(state==='play'){
  if(!paused()){
   gt+=dt;updPlayer(dt);updateSafeCrack(dt);updEnemies(dt);updAllies(dt);updProjs(dt);updRockets(dt);
   updateThrowables(dt);updateEGrenades(dt);updateSmokes(dt);updateFires(dt);updWeather(dt)
  }
  updParts(dt);updFx(dt);hud(false);
  $('damage').style.opacity=P.hurt>0?Math.min(.85,P.hurt*2):0;
  const hpR=P.hp/P.maxHp;let lowA=0;
  if(hpR<0.5){const tt=(0.5-hpR)/0.5;lowA=tt*tt*0.85;
   if(hpR<0.2){lowA+=Math.sin(gt*7)*0.08;lowA=Math.max(0,Math.min(0.95,lowA))}}
  $('lowhp').style.opacity=lowA
 } else {
  updParts(dt);updFx(dt);$('damage').style.opacity=0;$('lowhp').style.opacity=0
 }
 if(buf&&state!=='menu')render();
 if(state==='play'&&!paused()){ft.push(dt);
  if(ft.length>45){let s=0;for(const v of ft)s+=v;const a=s/ft.length;ft.length=0;adapt++;
   if(adapt>2){if(a>.033&&qs>.45){qs=Math.max(.45,qs-.12);resize();adapt=0}
    else if(a<.017&&qs<1){qs=Math.min(1,qs+.08);resize();adapt=0}}}}
}
const LOADING_TIPS=[
 'La ciudad alberga <strong>seis puestos fortificados</strong>. Los de mayor nivel concentran más defensas: no confundas una entrada abierta con una zona segura.',
 'La <strong>base de nivel 3</strong> es la posición más pesada: puede tener cuatro torres, alambradas y defensas interiores. Prepárate antes de cruzar su perímetro.',
 'El <strong>RPG-7</strong> dispara un cohete PG-7V de 40 mm y solo admite uno cargado. Si lo llevas, busca el momento adecuado: la recarga no es instantánea.',
 'Los disparos del lanzacohetes delatan tu posición a gran distancia. <strong>Haz que cada cohete cuente</strong> y no lo uses como si fuera un fusil.',
 'La extracción está en el extremo opuesto de la ciudad. <strong>La baliza verde es tu salida</strong>; sobrevivir al combate no basta si no consigues llegar hasta ella.',
 'El botín de los enemigos pesados puede incluir armas, blindaje y cohetes. <strong>Revisa los cuerpos</strong> después de asegurar la zona, pero no te quedes quieto demasiado tiempo.',
 'El contenedor seguro conserva sus objetos incluso si caes en combate. <strong>Asegura lo irremplazable</strong> antes de arriesgar tu equipo en una incursión.',
 'La tienda aplica una tasa al vender y un impuesto a la extracción. <strong>El valor que recoges no siempre es el valor que cobras</strong>: calcula si el riesgo compensa.',
 'El hambre y la sed también importan. Vigila sus indicadores mientras avanzas: <strong>una incursión larga exige suministros</strong>, no solo munición.',
 'Los puestos de nivel bajo tienen más accesos; los fortines superiores cuentan con más obstáculos y equipo. <strong>Elige la aproximación según la defensa</strong>, no por costumbre.',
 'El humo puede ayudarte a romper una línea de visión, pero no convierte una posición expuesta en cobertura sólida. <strong>Muévete mientras el enemigo pierde contacto</strong>.',
 'La MG42 golpea fuerte, pero pesa mucho más que un arma ligera. <strong>Equipa según la misión</strong>: potencia de fuego y movilidad rara vez vienen gratis.',
 'El mercado cambia sus precios. Antes de gastar todo tu dinero, revisa las ofertas y recuerda que <strong>la munición también forma parte del presupuesto</strong>.',
 'La niebla, la lluvia y las tormentas alteran las condiciones de combate. Si el clima reduce la visibilidad enemiga, <strong>aprovecha la ventana para reposicionarte</strong>.',
 'El blindaje ayuda a resistir, pero no te vuelve invulnerable. <strong>Usa muros, esquinas y edificios</strong> para evitar recibir fuego innecesario.',
 'Si una base activa la alarma, espera resistencia adicional. <strong>No te quedes atrapado en el perímetro</strong>: identifica una salida antes de comprometerte.'
];
let lastLoadingTip=-1,loadingTimer=null;
function start(){
 if(state!=='menu')return;
 ensureAudio();reset();meta.stash=new Array(12).fill(null);saveMeta();
 state='loading';screen(null);
 $('invPanel').classList.remove('on');$('lootPanel').classList.remove('on');
 $('extwrap').classList.remove('on');$('extfill').style.width='0';
 $('btnLoot').classList.remove('on');$('btnLoot').classList.remove('ally');
 $('lowhp').style.opacity=0;$('outpostBanner').className='';
 currentOutpostShown=null;
 let tipIndex=Math.floor(Math.random()*LOADING_TIPS.length);
 if(LOADING_TIPS.length>1&&tipIndex===lastLoadingTip)tipIndex=(tipIndex+1+Math.floor(Math.random()*(LOADING_TIPS.length-1)))%LOADING_TIPS.length;
 lastLoadingTip=tipIndex;
 $('loadingTipText').innerHTML=LOADING_TIPS[tipIndex];
 const track=$('loadProgress');track.style.animation='none';void track.offsetWidth;track.style.animation='loadFill 2.6s linear forwards';
 $('loadStatus').textContent=['ESTABLECIENDO ENLACE TÁCTICO...','VERIFICANDO EQUIPO...','BALIZA DE EXTRACCIÓN LOCALIZADA...'][Math.floor(Math.random()*3)];
 $('continueOperationBtn').style.display='none';
 $('loadingScreen').classList.add('on');
 if(loadingTimer)clearTimeout(loadingTimer);
 loadingTimer=setTimeout(()=>{
  if(state!=='loading')return;
  $('loadStatus').textContent='INFORME LISTO · ESPERANDO AUTORIZACIÓN';
  $('continueOperationBtn').style.display='inline-block';
 },2600);
}
function continueOperation(){
 if(state!=='loading')return;
 if(loadingTimer){clearTimeout(loadingTimer);loadingTimer=null;}
 $('loadingScreen').classList.remove('on');
 $('continueOperationBtn').style.display='none';
 state='play';hud(true);
 const wmsg=weather==='rain'?'LLUEVE · VISIÓN ENEMIGA REDUCIDA':weather==='fog'?'NIEBLA · LOS ENEMIGOS VEN MENOS':weather==='sandstorm'?'TORMENTA · VISIÓN REDUCIDA':'6 BASES FORTIFICADAS · PISO MILITAR';
 msg(wmsg,'#ffb040');lastT=performance.now();ft.length=0;
}
function toMenu(){
 state='menu';screen('menuScreen');
 $('extwrap').classList.remove('on');$('lowhp').style.opacity=0;
 $('outpostBanner').className='';currentOutpostShown=null;
 refreshMenuStats()
}
loadMeta();refreshMenuStats();refreshMarket();rollDailyMissions();
onTap($('startBtn'),()=>{if(state==='menu')start()});
onTap($('continueOperationBtn'),continueOperation);
onTap($('shopBtn'),()=>{if(state==='menu')openShop()});
onTap($('shopClose'),()=>closeShop());
onTap($('dailyBtn'),()=>{if(state==='menu')openDaily()});
onTap($('dailyClose'),()=>closeDaily());
onTap($('achBtn'),()=>{if(state==='menu')openAch()});
onTap($('achClose'),()=>closeAch());
onTap($('nightmareBtn'),()=>{
 if(!meta.nightmareUnlocked)return;
 meta.nightmareActive=!meta.nightmareActive;saveMeta();refreshMenuStats();SFX.ui();
 msg(meta.nightmareActive?'PESADILLA ACTIVADA':'MODO NORMAL',meta.nightmareActive?'#ff5a5a':'#7dff8f')
});
onTap($('retryBtn'),()=>toMenu());
onTap($('againBtn'),()=>toMenu());
document.querySelectorAll('.shopTabs button').forEach(b=>{onTap(b,()=>{shopTab=b.dataset.tab;renderShop(shopTab);SFX.ui()})});
onTap($('invClose'),()=>$('invPanel').classList.remove('on'));onTap($('itemActionCancel'),()=>$('itemActionScreen').classList.remove('on'));
onTap($('lootClose'),()=>$('lootPanel').classList.remove('on'));
document.addEventListener('visibilitychange',()=>{
 if(document.hidden){running=false;fireHeld=false;joyOn=false;joyId=null;lookId=null;joyBase.style.display='none';if(actx&&actx.state==='running')actx.suspend()}
 else{running=true;lastT=performance.now();ft.length=0;if(actx&&actx.state==='suspended')actx.resume()}
});
document.addEventListener('gesturestart',e=>e.preventDefault());
document.addEventListener('contextmenu',e=>e.preventDefault());

const MAP_SEED=(Date.now()&0xFFFFFF)>>>0;
generateCity(MAP_SEED);
buildOutposts();
updateBeacon();
for(const op of OUTPOSTS)fortifyOutpost(op);
mapOrig.set(map);
rebuildMinimap();
computeInteriorProps(MAP_SEED);
computePickupSpots(MAP_SEED);
reset();resize();requestAnimationFrame(loop);
})();
