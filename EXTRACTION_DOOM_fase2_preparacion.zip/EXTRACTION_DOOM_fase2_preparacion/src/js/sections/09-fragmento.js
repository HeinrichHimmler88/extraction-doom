   fr:conf.fr,corpse:conf.corpse,atkCd:0,hurtT:0,alive:true,wt:0,wander:initFace,wanderT:0,loot:makeLoot(type),
   height:conf.h,aimT:0,shoutT:0,reinforceT:conf.reinforceCd||0,recentDmg:0,recentDmgT:0,zigzagT:0,zigzagDir:1,
   stop:conf.stop,boss:!!conf.boss,sniper:!!conf.laser,meleeType:!!conf.melee,pellets:conf.pellets||1,
   minDist:conf.minDist||0,maxDist:conf.maxDist||30,coverTarget:null,face:initFace,detect:0,fov:conf.fov,sight:conf.sight,
   name:conf.name,color:conf.color,outpost,homeX:outpost.x,homeY:outpost.y,leash:outpost.leash,
   state:'PATROL',stateT:0,waypointIdx:Math.floor(Math.random()*(outpost.waypoints.length||1))};
  enemies.push(e);spawned.push(e);
 }
 outpost.enemies=spawned;outpost.totalCount=spawned.length;outpost.killed=0;outpost.taken=false;
}
function spawnOutpostReinforcements(op){
  if(!op.gates||op.gates.length===0)return;
  let spawned=0;
  const shuffled=op.gates.slice().sort(()=>Math.random()-0.5);
  const hpMul=meta.nightmareActive?1.5:1,dmgMul=meta.nightmareActive?1.5:1;
  for(const gate of shuffled){
    if(spawned>=3)break;
    const gx=op.maskX+gate.mx,gy=op.maskY+gate.my;
    const dx=gx-op.x,dy=gy-op.y;
    const d=Math.hypot(dx,dy)||1;
    const nx=dx/d,ny=dy/d;
    const spawnX=Math.floor(gx+nx*2),spawnY=Math.floor(gy+ny*2);
    if(spawnX<2||spawnY<2||spawnX>=MW-2||spawnY>=MH-2)continue;
    if(!canStandProp(spawnX+0.5,spawnY+0.5,0.4))continue;
    const conf=ETYPES.soldier;
    const nf=Math.random()*6.28;
    const e={x:spawnX+0.5,y:spawnY+0.5,type:'soldier',
      hp:Math.round(conf.hp*hpMul),maxHp:Math.round(conf.hp*hpMul),
      speed:conf.speed,dmg:Math.round(conf.dmg*dmgMul),
      fr:conf.fr,corpse:conf.corpse,atkCd:0.5,hurtT:0,alive:true,
      wt:0,wander:nf,wanderT:0,loot:makeLoot('soldier'),
      height:conf.h,aimT:0,shoutT:0,reinforceT:0,
      recentDmg:0,recentDmgT:0,zigzagT:0,zigzagDir:1,
      stop:conf.stop,boss:false,sniper:false,meleeType:false,
      pellets:1,minDist:0,maxDist:30,coverTarget:null,
      face:nf,detect:1,fov:conf.fov,sight:conf.sight,
      name:conf.name,color:conf.color,
      outpost:op,homeX:op.x,homeY:op.y,leash:op.leash,
      state:'COMBAT',stateT:0,lastKnownPos:{x:P.x,y:P.y}};
    enemies.push(e);
    op.enemies.push(e);
    total++;
    spawned++;
  }
  if(spawned>0){SFX.shout();msg('¡REFUERZOS EN CAMINO!','#ff3a3a')}
}
function checkOutpostCleared(e){
 if(!e.outpost||e.outpost.taken)return;
 const op=e.outpost;
 const alive=op.enemies.filter(x=>x.alive);
 if(alive.length===0){
  op.taken=true;op.killed=op.totalCount;outpostsTaken++;
  op.alertState='CLEARED';
  meta.stats.outpostsTaken=(meta.stats.outpostsTaken||0)+1;
  showAchievementPopup({name:op.name,desc:'Puesto tomado · '+op.totalCount+' bajas',icon:op.tier===3?'🏰':op.tier===2?'🏢':'🏠'},'outpost');
  SFX.win();if(navigator.vibrate)navigator.vibrate([40,60,40]);
  spawnOutpostReward(op);
  // NUEVO: revelar puestos cercanos en minimapa
  let revealed=0;
  for(const other of OUTPOSTS){
    if(other===op||other.taken)continue;
    if(revealedOutposts.has(other.id))continue;
    if(Math.hypot(other.x-op.x,other.y-op.y)<50){
      revealedOutposts.add(other.id);
      revealed++;
    }
  }
  if(revealed>0)msg('📡 '+revealed+' PUESTO(S) MARCADO(S) EN MINIMAPA','#9fd8ff');
  const o1=objectives.find(o=>o.id==='take_outpost');
  if(o1&&!o1.done){o1.done=true;meta.stats.objectivesDone++;msg('¡OBJETIVO: PUESTO TOMADO!','#7dff8f');updateDailyProgress('objectives',1)}
  const o2=objectives.find(o=>o.id==='take_2_outposts');
  if(o2&&!o2.done&&outpostsTaken>=2){o2.done=true;meta.stats.objectivesDone++;msg('¡OBJETIVO: 2 PUESTOS!','#7dff8f');updateDailyProgress('objectives',1)}
  updateDailyProgress('outposts',1);saveMeta();
 }
}
function spawnOutpostReward(op){
  const tier=op.tier,rewards=makeOutpostReward(tier),spots=[];
  const validCells=op.interiorCells.filter(c=>{
    const wx=op.maskX+c.mx+0.5,wy=op.maskY+c.my+0.5;
    return canStandProp(wx,wy,0.3);
  });
  const numCaches=tier===3?2:1;
  let tries=0;
  while(spots.length<numCaches&&tries<40&&validCells.length>0){
    tries++;
    const c=validCells[Math.floor(Math.random()*validCells.length)];
    const wx=op.maskX+c.mx+0.5,wy=op.maskY+c.my+0.5;
    if(Math.hypot(wx-op.x,wy-op.y)<1.5)continue;
    let tooClose=false;
    for(const s of spots)if(Math.hypot(s[0]-wx,s[1]-wy)<1.5){tooClose=true;break}
    if(tooClose)continue;
    spots.push([wx,wy]);
  }
  if(spots.length===0)spots.push([op.x,op.y]);
  const primaryReward=rewards;
  spots.forEach((s,i)=>{
   corpses.push({x:s[0],y:s[1],spr:sCache,wh:0.7,ww:0.7,z0:0,perm:false,
    loot:i===0?primaryReward:[{id:'shells',count:2},{id:'bullets',count:2}],cache:true,outpost:op,healAvailable:true});
  });
  rebuildPropGrid();
}
function rollObjectives(){
 const all=[
  {id:'briefcase',label:'RECUPERA EL MALETÍN'},
  {id:'kill_officer',label:'ELIMINA AL OFICIAL'},
  {id:'no_damage',label:'60s SIN RECIBIR DAÑO'},
  {id:'loot_amount',label:'EXTRAE CON $2500+'},
  {id:'take_outpost',label:'TOMA UN PUESTO'},
  {id:'take_2_outposts',label:'TOMA 2 PUESTOS'}
 ];
 all.sort(()=>Math.random()-0.5);
 const n=2+(Math.random()<.5?0:1);
 objectives=all.slice(0,n).map(o=>({...o,done:false}));
 if(objectives.find(o=>o.id==='briefcase')){
  const conts=corpses.filter(c=>c.perm);
  if(conts.length){const c=conts[Math.floor(Math.random()*conts.length)];c.loot.push({id:'briefcase',count:1})}
 }
 if(objectives.find(o=>o.id==='kill_officer')){
  const offs=enemies.filter(e=>e.type==='officer');
  if(offs.length){offs[Math.floor(Math.random()*offs.length)].objective=true}
 }
}
function spawnSafeBoxes(){
 SAFE_BOXES=[];safeCrack=null;nearSafe=null;$('safeCrackUI').style.display='none';
 const target=5;let tries=0;
 while(SAFE_BOXES.length<target&&tries<1800){tries++;
  const x=2.5+Math.floor(Math.random()*(MW-5)),y=2.5+Math.floor(Math.random()*(MH-5));
  if(isWall(x,y)||!canStandProp(x,y,.35))continue;
  if(Math.hypot(x-2.5,y-2.5)<7||Math.hypot(x-BEACON.x,y-BEACON.y)<5)continue;
  if(SAFE_BOXES.some(q=>Math.hypot(q.x-x,q.y-y)<9))continue;
  SAFE_BOXES.push({x,y,spr:sSafe,wh:.42,ww:.38,opened:false,loot:[],perm:true,isSafe:true});
 }
}
function safeLootRoll(){
 const roll=Math.random();
 if(roll<.48){
  const common=['shells','bullets','ammo9','ammo76239','bandage','medkit','water','soda','burger','fruit','can'];
  const id=common[Math.floor(Math.random()*common.length)];
  const n=(id==='shells'||id==='bullets'||id==='ammo9'||id==='ammo76239')?(1+Math.floor(Math.random()*2)):1;
  const loot=[{id,count:n}];
  if(Math.random()<.3)loot.push({id:['bandage','water','can','bullets'][Math.floor(Math.random()*4)],count:1});
  return loot;
 }
 let pool;
