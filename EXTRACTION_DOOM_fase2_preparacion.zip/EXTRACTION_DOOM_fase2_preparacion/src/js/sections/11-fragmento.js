const canvas=$('scene'),ctx=canvas.getContext('2d',{alpha:false}),mm=$('mm'),mctx=mm.getContext('2d');
let RW=320,RH=180,projDist=100,img,buf,zbuf,sky,SW=0,qs=1,ft=[],adapt=0;
const PL=1.25;
function buildSky(){SW=Math.round(RW*3.6);const hh=RH/2|0;sky=new Uint32Array(SW*hh);const sx=SW*.3,sy=hh*.38;
 const F=FOG,T=weather==='rain'?[92,106,124]:weather==='fog'?[150,164,180]:weather==='sandstorm'?[190,150,96]:[55,125,222],sunOn=weather==='clear',thr=weather==='clear'?.5:.3;
 const vn=(x,y,p)=>{const xi=Math.floor(x),yi=Math.floor(y),fx=x-xi,fy=y-yi,u=fx*fx*(3-2*fx),v=fy*fy*(3-2*fy),h=(a,b)=>hash(((a%p)+p)%p,b,5);
  return(h(xi,yi)*(1-u)+h(xi+1,yi)*u)*(1-v)+(h(xi,yi+1)*(1-u)+h(xi+1,yi+1)*u)*v};
 for(let y=0;y<hh;y++){const f=y/hh;for(let x=0;x<SW;x++){let r=T[0]+(F[0]-T[0])*f,g=T[1]+(F[1]-T[1])*f,b=T[2]+(F[2]-T[2])*f;
  let cl=vn(x/SW*8,y/hh*3,8)*.6+vn(x/SW*16,y/hh*6,16)*.4;cl=clamp((cl-thr)*3,0,1)*Math.min(1,(1-f)*2.4)*.9;
  r+=(255-r)*cl;g+=(255-g)*cl;b+=(255-b)*cl;
  let dx=Math.abs(x-sx);dx=Math.min(dx,SW-dx);const d=Math.hypot(dx,(y-sy))/hh;
  if(sunOn&&d<.04){r=255;g=252;b=220}else if(sunOn){const gl=Math.pow(Math.max(0,1-d*2.4),2);r+=gl*90;g+=gl*70;b+=gl*20}
  sky[y*SW+x]=C(r,g,b)}}}
function resize(){const cw=innerWidth,ch=innerHeight,as=cw/ch;let rh=Math.round(Math.sqrt(105000*qs/as)),rw=Math.round(rh*as);
 rw=clamp(rw,200,760);rh=clamp(Math.round(rw/as),120,900);const ch0=RW!==rw||RH!==rh;RW=rw;RH=rh;canvas.width=RW;canvas.height=RH;
 img=ctx.createImageData(RW,RH);buf=new Uint32Array(img.data.buffer);zbuf=new Float32Array(RW);projDist=RW/(2*PL);if(ch0||!sky)buildSky()}
addEventListener('resize',resize);addEventListener('orientationchange',()=>setTimeout(resize,200));

const mmBase=document.createElement('canvas');mmBase.width=MW;mmBase.height=MH;
function rebuildMinimap(){
  const c=mmBase.getContext('2d');
  const im=c.createImageData(MW,MH);
  const b=new Uint32Array(im.data.buffer);
  const col=[C(80,80,90),C(130,130,135),C(90,140,80),C(140,110,70),C(80,80,90),C(80,80,90),C(110,105,95)];
  for(let i=0;i<MW*MH;i++)b[i]=map[i]?C(40,40,44):col[gmap[i]||0];
  c.putImageData(im,0,0);
}
const CW=8;
const compassStrip=$('compassStrip');
{let html='';
 for(let i=0;i<CW;i++){
  const dirs=['N','NE','E','SE','S','SO','O','NO'];
  const isCard=i%2===0;
  html+='<span'+(isCard?' class="card"':'')+'>'+dirs[i]+'</span>';
 }
 compassStrip.innerHTML=html+html+html;
 compassStrip.style.width=compassStrip.scrollWidth+'px';
}
function updCompass(){
 const dirs=8,unit=50,heading=P.a+Math.PI/2;
 const norm=((heading/(Math.PI*2))%1+1)%1;
 const centerIdx=norm*dirs,centerX=100;
 const offset=centerX-(centerIdx*unit);
 compassStrip.style.transform='translateX('+(offset-unit*dirs)+'px)';
}

const flow=new Int16Array(MW*MH);let flowT=0;
const D4=[[1,0],[-1,0],[0,1],[0,-1]],D8=D4.concat([[1,1],[1,-1],[-1,1],[-1,-1]]);
function buildFlow(){flow.fill(-1);const q=[(P.y|0)*MW+(P.x|0)];flow[q[0]]=0;
 for(let h=0;h<q.length;h++){const c=q[h],cx=c%MW,cy=(c/MW)|0;for(const d of D4){const nx=cx+d[0],ny=cy+d[1];if(nx<0||ny<0||nx>=MW||ny>=MH)continue;const n=ny*MW+nx;if(flow[n]>=0||map[n]||pblk[n])continue;flow[n]=flow[c]+1;q.push(n)}}}
function flowDir(e){const cx=e.x|0,cy=e.y|0;let b=flow[cy*MW+cx],bx=0,by=0;if(b<0)b=1e9;
 for(const d of D8){const n=(cy+d[1])*MW+cx+d[0];if(flow[n]<0||map[n]||pblk[n])continue;if(d[0]&&d[1]&&(map[cy*MW+cx+d[0]]||map[(cy+d[1])*MW+cx]||pblk[cy*MW+cx+d[0]]||pblk[(cy+d[1])*MW+cx]))continue;if(flow[n]<b){b=flow[n];bx=d[0];by=d[1]}}
 if(!bx&&!by)return null;const dx=cx+.5+bx-e.x,dy=cy+.5+by-e.y,l=Math.hypot(dx,dy)||1;return[dx/l,dy/l]}

function onTap(el,handler){
 if(!el)return;
 let sx=0,sy=0,moved=false,lastTouch=0;
 el.addEventListener('touchstart',e=>{e.stopPropagation();const t=e.touches[0];sx=t.clientX;sy=t.clientY;moved=false},{passive:true});
 el.addEventListener('touchmove',e=>{const t=e.touches[0];if(Math.abs(t.clientX-sx)>10||Math.abs(t.clientY-sy)>10)moved=true},{passive:true});
 el.addEventListener('touchend',e=>{e.stopPropagation();if(moved)return;e.preventDefault();lastTouch=Date.now();try{ensureAudio()}catch(_){}handler()},{passive:false});
 el.addEventListener('touchcancel',e=>{e.stopPropagation()},{passive:true});
 el.addEventListener('click',e=>{if(Date.now()-lastTouch<600)return;e.preventDefault();handler()});
}
function onHold(el,onShort,onLong){
 if(!el)return;
 let tmr=null,longFired=false,touched=false;
 const START=(e)=>{e.preventDefault();e.stopPropagation();touched=true;longFired=false;tmr=setTimeout(()=>{longFired=true;onLong()},450)};
 const END=(e)=>{e.stopPropagation();if(tmr)clearTimeout(tmr);if(touched&&!longFired)onShort();touched=false};
 const CANCEL=()=>{if(tmr)clearTimeout(tmr);touched=false};
 el.addEventListener('touchstart',START,{passive:false});
 el.addEventListener('touchend',END,{passive:true});
 el.addEventListener('touchcancel',CANCEL,{passive:true});
 let moTmr=null,moLong=false,moDown=false;
 el.addEventListener('mousedown',e=>{e.preventDefault();moDown=true;moLong=false;moTmr=setTimeout(()=>{moLong=true;onLong()},450)});
 el.addEventListener('mouseup',e=>{e.preventDefault();if(moTmr)clearTimeout(moTmr);if(moDown&&!moLong)onShort();moDown=false});
 el.addEventListener('mouseleave',()=>{if(moTmr)clearTimeout(moTmr);moDown=false});
}
const keys={};
addEventListener('keydown',e=>{const k=e.key.toLowerCase();keys[k]=true;if(['arrowup','arrowdown','arrowleft','arrowright',' '].includes(k))e.preventDefault();
 if(state!=='play')return;if(k===' ')fireHeld=true;if(k==='q')swapOrReload();if(k==='i')toggleInv();if(k==='e')openLoot();
 if(k==='r')startReload();if(k==='f')melee();
 if(k==='g')throwGrenade();if(k==='v')cycleThrowable()});
addEventListener('keyup',e=>{keys[e.key.toLowerCase()]=false;if(e.key===' ')fireHeld=false});
$('zoneR').addEventListener('click',()=>{if(state==='play'&&!('ontouchstart' in window)&&canvas.requestPointerLock)canvas.requestPointerLock()});
document.addEventListener('mousemove',e=>{if(document.pointerLockElement&&state==='play'&&!paused())P.a+=e.movementX*.0026});
document.addEventListener('mousedown',e=>{if(document.pointerLockElement&&state==='play'&&!paused())fireHeld=true});
addEventListener('mouseup',()=>{fireHeld=false;$('btnFire').classList.remove('on')});
function paused(){return $('invPanel').classList.contains('on')||$('lootPanel').classList.contains('on')}
const joyBase=$('joyBase'),joyKnob=$('joyKnob');let joyId=null,jcx=0,jcy=0,joyX=0,joyY=0,joyOn=false;const JM=52;
const zL=$('zoneL'),zR=$('zoneR'),NP={passive:false};
zL.addEventListener('touchstart',e=>{e.preventDefault();ensureAudio();for(const t of e.changedTouches)if(joyId===null){joyId=t.identifier;jcx=t.clientX;jcy=t.clientY;joyOn=true;joyX=joyY=0;
 joyBase.style.left=jcx+'px';joyBase.style.top=jcy+'px';joyBase.style.display='block';joyKnob.style.left=joyKnob.style.top='50%'}},NP);
zL.addEventListener('touchmove',e=>{e.preventDefault();for(const t of e.changedTouches)if(t.identifier===joyId){let dx=t.clientX-jcx,dy=t.clientY-jcy;const d=Math.hypot(dx,dy);
 if(d>JM){dx=dx/d*JM;dy=dy/d*JM}joyX=dx/JM;joyY=-dy/JM;joyKnob.style.left=(50+dx/JM*44)+'%';joyKnob.style.top=(50+dy/JM*44)+'%'}},NP);
function endJoy(e){for(const t of e.changedTouches)if(t.identifier===joyId){joyId=null;joyOn=false;joyX=joyY=0;joyBase.style.display='none'}}
zL.addEventListener('touchend',endJoy,{passive:true});
zL.addEventListener('touchcancel',endJoy,{passive:true});
let lookId=null,lx=0,ly=0,lm=0;
zR.addEventListener('touchstart',e=>{e.preventDefault();ensureAudio();for(const t of e.changedTouches)if(lookId===null){lookId=t.identifier;lx=t.clientX;ly=t.clientY;lm=0}},NP);
zR.addEventListener('touchmove',e=>{e.preventDefault();for(const t of e.changedTouches)if(t.identifier===lookId){const dx=t.clientX-lx;lm+=Math.abs(dx)+Math.abs(t.clientY-ly);lx=t.clientX;ly=t.clientY;if(state==='play'&&!paused())P.a+=dx*.0055}},NP);
zR.addEventListener('touchend',e=>{for(const t of e.changedTouches)if(t.identifier===lookId){if(lm<12&&state==='play'&&!paused())shoot();lookId=null}},{passive:true});
zR.addEventListener('touchcancel',()=>{lookId=null},{passive:true});
function bind(id,down,up){const b=$(id);b.addEventListener('touchstart',e=>{e.preventDefault();e.stopPropagation();ensureAudio();down();b.classList.add('on')},NP);
 const u=e=>{e.stopPropagation();if(up)up();b.classList.remove('on')};
 b.addEventListener('touchend',u,{passive:true});
 b.addEventListener('touchcancel',u,{passive:true})}
$('safeCrackCancel').addEventListener('click',()=>cancelSafeCrack('FORZADO CANCELADO'));
 bind('btnFire',()=>{fireHeld=true},()=>{fireHeld=false});bind('btnSwap',swapOrReload);bind('btnInv',toggleInv);bind('btnMelee',melee);
// La interacción de saqueo se dispara al soltar/tocar explícitamente el botón, no al aparecer por proximidad.
const lootBtn=$('btnLoot');let lootTouchStarted=false;
lootBtn.addEventListener('touchstart',e=>{e.preventDefault();e.stopPropagation();lootTouchStarted=true;ensureAudio();lootBtn.classList.add('on')},NP);
lootBtn.addEventListener('touchend',e=>{e.preventDefault();e.stopPropagation();const wasStarted=lootTouchStarted;lootTouchStarted=false;lootBtn.classList.remove('on');if(wasStarted&&state==='play')openLoot()},{passive:false});
lootBtn.addEventListener('touchcancel',()=>{lootTouchStarted=false;lootBtn.classList.remove('on')},{passive:true});
lootBtn.addEventListener('click',e=>{if('ontouchstart' in window)return;e.preventDefault();if(state==='play')openLoot()});
const btnThrow=$('btnThrow');let throwTmr=null,throwLong=false;
btnThrow.addEventListener('touchstart',e=>{e.preventDefault();e.stopPropagation();ensureAudio();btnThrow.classList.add('on');throwLong=false;
 throwTmr=setTimeout(()=>{throwLong=true;cycleThrowable();if(navigator.vibrate)navigator.vibrate(20)},380)},NP);
btnThrow.addEventListener('touchend',e=>{e.stopPropagation();clearTimeout(throwTmr);btnThrow.classList.remove('on');if(!throwLong)throwGrenade()},{passive:true});
btnThrow.addEventListener('touchcancel',()=>{clearTimeout(throwTmr);btnThrow.classList.remove('on')},{passive:true});
btnThrow.addEventListener('mousedown',e=>{e.preventDefault();ensureAudio();btnThrow.classList.add('on');throwLong=false;
 throwTmr=setTimeout(()=>{throwLong=true;cycleThrowable()},380)});
btnThrow.addEventListener('mouseup',e=>{clearTimeout(throwTmr);btnThrow.classList.remove('on');if(!throwLong)throwGrenade()});
$('btnFire').addEventListener('mousedown',()=>{fireHeld=true;$('btnFire').classList.add('on')});

