  card.innerHTML=lvlTag+'<div class="ic" style="background:'+d.color+'">'+d.sym+'</div>'+
   '<div class="info"><div class="nm">'+d.name+'</div><div class="ds">'+wInfo+'</div></div>'+
   '<div class="pr" style="color:'+priceColor+'">$'+price+'</div>';
  if(!cant)onTap(card,()=>buyItem(id));
  else if(has)card.querySelector('.pr').innerHTML='<span style="color:#888">YA LO TIENES</span>';
  else if(!levelOK)card.querySelector('.pr').innerHTML='<span style="color:#a55">NIVEL '+d.minLevel+'</span>';
  else if(meta.money<price)card.querySelector('.pr').innerHTML='<span style="color:#a55">SIN DINERO</span>';
  else if(!stashHasSpace())card.querySelector('.pr').innerHTML='<span style="color:#a55">LLENO</span>';
  grid.appendChild(card)
 }
 renderStash()
}
function stashHasItem(id){for(const it of meta.stash)if(it&&it.id===id)return true;return false}
function stashHasSpace(){for(const it of meta.stash)if(!it)return true;return false}
function buyItem(id){
 const d=ITEMS[id];
 if(d.minLevel&&meta.level<d.minLevel){SFX.error();msg('NECESITAS NIVEL '+d.minLevel,'#ff6a5a');return}
 const price=marketPrice(d.v);
 if(meta.money<price){SFX.error();msg('SIN DINERO','#ff6a5a');return}
 if(!stashHasSpace()){SFX.error();msg('INVENTARIO LLENO','#ff6a5a');return}
 if(stashHasItem(id)&&(d.slot||d.weapon!==undefined)){SFX.error();msg('YA LO TIENES','#ff6a5a');return}
 for(const it of meta.stash){if(it&&it.id===id){it.count++;meta.money-=price;SFX.buy();saveMeta();renderShop(shopTab);msg('COMPRADO: '+d.name+' -$'+price,'#7dff8f');return}}
 for(let i=0;i<12;i++){if(!meta.stash[i]){meta.stash[i]={id,count:1,dur:d.slot?d.dur:undefined};meta.money-=price;SFX.buy();saveMeta();renderShop(shopTab);msg('COMPRADO: '+d.name+' -$'+price,'#7dff8f');return}}
}
function sellStashItem(idx){
 const it=meta.stash[idx];if(!it)return;
 const d=ITEMS[it.id];
 const price=Math.round(d.v*(d.misc?1:RESALE_RATE));
 if(it.count>1)it.count--;else meta.stash[idx]=null;
 meta.money+=price;SFX.sell();saveMeta();renderShop(shopTab);
 msg('VENDIDO: +$'+price+(d.misc?' (VALOR COMPLETO)':' (75%)'),'#ffd24a')
}
function repairArmor(idx){
 const it=meta.stash[idx];if(!it)return;
 const d=ITEMS[it.id];
 if(!d.slot||!d.dur){SFX.error();msg('NO SE PUEDE REPARAR','#ff6a5a');return}
 const cost=Math.round(d.v*REPAIR_RATE);
 if(meta.money<cost){SFX.error();msg('SIN DINERO ($'+cost+')','#ff6a5a');return}
 if(it.dur===undefined)it.dur=d.dur;
 if(it.dur>=d.dur){msg('YA ESTÁ AL MÁXIMO','#ffb040');return}
 meta.money-=cost;it.dur=d.dur;
 SFX.buy();saveMeta();renderShop(shopTab);
 msg('REPARADO: -$'+cost,'#7dff8f')
}
function renderStash(){
 const el=$('shopStash');el.innerHTML='';
 for(let i=0;i<12;i++){
  const it=meta.stash[i];
  const s=document.createElement('div');s.className='slot';
  if(it){
   const d=ITEMS[it.id];if(!d){s.className+=' emptySlot';s.textContent='OBJETO DESCONOCIDO';el.appendChild(s);continue;}s.style.background=d.color||'#343840';
   const sellPrice=Math.round((d.v||0)*RESALE_RATE);
   const isArmor=d.slot&&d.dur;
   const dur=it.dur!==undefined?it.dur:d.dur;
   s.innerHTML='<span class="nm">'+d.name+'</span><span class="sym">'+d.sym+'</span>'+
    (it.count>1?'<span class="cnt">'+it.count+'</span>':'<span class="pr">$'+sellPrice+'</span>')+
    (isArmor?'<span style="position:absolute;bottom:12px;left:3px;font-size:7px;color:#ff9a5a">'+Math.ceil(dur)+'/'+d.dur+'</span>':'');
   if(isArmor&&dur<d.dur){onHold(s,()=>repairArmor(i),()=>sellStashItem(i))}
   else{onTap(s,()=>sellStashItem(i))}
  } else s.className+=' emptySlot';
  el.appendChild(s)
 }
}

const SL=[],pool=[];let pn=0;
function add(x,y,sp,wh,ww,z0,hurt,flip,bob,br){
  const o=pool[pn]||(pool[pn]={});pn++;
  const dx=x-P.x,dy=y-P.y;
  o.x=x;o.y=y;o.d2=dx*dx+dy*dy;o.sp=sp;o.wh=wh;o.ww=ww;
  o.z0=z0;o.hurt=hurt;o.flip=flip;o.bob=bob;o.br=br;
  o.isEnemy=false;o.e=null;o.isAlly=false;
  SL.push(o)
}
function drawHudFx(W,H){const cxp=W/2,cyp=H/2;
 for(const e of enemies){
  if(!e.alive||!e.sniper||e.aimT<=0)continue;
  if(!los(e.x,e.y,P.x,P.y))continue;
  const sp=worldToScreen(e.x,e.y,e.height*.7);
  if(!sp)continue;
  const t=1-Math.min(1,e.aimT/1.5);
  ctx.strokeStyle='rgba(255,30,30,'+(0.35+t*0.6)+')';ctx.lineWidth=1.5+t;
  ctx.beginPath();ctx.moveTo(sp.x,sp.y);ctx.lineTo(cxp,cyp);ctx.stroke();
  ctx.fillStyle='rgba(255,30,30,'+(0.4+t*0.5)+')';
  ctx.beginPath();ctx.arc(cxp,cyp,3+t*5,0,6.28);ctx.fill()
 }
 for(const d of dmgDirs){const rel=d.angle-P.a;const sa=Math.atan2(Math.sin(rel),Math.cos(rel));if(Math.abs(sa)>1.2)continue;
  const a=d.life/d.max,r0=Math.min(W,H)*0.16,r1=Math.min(W,H)*0.22,ca=-Math.PI/2+sa;
  ctx.strokeStyle='rgba(255,40,20,'+(a*0.85)+')';ctx.lineWidth=6;
  ctx.beginPath();ctx.arc(cxp,cyp,r1,ca-0.22,ca+0.22);ctx.stroke();
  ctx.lineWidth=3;ctx.strokeStyle='rgba(255,120,80,'+(a*0.7)+')';
  ctx.beginPath();ctx.arc(cxp,cyp,r0,ca-0.18,ca+0.18);ctx.stroke()}
 for(const m of hitMarkers){const a=m.life/m.max;ctx.strokeStyle='rgba(255,255,255,'+a+')';ctx.lineWidth=2;
  const s=6;ctx.beginPath();ctx.moveTo(m.sx-s,m.sy-s);ctx.lineTo(m.sx+s,m.sy+s);ctx.moveTo(m.sx+s,m.sy-s);ctx.lineTo(m.sx-s,m.sy+s);ctx.stroke()}
 ctx.textAlign='center';ctx.textBaseline='middle';
 for(const n of dmgNumbers){const a=n.life/n.max;ctx.font='bold 14px "Courier New",monospace';
  ctx.strokeStyle='rgba(0,0,0,'+a+')';ctx.lineWidth=3;ctx.strokeText(n.val,n.sx,n.sy);
  ctx.fillStyle=(n.crit?'rgba(255,220,50,':'rgba(255,255,255,')+a+')';ctx.fillText(n.val,n.sx,n.sy);
  if(n.crit){ctx.font='bold 10px "Courier New",monospace';ctx.fillStyle='rgba(255,220,50,'+a+')';ctx.fillText('CRÍT',n.sx,n.sy-14)}}
}
function drawEnemyBars(W,H){
 const MAX_DIST=6;
 for(const v of visibleEnemies){
  const e=v.e,isAlly=v.isAlly,x=v.x,y=v.y,sc=v.sc,dist=v.dist;
  if(dist>MAX_DIST)continue;
  const fade=dist>5?(MAX_DIST-dist):1;if(fade<=0)continue;
  const hpR=Math.max(0,e.hp/e.maxHp);
  const barW=Math.max(16,Math.min(34,20*sc/80)),barH=2.5;
  const nameY=y-8;
  ctx.font='bold 7px "Courier New",monospace';
  ctx.textAlign='center';ctx.textBaseline='bottom';
  ctx.strokeStyle='rgba(0,0,0,'+(0.9*fade)+')';ctx.lineWidth=2;
  ctx.strokeText(e.name,x,nameY);
  ctx.fillStyle=isAlly?'rgba(157,216,255,'+fade+')':hexA(e.color||'#fff',fade);
  ctx.fillText(e.name,x,nameY);
  const bx=x-barW/2,by=y-6;
  ctx.fillStyle='rgba(0,0,0,'+(0.6*fade)+')';ctx.fillRect(bx-0.5,by-0.5,barW+1,barH+1);
  ctx.fillStyle='rgba(60,0,0,'+(0.85*fade)+')';ctx.fillRect(bx,by,barW,barH);
  let col;
  if(isAlly)col='#5bd8ff';
  else if(e.state==='FLEE')col='#ff8a2a';
  else if(hpR>0.6)col='#4caf50';
  else if(hpR>0.3)col='#ffb040';
  else col='#ff3020';
  ctx.fillStyle=hexA(col,fade);ctx.fillRect(bx,by,barW*hpR,barH);
  if(e.boss){ctx.strokeStyle='rgba(255,255,255,'+fade+')';ctx.lineWidth=1;ctx.strokeRect(bx-0.5,by-0.5,barW+1,barH+1)}
  if(e.objective){ctx.fillStyle='rgba(255,210,74,'+fade+')';ctx.font='bold 9px "Courier New",monospace';ctx.fillText('★',x+barW/2+6,nameY)}
 }
 ctx.textAlign='center';ctx.textBaseline='middle';
 for(const e of enemies){
  if(!e.alive||e.state==='COMBAT'||(e.detect||0)<0.15)continue;
  const sp=worldToScreen(e.x,e.y,e.height*1.05);if(!sp)continue;
  if(sp.dist>MAX_DIST)continue;
  const xi=sp.x|0;if(xi<0||xi>=W)continue;
  if(sp.tY>=zbuf[xi])continue;
  const a=Math.min(1,e.detect*2);
  let sym='?';
  if(e.state==='SUSPICIOUS')sym='!';
  else if(e.state==='SEARCH')sym='?';
  else if(e.state==='FLEE')sym='!!';
  ctx.font='bold 12px "Courier New",monospace';
  ctx.strokeStyle='rgba(0,0,0,'+a+')';ctx.lineWidth=2;
  ctx.strokeText(sym,sp.x,sp.y);
  const col=(e.state==='SUSPICIOUS'||e.state==='FLEE')?'rgba(255,150,50,':'rgba(255,220,50,';
