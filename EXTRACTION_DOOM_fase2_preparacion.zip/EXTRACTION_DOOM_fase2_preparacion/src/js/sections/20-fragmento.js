 if(isWall(nx,g.y)||propBlocksAt(nx,g.y)){g.vx=-g.vx*.45;hitWall=true}else g.x=nx;
 if(isWall(g.x,ny)||propBlocksAt(g.x,ny)){g.vy=-g.vy*.45;hitWall=true}else g.y=ny;
 let hitGround=false;
 if(g.z<=.05){g.z=.05;
  if(Math.abs(g.vz)>.5){g.vz=-g.vz*.35;g.vx*=.55;g.vy*=.55;g.bounces++;hitGround=true;SFX.bounce()}
  else{g.vz=0;g.vx*=.85;g.vy*=.85;if(g.bounces===0){g.bounces=1;hitGround=true}}}
 let detonate=false;
 if(g.life<=0)detonate=true;
 else if(g.type==='frag'&&g.fuse<=0)detonate=true;
 else if((g.type==='smoke'||g.type==='molotov')&&(hitGround||hitWall)&&g.age>.15)detonate=true;
 if(detonate){if(g.type==='frag')fragExplode(g.x,g.y);
  else if(g.type==='smoke')spawnSmoke(g.x,g.y);
  else spawnFire(g.x,g.y);
  throwables.splice(i,1)}}}
function updateEGrenades(dt){
 for(let i=eGrenades.length-1;i>=0;i--){const g=eGrenades[i];
  g.life-=dt;g.fuse-=dt;g.vz-=12*dt;g.z+=g.vz*dt;
  const nx=g.x+g.vx*dt,ny=g.y+g.vy*dt;
  if(isWall(nx,g.y)||propBlocksAt(nx,g.y))g.vx=-g.vx*.4;else g.x=nx;
  if(isWall(g.x,ny)||propBlocksAt(g.x,ny))g.vy=-g.vy*.4;else g.y=ny;
  if(g.z<=.05){g.z=.05;
   if(Math.abs(g.vz)>.5){g.vz=-g.vz*.35;g.vx*=.5;g.vy*=.5}
   else{g.vz=0;g.vx*=.85;g.vy*=.85}}
  if(g.fuse<=0||g.life<=0){fragExplode(g.x,g.y);eGrenades.splice(i,1)}}}
function updateSmokes(dt){for(let i=smokes.length-1;i>=0;i--){const s=smokes[i];s.life-=dt;if(s.life<=0)smokes.splice(i,1)}
 for(const s of smokes){if(Math.random()<.5){const a=Math.random()*6.28,r=Math.random()*s.radius;
  parts.push({x:s.x+Math.cos(a)*r,y:s.y+Math.sin(a)*r,vx:(Math.random()-.5)*.2,vy:(Math.random()-.5)*.2,life:1.2+Math.random()*.5,col:C(200,200,200)})}}}
function updateFires(dt){for(let i=fires.length-1;i>=0;i--){const f=fires[i];f.life-=dt;if(f.life<=0){fires.splice(i,1);continue}
 for(let k=0;k<3;k++){const a=Math.random()*6.28,r=Math.random()*f.radius;
  parts.push({x:f.x+Math.cos(a)*r,y:f.y+Math.sin(a)*r,vx:0,vy:0,life:.35+Math.random()*.25,col:C(255,80+Math.random()*130,30)})}
 const dx=P.x-f.x,dy=P.y-f.y;
 if(dx*dx+dy*dy<f.radius*f.radius){P.fireHurtCd-=dt;if(P.fireHurtCd<=0){P.fireHurtCd=.4;hurt(4,f.x,f.y);if(navigator.vibrate)navigator.vibrate(30)}}
 for(const e of enemies){if(!e.alive)continue;const ex=e.x-f.x,ey=e.y-f.y;
  if(ex*ex+ey*ey<f.radius*f.radius){e.hp-=10*dt;if(e.hp<=0)killEnemy(e)}}}}
function melee(){if(state!=='play'||P.fireCd>0.15||paused())return;
 P.fireCd=0.55;P.meleeAnim=0.28;SFX.punch();
 const dx=Math.cos(P.a),dy=Math.sin(P.a);
 for(const e of enemies){if(!e.alive)continue;
  const ex=e.x-P.x,ey=e.y-P.y,t=ex*dx+ey*dy;
  if(t<=0||t>1.5)continue;
  const perp=Math.abs(ex*dy-ey*dx);
  if(perp<.55){const dist=Math.hypot(ex,ey);hit(e,22,false,{dist:dist,melee:true});const push=.45;
   if(canStandProp(e.x+dx*push,e.y+dy*push,.3)){e.x+=dx*push;e.y+=dy*push}break}}
 hud(false)}
function worldToScreen(wx,wy,zh){
 const dx=Math.cos(P.a),dy=Math.sin(P.a),px=-dy*PL,py=dx*PL;
 const sx=wx-P.x,sy=wy-P.y;const inv=1/(px*dy-dx*py);
 const tX=inv*(dy*sx-dx*sy),tY=inv*(-py*sx+px*sy);
 if(tY<0.3)return null;
 return {x:(RW/2)*(1+tX/tY),y:RH/2+(0.5-zh)*(projDist/tY),dist:tY,sc:projDist/tY,tX:tX,tY:tY}}
function shoot(){if(state!=='play'||P.fireCd>0||paused()||P.reloading>0)return;
 const w=WEAPONS[P.weapon],wi=P.weapon;
 if(w.ammo){if(P.mag[wi]<=0){if(P[w.ammo]>0){startReload();return}SFX.empty();P.fireCd=.25;return}}
 P.fireCd=w.rate;P.muzzle=.09;
 if(w.ammo)P.mag[wi]--;
 SFX[w.sfx]();
 const noiseR=w.rocket?35:w.ammo==='shells'?30:w.ammo==='bullets'?28:22;
 noises.push({x:P.x,y:P.y,radius:noiseR,life:2.5,intensity:1});
 if(noises.length>15)noises.shift();
 if(w.rocket){
   const ox=Math.cos(P.a),oy=Math.sin(P.a);
   rockets.push({
     x:P.x+ox*.5, y:P.y+oy*.5,
     vx:ox*15, vy:oy*15,
     life:3,
     originX:P.x, originY:P.y, armed:false
   });
   P.muzzle=.12;
   whoosh();
   // Humo residual en el punto de disparo
   if(smokes.length<6){
     smokes.push({x:P.x+ox*.5,y:P.y+oy*.5,life:1.5,maxLife:1.5,radius:1.0,seed:Math.random()*100});
   }
   hud(true);
   return;
 }
 for(let i=0;i<w.pellets;i++){const a=P.a+(Math.random()-.5)*w.spread,rx=Math.cos(a),ry=Math.sin(a);let bt=wallDist(P.x,P.y,rx,ry,40),be=null;
  for(const e of enemies){if(!e.alive)continue;const ex=e.x-P.x,ey=e.y-P.y,t=ex*rx+ey*ry;if(t<=.3||t>=bt)continue;if(Math.abs(ex*ry-ey*rx)<.42){bt=t;be=e}}
  if(be){const crit=Math.random()<0.2;hit(be,w.dmg*(crit?1.5:1),crit,{dist:bt})}}
 hud(true)}
function hit(e,d,crit,info){e.hp-=d;e.hurtT=.16;
 e.recentDmg+=d;e.recentDmgT=1.5;
 if(crit){runStats.headshots++;meta.achievementProgress.headshots++;updateDailyProgress('headshots',1);if(meta.achievementProgress.headshots>=10)unlockAchievement('surgeon')}
 if(e.hp<=0){killEnemy(e,info&&info.dist,info&&info.melee?'melee':'shoot')}
 else{
  if(e.state!=='COMBAT'&&e.state!=='FLEE'){setState(e,'COMBAT');e.lastKnownPos={x:P.x,y:P.y};if(e.outpost)raiseAlert(e.outpost,'ALERT');broadcastToSquad(e,e.lastKnownPos)}
  e.detect=1;
  SFX.enemyHit();puff(e.x,e.y,5,C(200,40,40));
  const sp=worldToScreen(e.x,e.y,e.height*.55);
  if(sp){hitMarkers.push({sx:sp.x,sy:sp.y,life:.18,max:.18});
   dmgNumbers.push({sx:sp.x+(Math.random()-.5)*14,sy:sp.y-4,life:.7,max:.7,val:Math.round(d),crit:!!crit})}
  if(crit)SFX.crit()}}
function hurt(d,srcX,srcY){if(state!=='play')return;P.hp-=d;P.hurt=.45;SFX.playerHurt();
 noDamageTimer=0;runStats.damageTaken=true;
 if(navigator.vibrate)navigator.vibrate(Math.min(80,Math.round(d*1.5)));
 if(srcX!==undefined){const a=Math.atan2(srcY-P.y,srcX-P.x);dmgDirs.push({angle:a,life:1.2,max:1.2})}
 if(P.hp<=0){P.hp=0;cancelSafeCrack();$('safeCrackUI').style.display='none';state='dead';SFX.dead();fireHeld=false;onDeath();screen('deadScreen')}
 hud(true)}
function puff(x,y,n,col){for(let i=0;i<n;i++)parts.push({x,y,vx:(Math.random()-.5)*2.4,vy:(Math.random()-.5)*2.4,life:.4+Math.random()*.4,col})}
function los(x0,y0,x1,y1){const dx=x1-x0,dy=y1-y0,n=Math.ceil(Math.hypot(dx,dy)/.28);
 for(let i=1;i<n;i++){const tx=x0+dx*i/n,ty=y0+dy*i/n;
  if(isWall(tx,ty))return false;
  if(propBlocksAt(tx,ty))return false;
  for(const s of smokes){const sdx=tx-s.x,sdy=ty-s.y;if(sdx*sdx+sdy*sdy<s.radius*s.radius)return false}}
 return true}
function moveE(e,dx,dy){if(canStandProp(e.x+dx,e.y,.3))e.x+=dx;if(canStandProp(e.x,e.y+dy,.3))e.y+=dy}
function stashValue(arr){let v=0;for(const it of arr)if(it)v+=ITEMS[it.id].v*it.count;return v}
function insuranceCost(){return Math.max(20,Math.round(stashValue(meta.stash)*INSURANCE_RATE))}
function onDeath(){
 meta.stats.runs++;if(meta.stats.runs>=10)unlockAchievement('veteran');
 const lost=Math.round(meta.money*DEATH_MONEY_PENALTY);
 meta.money-=lost;meta.stats.totalLostOnDeath+=lost;lastEco.tax=lost;
 let insurancePaid=0;
 if(meta.insuranceActive){insurancePaid=Math.round(stashValue(meta.stash)*INSURANCE_RECOVER);meta.money+=insurancePaid;meta.insuranceActive=false}
 meta.stash=new Array(12).fill(null);saveMeta();
 $('stats').innerHTML='ENEMIGOS: <b>'+kills+'/'+total+'</b><br>PUESTOS: <b>'+outpostsTaken+'/'+OUTPOSTS.length+'</b><br>TIEMPO: <b>'+gt.toFixed(1)+'s</b><br>'+
  '<span style="color:#ff6a5a">-$'+lost+' (10%)</span>'+(insurancePaid>0?'<br><span style="color:#7dff8f">+$'+insurancePaid+' (seguro 50%)</span>':'<br><span style="color:#ff6a5a">Equipo perdido</span>');
}
function onWin(){
 const currentVal=(()=>{let v=0;
  for(const it of P.inventory)if(it)v+=ITEMS[it.id].v*it.count;
  for(const q in P.eq)if(P.eq[q])v+=ITEMS[P.eq[q].id].v;
  for(const wi of (P.weaponSlots||[]))if(wi>=0)v+=ITEMS[WID[wi]].v;
  for(const t in P.throwables)if(P.throwables[t]>0)v+=ITEMS[t].v*P.throwables[t];
  return v})();
 const laObj=objectives.find(o=>o.id==='loot_amount');
 if(laObj&&!laObj.done&&currentVal>=2500){laObj.done=true;msg('¡$2500+ EXTRAÍDOS!','#7dff8f');meta.stats.objectivesDone++;updateDailyProgress('objectives',1)}
 let itemCount=0;
 for(const it of P.inventory)if(it)itemCount+=it.count;
 for(const t in P.throwables)if(P.throwables[t]>0)itemCount+=P.throwables[t];
 if(!runStats.damageTaken)unlockAchievement('ghost');
 if(currentVal>=5000)unlockAchievement('rich');
 if(gt<240)unlockAchievement('speedrun');
 if(itemCount>=12)unlockAchievement('collector');
 let totalVal=currentVal,objBonus=0;
 // Los objetos de miscelánea conservan el valor completo al venderse/extraerse; el resto mantiene la reventa normal.
 let miscBonus=0;for(const it of P.inventory)if(it&&ITEMS[it.id].misc)miscBonus+=ITEMS[it.id].v*it.count*(1-RESALE_RATE);
 for(const o of objectives)if(o.done){totalVal+=500;objBonus++}
 let allyBonus=0;
 for(const a of allies)if(a.alive&&a.following){totalVal+=800;allyBonus++}
 const nightmareMul=meta.nightmareActive?3:1;
 const gross=Math.round((totalVal*RESALE_RATE+miscBonus)*nightmareMul);
 const tax=Math.round(gross*EXTRACT_TAX);
