# Lista de pruebas manuales de regresión

Marca cada punto después de probarlo en el navegador/teléfono. Haz la prueba en la rama de trabajo, no en `principal`.

- [ ] La página carga y el menú responde.
- [ ] La partida empieza sin retraso anormal.
- [ ] Joystick móvil y control de cámara responden.
- [ ] Disparo, recarga y cambio de armas funcionan.
- [ ] El RPG y los demás lanzables siguen funcionando.
- [ ] Inventario: equipar, usar, guardar y arrojar objetos.
- [ ] Enemigos detectan, persiguen y atacan correctamente.
- [ ] Botín, cajas fuertes y coleccionables funcionan.
- [ ] Extracción calcula y entrega las ganancias correctas.
- [ ] Muerte cancela acciones temporizadas y permite volver al menú.
- [ ] Dinero, estadísticas y progreso persisten tras recargar.
- [ ] No aparecen errores nuevos en la consola del navegador.

Anota el commit y el dispositivo/navegador probado al terminar.
